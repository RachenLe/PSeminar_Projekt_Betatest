package com.game.png.Main.GameObjects.PhysicsAndMisc;


public class FloatPoint
{
    public float y;
    public float x;

    public FloatPoint(float x, float y)
    {
        this.x = x;
        this.y = y;
    }

    public void setPoint(float x,float y)
    {
        this.x = x;
        this.y = y;
    }
}