package com.game.png.GUI;

import android.R.layout;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.WifiP2pManager.Channel;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.game.png.Main.MultiplayerUtil.MultiplayerBroadcastReceiver;
import com.game.png.Main.MultiplayerUtil.P2pManagement;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import com.game.png.R.id;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;


public class P2pDetection extends Activity implements Serializable
{

    private MultiplayerBroadcastReceiver receiver;
    public TextView textView;
    public ListView listView;
    public ArrayAdapter<String> p2pAdapter;
    public boolean cameFromLinkedActivity;
    public boolean changingToLinkedActivity;
    boolean changingToP2pActivity;
    public WifiP2pManager manager;
    public Channel channel;
    public IntentFilter intentFilter;
    private boolean registered;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = this.getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        this.getWindow().setFlags(LayoutParams.FLAG_FULLSCREEN, LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.activity_p2p_detection);

        this.textView = this.findViewById(id.status);
        this.listView = this.findViewById(id.listView);

        this.p2pAdapter = new ArrayAdapter<String>(this, layout.simple_list_item_1);
        this.listView.setAdapter(this.p2pAdapter);
        if(P2pManagement.manager == null || P2pManagement.channel == null) {
            P2pManagement.initialize(this.getApplicationContext());
        }
        this.manager = P2pManagement.manager;
        this.channel = P2pManagement.channel;
        if(!this.registered) {
            this.receiver = new MultiplayerBroadcastReceiver(this.manager, this.channel, this);
            this.registered = true;
        }

        this.intentFilter = new IntentFilter();
        this.intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        this.intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        this.intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        this.intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        this.registerReceiver(this.receiver, this.intentFilter);

        final P2pDetection p2pd = this;

        this.listView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                P2pDetection.this.receiver.connectToGroup(position);
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while(!P2pDetection.this.receiver.groupEntered){
                            //Do nothing
                        }
                        p2pd.changingToP2pActivity = true;
                        p2pd.changingToLinkedActivity = true;
                        Intent intent = new Intent(p2pd,P2pRoomDisplay.class);
                        intent.putExtra("cameFromLinkedActivity", true);
                        intent.putExtra("isOwner", false);
                        p2pd.startActivity(intent);
                        p2pd.finish();
                    }
                });

                thread.start();

            }
        });

        this.cameFromLinkedActivity = (boolean) this.getIntent().getSerializableExtra("cameFromLinkedActivity");
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (!this.cameFromLinkedActivity) {
            SoundManager.resumeMusic();
        }
        if(!this.registered){
            this.registerReceiver(this.receiver, this.intentFilter);
            this.registered = true;
        }
        View decorView = this.getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    /* unregister the broadcast receiver */


    @Override
    protected void onPause(){

        super.onPause();
        if(!this.changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
            this.cameFromLinkedActivity = false;

        }
        if(this.receiver != null) {
            this.unregisterReceiver(this.receiver);
            this.registered = false;

        }


    }

    @Override
    protected void onDestroy(){
        if(!this.changingToP2pActivity){
            this.receiver.disconnect();

        }
        if(this.registered && this.receiver != null ){
            this.unregisterReceiver(this.receiver);
            this.registered = false;
        }
        super.onDestroy();
    }



        public void back(View view) {
            changingToLinkedActivity = true;
            changingToP2pActivity = false;
            receiver.disconnect();
            Intent intent = new Intent(this, PlayModiSelection.class);
            intent.putExtra("cameFromLinkedActivity", true);
            startActivity(intent);
            finish();
        }

        public void showGroups(ArrayList<HashMap> groupList) {
            this.p2pAdapter.clear();

            for (HashMap group : groupList) {
                WifiP2pDevice device = (WifiP2pDevice) group.get("hostDevice");
                String groupname = (String) group.get("GroupName");
                String IP = (String) group.get("IP");
                this.p2pAdapter.add(groupname + "\n" + device.deviceName + "\n" + IP);
            }
        }

        public void createGroup(View view) {
            this.receiver.createGroup();
            final P2pDetection p2pd = this;
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while (!P2pDetection.this.receiver.groupEntered) {
                            //do Nothing
                        }
                        p2pd.changingToP2pActivity = true;
                        p2pd.changingToLinkedActivity = true;
                        Intent intent = new Intent(p2pd, P2pRoomDisplay.class);
                        intent.putExtra("cameFromLinkedActivity", true);
                        intent.putExtra("isOwner", true);
                        p2pd.startActivity(intent);
                        p2pd.finish();
                    }
                    catch(Exception e){
                        //do Nothing
                    }

                }
            });

            thread.start();


        }

        public void searchGroups(View view) {
            this.receiver.aGroupDevices.clear();
            this.receiver.discoverGroupServices();

        }





}










