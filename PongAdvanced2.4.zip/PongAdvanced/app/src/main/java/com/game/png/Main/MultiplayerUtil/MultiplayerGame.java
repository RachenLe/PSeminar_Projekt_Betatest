
package com.game.png.Main.MultiplayerUtil;

import com.game.png.GUI.MultiplayerGameActivity;
import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameObjects.Paddl;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.annotation.Nullable;
import android.view.MotionEvent;

import com.game.png.GUI.Game;
import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameModes.GameThread;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.Entitys.Bot;
import com.game.png.Main.GameObjects.Paddl;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;

import java.net.ServerSocket;
import java.net.Socket;

public class MultiplayerGame extends GamePanel
{
    private final ClientTask client;
    private Paddl player  ;
    public Ball ball;
    public int pointsPlayer;
    public boolean ballOnstartPosition;
    private boolean justStarted =true;
    private float startX, startY;
    public OnTouchListener listener;
    public long tStart, tEnd, tDelta;
    public int time;
    private float maxBallSpeed;

    public MultiplayerGame(MultiplayerGameActivity context, ClientTask client )
    {
        super(context, Difficulty.MULTIPLAYER);
        this.getHolder().addCallback(this);
        this.thread = new GameThread(this.getHolder(),this);
        this.client = client;
    }

    @Override
    public void onCreation()
    {
        this.player = new Paddl(500 * this.widthFaktor, 1300* this.heightFaktor, 280 * this.widthFaktor, 40* this.heightFaktor, GamePanel.objectColor, this);
        this.ball = new Ball(100* this.heightFaktor, 100* this.heightFaktor, 20* this.widthFaktor, GamePanel.objectColor, this, this.difficulty);
        this.addObject(this.ball);
        this.addObject(this.player);
        this.colliders.add(new Collider(MultiplayerGame.this.player, MultiplayerGame.this.ball){});
        this.ball.activate();
        this.player.activate();
        this.tStart = System.currentTimeMillis();

        switch(this.difficulty){
            case MAJOR:
                this.startX = 30* this.widthFaktor;
                this.startY = 60* this.heightFaktor;
                break;

            case EASY:
                this.startX = 5* this.widthFaktor;
                this.startY = 20* this.heightFaktor;
                break;

            case HARD:
                this.startX = 25* this.widthFaktor;
                this.startY = 45* this.heightFaktor;
                break;

            case MEDIUM:
                this.startX = 10* this.widthFaktor;
                this.startY = 30* this.heightFaktor;
                break;
        }
        this.maxBallSpeed = this.startY + this.startX;
    }

    @Override
    public void onTouch(MotionEvent event)
    {

        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                if (this.won || this.gameOver)
                {
                    this.endedOnClick = true;
                }
            case MotionEvent.ACTION_MOVE:
                if (!this.won && !this.gameOver) {
                    boolean ballRelease = false;

                    //der Player wurde durch den Hauptpointer verschoben
                    if (event.getPointerCount() == 1)
                    {
                        this.player.setPosition((int) event.getX(), this.getHeight() - 150);
                    }

                    //Der Hauptpointer berührt den Ball
                    if(event.getX() < this.getWidth() / 2 + this.ball.width() + 20 && event.getX() > this.getWidth() / 2 - this.ball.width() - 20
                            && event.getY() < this.getHeight() / 2 + this.ball.height() + 20 && event.getY() > this.getHeight() / 2 - this.ball.height() - 20
                            && this.ballOnstartPosition)
                    {
                        ballRelease = true;
                    }

                    //ein anderer Pointer berührt den Ball

                    try
                    {
                        int pointer = event.getPointerId(event.getPointerCount()-1);

                        if (((event.getX(pointer) < this.getWidth() / 2 + this.ball.width() + 20 && event.getX(pointer) > this.getWidth() / 2 - this.ball.width() - 20
                                && event.getY(pointer) < this.getHeight() / 2 + this.ball.height() + 20 && event.getY(pointer) > this.getHeight() / 2 - this.ball.height() - 20))
                                && this.ballOnstartPosition)
                        {
                            ballRelease = true;
                        }

                    }

                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }


                    //der Ball wurde berührt und lag in der Startposition
                    if(ballRelease)
                    {
                        this.ball.resetStartVelocity();
                        this.ball.calculateMoving(this.startX, this.startY);
                        this.ball.moveable = true;
                        this.ballOnstartPosition = false;
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
                break;
        }
    }

    @Override
    public void extendedDraw(Canvas canvas)
    {
        Paint miscPaint = new Paint();
        miscPaint.setColor(GamePanel.objectColor);
        miscPaint.setTextSize(125* this.widthFaktor);
        Rect rect = new Rect();
        int ppE;
        if (this.pointsPlayer > 9)
        {
            ppE = 2;
        }

        else
        {
            ppE = 1;
        }

        miscPaint.getTextBounds("" + this.pointsPlayer + "", 0, ppE, rect);
        float helloHeight = rect.height();
        rect = new Rect();

        canvas.drawText("" + this.pointsPlayer + "", 15, ((getHeight() / 4) + (helloHeight * 3 / 2)), miscPaint);
        canvas.drawLine(0, this.getHeight() / 4, this.getWidth(), this.getHeight() / 4, miscPaint);
    }

    @Override
    public void updateSpc()
    {
        if(this.justStarted)
        {
            this.ball.setPosition(this.getWidth()/2, this.getHeight()/2);
            this.justStarted =false;
            this.ballOnstartPosition =true;
        }

        if(this.player.centerY() < this.getHeight()-150 || this.player.centerY() > this.getHeight()-150 )
        {
            this.player.setPosition(this.player.point.x, this.getHeight()-150);
        }

        switch(this.ball.checkBoundCollision())
        {
            case RIGHT:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                break;
            case LEFT:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                break;
            case TOP:
            case LEFTTOP:
            case RIGHTTOP:
                client.sendBallData(ball.centerX(),ball.centerY(),ball.movingX,ball.movingY);
                removeObject(ball);
                ball = null;
                break;
            case BOTTOM:
            case LEFTBOTTOM:
            case RIGHTBOTTOM:
                this.ball.moveable = false;
                this.ballOnstartPosition = true;
                this.ball.setPosition(this.getWidth()/2, this.getHeight()/2);
                // add point to last shooter
                break;
            default:
                break;
        }

        if(this.pointsPlayer >= 11 )
        {

        }


    }

    @Override
    public int getScore(){

        return pointsPlayer;
    }

}