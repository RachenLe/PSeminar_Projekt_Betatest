package com.game.png.Main.MultiplayerUtil;

/**
 * Created by Lennard on 10.01.2018.
 */

public class ServerMessage {
    public static final int SHUTDOWN = 20008277, STARTGAME = 7296200, PAUSE = 2725551;

            private ServerMessage(){

            }
}
