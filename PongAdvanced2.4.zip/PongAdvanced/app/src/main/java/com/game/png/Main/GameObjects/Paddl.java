package com.game.png.Main.GameObjects;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.game.png.Main.GameModes.GamePanel;

public class Paddl extends GameObject
{
    private final int color;

    public Paddl(float x, float y , float width, float height, int color, GamePanel context)
    {
        super(x,y, width, height, context);
        this.color = color;
        this.bounceAble = false;
    }

    @Override
    public void update()
    {
        super.update();
    }

    public void deactivate()
    {
        this.activated = false;
    }

    public void activate()
    {
        this.activated = true;
    }

    @Override
    public void draw(Canvas canvas)
    {
        Paint paint = new Paint();
        paint.setColor(this.color);
        canvas.drawRect(this, paint);
    }
}