package com.game.png.Main.GameObjects.PhysicsAndMisc;

public enum SurfaceBorders
{
    LEFT, RIGHT, TOP, BOTTOM, LEFTBOTTOM, LEFTTOP, RIGHTTOP, RIGHTBOTTOM, NONE
}