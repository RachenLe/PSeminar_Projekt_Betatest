package com.game.png.Main.GameModes;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class GameThread extends Thread
{
    public static final int MAX_FPS = 30;
    private double averageFPS;
    private final SurfaceHolder surfaceHolder;
    private final GamePanel gamePanel;
    private boolean running;
    public static Canvas canvas;
    public boolean sleeping;
    boolean ended;
    boolean pause;

    public void setRunning(boolean running)
    {
        this.running = running;
    }

    public GameThread(SurfaceHolder surfaceHolder, GamePanel gamePanel)
    {
        this.surfaceHolder = surfaceHolder;
        this.gamePanel = gamePanel;
        this.ended = false;
    }

    @Override
    public void run()
    {
        long startTime;
        long timeMillis = 1000 / GameThread.MAX_FPS;
        long waitTime;
        int frameCount = 0;
        long totalTime = 0;
        long targetTime = 1000 / GameThread.MAX_FPS;
        this.ended = false;
        while (this.running)
        {
            if(!this.pause)
            {
                startTime = System.nanoTime();
                GameThread.canvas = null;
                try
                {
                    GameThread.canvas = surfaceHolder.lockCanvas();
                    gamePanel.update();
                    gamePanel.draw(GameThread.canvas);

                }

                catch (Exception e)
                {
                    e.printStackTrace();
                }

                finally
                {
                    if (GameThread.canvas != null)
                    {
                        try
                        {
                            this.surfaceHolder.unlockCanvasAndPost(GameThread.canvas);
                        }

                        catch (Exception e)
                        {
                                e.printStackTrace();
                        }
                    }
                }

                    timeMillis = (System.nanoTime() - startTime) / 1000000;
                    waitTime = targetTime - timeMillis;
                    try
                    {
                        if (waitTime > 0)
                        {
                            this.sleeping = true;
                            Thread.sleep(waitTime);
                            this.sleeping = false;
                        }
                    }

                    catch (Exception e)
                    {
                        continue;
                    }

                    totalTime += System.nanoTime() - startTime;
                    frameCount++;
                    if (frameCount == GameThread.MAX_FPS)
                    {
                        this.averageFPS = 1000 / ((totalTime / MAX_FPS) / 1000000);
                        frameCount = 0;
                        totalTime = 0;
                    }
                }
            }
        this.ended = true;
    }

    public void end()
    {
        this.running = false;
    }

    public void pause()
    {
        this.pause = true;
    }

    public void Continue()
    {
        this.pause = false;
    }
}