package com.game.png.Main;

import android.content.Context;
import android.graphics.Color;
import com.game.png.GUI.DesignSelection;
import java.io.Serializable;

public class SavedDataPacket implements Serializable
{
    public boolean musicOn, soundsOn;
    public float musicVolume, soundVolume;
    public int colorBackground, colorObjects;

    public Score[] classicHighscoreEasy;
    public Score[] juggleHighScoreEasy;
    public Score[] speedHighScoreEasy;

    public Score[] classicHighscoreMedium;
    public Score[] juggleHighScoreMedium;
    public Score[] speedHighScoreMedium;

    public Score[] classicHighscoreHard;
    public Score[] juggleHighScoreHard;
    public Score[] speedHighScoreHard;

    public Score[] classicHighscoreMajor;
    public Score[] juggleHighScoreMajor;
    public Score[] speedHighScoreMajor;

    public String currentGameDesign;
    public GameDesign designObject;

    public transient Context context;

    public SavedDataPacket(Context context)
    {
        this.context = context;
    }

    private void override()
    {
        SoundManager.musicOn = musicOn;
        SoundManager.soundsOn = soundsOn;
        SoundManager.musicVolume = musicVolume;
        SoundManager.soundVolume = soundVolume;
        GameDesign.currentColorBackground = colorBackground;
        GameDesign.currentColorObjects = colorObjects;
        HighscoreCalculator.speedHighscoreEasy = this.speedHighScoreEasy;
        HighscoreCalculator.classicHighscoreEasy = this.classicHighscoreEasy;
        HighscoreCalculator.juggleHighscoreEasy = this.juggleHighScoreEasy;

        HighscoreCalculator.speedHighscoreMedium = this.speedHighScoreMedium;
        HighscoreCalculator.classicHighscoreMedium = this.classicHighscoreMedium;
        HighscoreCalculator.juggleHighscoreMedium = this.juggleHighScoreMedium;

        HighscoreCalculator.speedHighscoreHard = this.speedHighScoreHard;
        HighscoreCalculator.classicHighscoreHard = this.classicHighscoreHard;
        HighscoreCalculator.juggleHighscoreHard = this.juggleHighScoreHard;

        HighscoreCalculator.speedHighscoreMajor = this.speedHighScoreMajor;
        HighscoreCalculator.classicHighscoreMajor = this.classicHighscoreMajor;
        HighscoreCalculator.juggleHighscoreMajor = this.juggleHighScoreMajor;

        DesignSelection.currentDesign = currentGameDesign;
        GameDesign.currentGamedesign = designObject;
    }

    public void save()
    {
        this.musicOn = SoundManager.musicOn;
        this.soundsOn = SoundManager.soundsOn;
        this.musicVolume = SoundManager.musicVolume;
        this.soundVolume = SoundManager.soundVolume;
        this.colorBackground = GameDesign.currentColorBackground;
        this.colorObjects = GameDesign.currentColorObjects;
        this.classicHighscoreEasy = HighscoreCalculator.classicHighscoreEasy;
        this.juggleHighScoreEasy = HighscoreCalculator.juggleHighscoreEasy;
        this.speedHighScoreEasy = HighscoreCalculator.speedHighscoreEasy;

        this.speedHighScoreMedium = HighscoreCalculator.speedHighscoreMedium;
        this.classicHighscoreMedium = HighscoreCalculator.classicHighscoreMedium;
        this.juggleHighScoreMedium = HighscoreCalculator.juggleHighscoreMedium;

        this.speedHighScoreHard = HighscoreCalculator.speedHighscoreHard;
        this.classicHighscoreHard =HighscoreCalculator.classicHighscoreHard;
        this.juggleHighScoreHard = HighscoreCalculator.juggleHighscoreHard;

        this.speedHighScoreMajor = HighscoreCalculator.speedHighscoreMajor;
        this.classicHighscoreMajor =HighscoreCalculator.classicHighscoreMajor;
        this.juggleHighScoreMajor =HighscoreCalculator.juggleHighscoreMajor;
        this.currentGameDesign = DesignSelection.currentDesign;
        this.designObject = GameDesign.currentGamedesign;
       DataManager.save(this.context.getFilesDir().getAbsolutePath(), "savedData",".sdp", this);
    }

    public void load()
    {
        SavedDataPacket packet = (SavedDataPacket)DataManager.load(this.context.getFilesDir().getAbsolutePath()+"savedData.sdp");

        if(packet != null)
        {
            this.musicOn = packet.musicOn;
            this.soundsOn = packet.soundsOn;
            this.musicVolume = packet.musicVolume;
            this.soundVolume = packet.soundVolume;
            this.colorBackground = packet.colorBackground;
            this.colorObjects = packet.colorObjects;
            this.classicHighscoreEasy =packet.classicHighscoreEasy;
            this.speedHighScoreEasy = packet.speedHighScoreEasy;
            this.juggleHighScoreEasy = packet.juggleHighScoreEasy;

            this.speedHighScoreMedium =packet.speedHighScoreMedium;
            this.classicHighscoreMedium = packet.classicHighscoreMedium;
            this.juggleHighScoreMedium = packet.juggleHighScoreMedium;

            this.speedHighScoreHard = packet.speedHighScoreHard;
            this.classicHighscoreHard =packet.classicHighscoreHard;
            this.juggleHighScoreHard = packet.juggleHighScoreHard;

            this.speedHighScoreMajor = packet.speedHighScoreMajor;
            this.classicHighscoreMajor =packet.classicHighscoreMajor;
            this.juggleHighScoreMajor =packet.juggleHighScoreMajor;
            this.currentGameDesign = packet.currentGameDesign;
            this.designObject = packet.designObject;
            this.override();
        }

        else
        {
            this.musicOn = true;
            this.soundsOn = true;
            this.musicVolume = 1;
            this.soundVolume = 1;
            this.colorBackground = Color.BLACK;
            this.colorObjects = Color.WHITE;
            this.currentGameDesign = "CLASSIC";
            HighscoreCalculator.resetScores();
            this.classicHighscoreEasy = HighscoreCalculator.classicHighscoreEasy;
            this.juggleHighScoreEasy = HighscoreCalculator.juggleHighscoreEasy;
            this.speedHighScoreEasy = HighscoreCalculator.speedHighscoreEasy;

            this.speedHighScoreMedium = HighscoreCalculator.speedHighscoreMedium;
            this.classicHighscoreMedium = HighscoreCalculator.classicHighscoreMedium;
            this.juggleHighScoreMedium = HighscoreCalculator.juggleHighscoreMedium;

            this.speedHighScoreHard = HighscoreCalculator.speedHighscoreHard;
            this.classicHighscoreHard =HighscoreCalculator.classicHighscoreHard;
            this.juggleHighScoreHard = HighscoreCalculator.juggleHighscoreHard;

            this.speedHighScoreMajor = HighscoreCalculator.speedHighscoreMajor;
            this.classicHighscoreMajor =HighscoreCalculator.classicHighscoreMajor;
            this.juggleHighScoreMajor =HighscoreCalculator.juggleHighscoreMajor;
            this.designObject = GameDesign.getGamedesignByName("CLASSIC");
            this.override();
            this.save();
        }
    }
}