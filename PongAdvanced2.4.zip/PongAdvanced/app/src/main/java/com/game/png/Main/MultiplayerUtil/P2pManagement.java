package com.game.png.Main.MultiplayerUtil;

import android.content.Context;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.WifiP2pManager.ActionListener;
import android.net.wifi.p2p.WifiP2pManager.Channel;

import java.net.InetAddress;

/**
 * Created by Lennard on 31.12.2017.
 */

public class P2pManagement {
    public static WifiP2pManager manager;
    public static Channel channel;
    public static InetAddress hostAdress;

    public static void initialize(Context context){
        P2pManagement.manager = (WifiP2pManager) context.getSystemService(Context.WIFI_P2P_SERVICE);
        P2pManagement.channel = P2pManagement.manager.initialize(context, context.getMainLooper(), null);
    }

    public static void clearManager(WifiP2pManager manager){

        manager.stopPeerDiscovery(P2pManagement.channel,new ActionListener(){

            @Override
            public void onSuccess() {
            }

            @Override
            public void onFailure(int code) {
            }
        });
        manager.cancelConnect(P2pManagement.channel,new ActionListener()
        {
            @Override
            public void onSuccess()
            {
            }

            @Override
            public void onFailure(int code)
            {
            }
        });
        manager.removeGroup(P2pManagement.channel, new ActionListener()
        {
            @Override
            public void onSuccess()
            {
            }

            @Override
            public void onFailure(int code)
            {
            }
        });

        manager.clearLocalServices(P2pManagement.channel, new ActionListener() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onFailure(int code) {
            }
        });

        manager.clearServiceRequests(P2pManagement.channel, new ActionListener() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onFailure(int code) {
            }
        });
        manager.clearServiceRequests(P2pManagement.channel, new ActionListener() {
            @Override
            public void onSuccess() {
            }
            @Override
            public void onFailure(int reason) {
            }
        });
        manager.clearLocalServices(P2pManagement.channel, new ActionListener() {
            @Override
            public void onSuccess() {
            }
            @Override
            public void onFailure(int reason) {
            }
        });

    }



}
