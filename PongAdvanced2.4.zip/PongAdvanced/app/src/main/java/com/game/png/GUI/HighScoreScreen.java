package com.game.png.GUI;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import com.game.png.Main.FadingSpeed;
import com.game.png.Main.GameModes.GameMode;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.HighscoreCalculator;
import com.game.png.Main.SavedDataPacket;
import com.game.png.Main.Score;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import com.game.png.R.id;
import com.game.png.R.layout;
import com.game.png.R.raw;

import java.io.Serializable;

public class HighScoreScreen extends Activity implements Serializable
{
    public String playerName;
    private TextView nmFirst,nmSecond,nmThird,nmFourth,nmFifth, scFirst,scSecond, scThird,scFourth,scFifth;
    public GameMode selectedMode;
    public Difficulty difficulty;
    public int score;
    private Score currentScore;
    public  boolean cameFromGame;
    private boolean cameFromLinkedActivity;
    private boolean changingToLinkedActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = this.getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(layout.activity_highscore_screen);

        this.findViewById(id.backFromHighscore).setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                (new SavedDataPacket(HighScoreScreen.this.getApplicationContext())).save();
                HighScoreScreen.this.changingToLinkedActivity = true;
                Intent intent =new Intent(HighScoreScreen.this, Menu.class);
                intent.putExtra("cameFromLinkedActivity", true);
                HighScoreScreen.this.startActivity(intent);
                HighScoreScreen.this.finish();
            }
        });

        this.cameFromLinkedActivity = (boolean) this.getIntent().getSerializableExtra("cameFromLinkedActivity");
        this.cameFromGame =  (boolean) this.getIntent().getSerializableExtra("cameFromGameActivity");

        if(this.cameFromGame)
        {
            SoundManager.fadeThrowMusic(raw.menu_music, FadingSpeed.FAST,true);
            this.score = (int) this.getIntent().getSerializableExtra("points");
            this.selectedMode = (GameMode) this.getIntent().getSerializableExtra("gamemode");
            this.difficulty = (Difficulty) this.getIntent().getSerializableExtra("difficulty");
            switch(this.selectedMode)
            {
                case SINGLESPEED:
                    switch (this.difficulty)
                    {
                        case EASY:
                            ((TextView) this.findViewById(id.layerView)).setText("SPEED - EASY");
                            break;
                        case MEDIUM:
                            ((TextView) this.findViewById(id.layerView)).setText("SPEED - MEDIUM");
                            break;
                        case HARD:
                            ((TextView) this.findViewById(id.layerView)).setText("SPEED - HARD");
                            break;
                        case MAJOR:
                            ((TextView) this.findViewById(id.layerView)).setText("SPEED - MAJOR");
                            break;
                    }
                    break;
                case SINGLECLASSIC:
                    switch (this.difficulty)
                    {
                        case EASY:
                            ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - EASY");
                            break;
                        case MEDIUM:
                            ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - MEDIUM");
                            break;
                        case HARD:
                            ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - HARD");
                            break;
                        case MAJOR:
                            ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - MAJOR");
                            break;
                    }
                    break;
                case SINGLEJUGGLE:
                    switch (this.difficulty)
                    {
                        case EASY:
                            ((TextView) this.findViewById(id.layerView)).setText("JUGGLE - EASY");
                            break;
                        case MEDIUM:
                            ((TextView) this.findViewById(id.layerView)).setText("JUGGLE - MEDIUM");
                            break;
                        case HARD:
                            ((TextView) this.findViewById(id.layerView)).setText("JUGGLE - HARD");
                            break;
                        case MAJOR:
                            ((TextView) this.findViewById(id.layerView)).setText("JUGGLE - MAJOR");
                            break;
                    }
                    break;
            }

            Builder alertDialog = new Builder(this);
            alertDialog.setTitle("SEE YOUR SCORE");
            alertDialog.setMessage("ENTER NAME");
            TextView textView = this.findViewById(id.NameViewHigh);
            final EditText input = new EditText(this);
            LayoutParams lp = new LayoutParams(
                    LayoutParams.MATCH_PARENT,
                    LayoutParams.MATCH_PARENT);
            input.setTextColor(Color.BLACK);
            input.setLayoutParams(lp);
            alertDialog.setView(input);
            alertDialog.setPositiveButton("CONFIRM",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            HighScoreScreen.this.playerName = input.getText().toString();
                            if (HighScoreScreen.this.playerName.trim().length()<=0|| HighScoreScreen.this.playerName.matches("-empty-"))
                            {
                                HighScoreScreen.this.playerName = "SNEXEFEX";
                            }

                            HighScoreScreen.this.currentScore = new Score(HighScoreScreen.this.playerName, HighScoreScreen.this.score);
                            HighScoreScreen.this.recalculateHighScore(HighScoreScreen.this.currentScore);
                        }
                    });

            alertDialog.show();
        }

        else
        {
            this.selectedMode = GameMode.SINGLECLASSIC;
            this.difficulty = Difficulty.EASY;
            this.showHighScore(this.selectedMode, this.difficulty);
        }

        Button switchOne = this.findViewById(id.switchOne);
        Button switchTwo = this.findViewById(id.switchTwo);

        switchOne.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                switch(HighScoreScreen.this.selectedMode){
                    case SINGLECLASSIC:
                        switch(HighScoreScreen.this.difficulty)
                        {
                            case EASY:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLESPEED;
                                HighScoreScreen.this.difficulty = Difficulty.MAJOR;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MEDIUM:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLECLASSIC;
                                HighScoreScreen.this.difficulty = Difficulty.EASY;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case HARD:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLECLASSIC;
                                HighScoreScreen.this.difficulty = Difficulty.MEDIUM;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MAJOR:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLECLASSIC;
                                HighScoreScreen.this.difficulty = Difficulty.HARD;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                        }
                        break;
                    case SINGLEJUGGLE:
                        switch(HighScoreScreen.this.difficulty)
                        {
                            case EASY:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLECLASSIC;
                                HighScoreScreen.this.difficulty = Difficulty.MAJOR;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MEDIUM:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLEJUGGLE;
                                HighScoreScreen.this.difficulty = Difficulty.EASY;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case HARD:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLEJUGGLE;
                                HighScoreScreen.this.difficulty = Difficulty.MEDIUM;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MAJOR:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLEJUGGLE;
                                HighScoreScreen.this.difficulty = Difficulty.HARD;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                        }
                        break;
                    case SINGLESPEED:
                        switch(HighScoreScreen.this.difficulty)
                        {
                            case EASY:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLEJUGGLE;
                                HighScoreScreen.this.difficulty = Difficulty.MAJOR;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MEDIUM:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLESPEED;
                                HighScoreScreen.this.difficulty = Difficulty.EASY;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case HARD:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLESPEED;
                                HighScoreScreen.this.difficulty = Difficulty.MEDIUM;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MAJOR:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLESPEED;
                                HighScoreScreen.this.difficulty = Difficulty.HARD;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                        }
                        break;
                }
            }
        });

        switchTwo.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                switch(HighScoreScreen.this.selectedMode)
                {
                    case SINGLECLASSIC:
                        switch(HighScoreScreen.this.difficulty)
                        {
                            case EASY:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLECLASSIC;
                                HighScoreScreen.this.difficulty = Difficulty.MEDIUM;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MEDIUM:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLECLASSIC;
                                HighScoreScreen.this.difficulty = Difficulty.HARD;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case HARD:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLECLASSIC;
                                HighScoreScreen.this.difficulty = Difficulty.MAJOR;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MAJOR:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLEJUGGLE;
                                HighScoreScreen.this.difficulty = Difficulty.EASY;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                        }
                        break;
                    case SINGLEJUGGLE:
                        switch(HighScoreScreen.this.difficulty)
                        {
                            case EASY:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLEJUGGLE;
                                HighScoreScreen.this.difficulty = Difficulty.MEDIUM;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MEDIUM:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLEJUGGLE;
                                HighScoreScreen.this.difficulty = Difficulty.HARD;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case HARD:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLEJUGGLE;
                                HighScoreScreen.this.difficulty = Difficulty.MAJOR;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MAJOR:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLESPEED;
                                HighScoreScreen.this.difficulty = Difficulty.EASY;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                        }
                        break;
                    case SINGLESPEED:
                        switch(HighScoreScreen.this.difficulty)
                        {
                            case EASY:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLESPEED;
                                HighScoreScreen.this.difficulty = Difficulty.MEDIUM;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MEDIUM:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLESPEED;
                                HighScoreScreen.this.difficulty = Difficulty.HARD;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case HARD:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLESPEED;
                                HighScoreScreen.this.difficulty = Difficulty.MAJOR;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                            case MAJOR:
                                HighScoreScreen.this.selectedMode = GameMode.SINGLECLASSIC;
                                HighScoreScreen.this.difficulty = Difficulty.EASY;
                                HighScoreScreen.this.showHighScore(HighScoreScreen.this.selectedMode, HighScoreScreen.this.difficulty);
                                break;
                        }
                        break;
                }
            }
        });
    }

    public void showHighScore(GameMode mode, Difficulty difficulty)
    {
        if(mode ==null)
        {
            mode = GameMode.SINGLECLASSIC;
        }
        switch(mode)
        {
            case SINGLESPEED:
                switch(difficulty)
                {
                    case EASY:
                        ((TextView) this.findViewById(id.layerView)).setText("SPEED - EASY");
                        this.setSelectedScore(HighscoreCalculator.speedHighscoreEasy);
                        break;
                    case MEDIUM:
                        ((TextView) this.findViewById(id.layerView)).setText("SPEED - MEDIUM");
                        this.setSelectedScore(HighscoreCalculator.speedHighscoreMedium);
                        break;
                    case HARD:
                        ((TextView) this.findViewById(id.layerView)).setText("SPEED - HARD");
                        this.setSelectedScore(HighscoreCalculator.speedHighscoreHard);
                        break;
                    case MAJOR:
                        ((TextView) this.findViewById(id.layerView)).setText("SPEED - MAJOR");
                        this.setSelectedScore(HighscoreCalculator.speedHighscoreMajor);
                        break;
                }

                break;
            case SINGLECLASSIC:
                switch(difficulty)
                {
                    case EASY:
                        ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - EASY");
                        this.setSelectedScore(HighscoreCalculator.classicHighscoreEasy);
                        break;
                    case MEDIUM:
                        ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - MEDIUM");
                        this.setSelectedScore(HighscoreCalculator.classicHighscoreMedium);
                        break;
                    case HARD:
                        ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - HARD");
                        this.setSelectedScore(HighscoreCalculator.classicHighscoreHard);
                        break;
                    case MAJOR:
                        ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - MAJOR");
                        this.setSelectedScore(HighscoreCalculator.classicHighscoreMajor);
                        break;
                }

                break;
            case SINGLEJUGGLE:
                switch(difficulty)
                {
                    case EASY:
                        ((TextView) this.findViewById(id.layerView)).setText("JUGGLE - EASY");
                        this.setSelectedScore(HighscoreCalculator.juggleHighscoreEasy);
                        break;
                    case MEDIUM:
                        ((TextView) this.findViewById(id.layerView)).setText("JUGGLE - MEDIUM");
                        this.setSelectedScore(HighscoreCalculator.juggleHighscoreMedium);
                        break;
                    case HARD:
                        ((TextView) this.findViewById(id.layerView)).setText("JUGGLE - HARD");
                        this.setSelectedScore(HighscoreCalculator.juggleHighscoreHard);
                        break;
                    case MAJOR:
                        ((TextView) this.findViewById(id.layerView)).setText("JUGGLE - MAJOR");
                        this.setSelectedScore(HighscoreCalculator.juggleHighscoreMajor);
                        break;
                }
                break;
            default:
                this.setSelectedScore(HighscoreCalculator.classicHighscoreEasy);
                ((TextView) this.findViewById(id.layerView)).setText("CLASSIC - EASY");
                break;
        }
    }

    public void setSelectedScore(Score[] scoreType)
    {
        this.nmFirst = this.findViewById(id.nmOne);
        this.nmSecond = this.findViewById(id.nmTwo);
        this.nmThird = this.findViewById(id.nmThree);
        this.nmFourth = this.findViewById(id.nmFour);
        this.nmFifth = this.findViewById(id.nmFive);

        this.scFirst = this.findViewById(id.scOne);
        this.scSecond = this.findViewById(id.scTwo);
        this.scThird = this.findViewById(id.scThree);
        this.scFourth = this.findViewById(id.scFour);
        this.scFifth = this.findViewById(id.scFive);

        this.nmFirst.setText(""+scoreType[0].name+"");
        this.nmSecond.setText(""+scoreType[1].name+"");
        this.nmThird.setText(""+scoreType[2].name+"");
        this.nmFourth.setText(""+scoreType[3].name+"");
        this.nmFifth.setText(""+scoreType[3].name+"");

        this.scFirst.setText(""+scoreType[0].score+"");
        this.scSecond.setText(""+scoreType[1].score+"");
        this.scThird.setText(""+scoreType[2].score+"");
        this.scFourth.setText(""+scoreType[3].score+"");
        this.scFifth.setText(""+scoreType[3].score+"");
    }

    private void recalculateHighScore(Score score)
    {
        int status;
        switch(this.selectedMode)
        {
            case SINGLECLASSIC:
                switch(this.difficulty)
                {
                    case EASY:
                        HighscoreCalculator.isTopClassicScore(score, Difficulty.EASY);
                        this.setSelectedScore(HighscoreCalculator.classicHighscoreEasy);
                        break;
                    case MEDIUM:
                        HighscoreCalculator.isTopClassicScore(score, Difficulty.MEDIUM);
                        this.setSelectedScore(HighscoreCalculator.classicHighscoreMedium);
                        break;
                    case HARD:
                        HighscoreCalculator.isTopClassicScore(score, Difficulty.HARD);
                        this.setSelectedScore(HighscoreCalculator.classicHighscoreHard);
                        break;
                    case MAJOR:
                        HighscoreCalculator.isTopClassicScore(score, Difficulty.MAJOR);
                        this.setSelectedScore(HighscoreCalculator.classicHighscoreMajor);
                        break;
                }
                break;

            case SINGLESPEED:
                switch(this.difficulty)
                {
                    case EASY:
                        HighscoreCalculator.isTopSpeedScore(score, Difficulty.EASY);
                        this.setSelectedScore(HighscoreCalculator.speedHighscoreEasy);
                        break;
                    case MEDIUM:
                        HighscoreCalculator.isTopSpeedScore(score, Difficulty.MEDIUM);
                        this.setSelectedScore(HighscoreCalculator.speedHighscoreMedium);
                        break;
                    case HARD:
                        HighscoreCalculator.isTopSpeedScore(score, Difficulty.HARD);
                        this.setSelectedScore(HighscoreCalculator.speedHighscoreHard);
                        break;
                    case MAJOR:
                        HighscoreCalculator.isTopSpeedScore(score, Difficulty.MAJOR);
                        this.setSelectedScore(HighscoreCalculator.speedHighscoreMajor);
                        break;
                }
                break;

            case SINGLEJUGGLE:
                switch(this.difficulty)
                {
                    case EASY:
                        HighscoreCalculator.isTopJuggleScore(score, Difficulty.EASY);
                        this.setSelectedScore(HighscoreCalculator.juggleHighscoreEasy);
                        break;
                    case MEDIUM:
                        HighscoreCalculator.isTopJuggleScore(score, Difficulty.MEDIUM);
                        this.setSelectedScore(HighscoreCalculator.juggleHighscoreMedium);
                        break;
                    case HARD:
                        HighscoreCalculator.isTopJuggleScore(score, Difficulty.HARD);
                        this.setSelectedScore(HighscoreCalculator.juggleHighscoreHard);
                        break;
                    case MAJOR:
                        HighscoreCalculator.isTopJuggleScore(score, Difficulty.MAJOR);
                        this.setSelectedScore(HighscoreCalculator.juggleHighscoreMajor);
                        break;
                }
                break;

            default:
                status = 8888;
                this.setSelectedScore(HighscoreCalculator.classicHighscoreEasy);
                break;
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if(!this.cameFromLinkedActivity)
        {
            SoundManager.resumeMusic();
        }
        View decorView = this.getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if(!this.changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
            this.cameFromLinkedActivity = false;
        }
    }
}