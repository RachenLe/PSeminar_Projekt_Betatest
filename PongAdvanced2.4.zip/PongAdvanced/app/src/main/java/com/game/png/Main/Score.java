package com.game.png.Main;

import java.io.Serializable;

public class Score implements Serializable
{
    public String name;
    public int score;
    public int rank;

    public Score(String name, int score)
    {
        this.name = name;
        this.score = score;
    }

    public void setRank()
    {
        rank = this.rank;
    }
}
