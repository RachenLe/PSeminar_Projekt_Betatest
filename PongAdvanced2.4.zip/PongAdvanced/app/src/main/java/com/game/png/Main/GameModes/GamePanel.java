package com.game.png.Main.GameModes;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import com.game.png.GUI.Game;
import com.game.png.Main.GameDesign;
import com.game.png.Main.GameObjects.GameObject;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.TimeCounter;
import java.util.ArrayList;

public abstract class GamePanel extends SurfaceView implements Callback
{
    public GameThread thread ;
    public ArrayList<GameObject> gameObjects = new ArrayList<GameObject>();
    public static int backgroundColor, objectColor;
    public ArrayList<Collider> colliders = new ArrayList<Collider>();
    public boolean won, gameOver;
    public Activity context;
    public Difficulty difficulty;
    public boolean ending;
    public boolean EndScreenDrawn;
    public boolean paused;
    public int PanelWidth, PanelHeight;
    public float widthFaktor, heightFaktor;
    public boolean endedOnClick;
    public int totalTimeMillis;
    public TimeCounter timer;
    private int score;
    private boolean showScore;

    public GamePanel(Activity context, Difficulty difficulty)
    {
        super(context);
        this.gameOver = false;
        this.won = false;
        this.getHolder().addCallback(this);
        this.thread = new GameThread(this.getHolder(),this);
        this.setFocusable(true);
        this.context = context;
        this. difficulty = difficulty;
        this.ending = false;
        if(context.getClass() == Game.class) {
            PanelWidth = ((Game)context).panelWidth;
            PanelHeight = ((Game)context).panelHeight;
        }
        this.EndScreenDrawn = false;
        GamePanel.backgroundColor = GameDesign.currentColorBackground;
        GamePanel.objectColor = GameDesign.currentColorObjects;
        this.timer = new TimeCounter();
    }

    public abstract void onCreation();

    @Override
    public void surfaceCreated(SurfaceHolder holder)
    {
        this.thread = new GameThread(this.getHolder(),this);
        this.widthFaktor = (float) this.PanelWidth /(float)1080;
        this.heightFaktor = (float) this.PanelHeight /(float)1776;
        this.onCreation();
        this.thread.setRunning(true);
        this.thread.start();
        this.timer.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
    {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder)
    {
        this.thread.setRunning(false);
        this.thread.interrupt();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        if(!this.ending &!this.paused)
        {
            this.onTouch(event);
        }
        return true;
    }

    public abstract void onTouch(MotionEvent event);

    @Override
    public void draw(Canvas canvas)
    {
        super.draw(canvas);
        if(!this.won && !this.gameOver && !this.paused)
        {
            canvas.drawColor(GamePanel.backgroundColor);

            for (int i = 0; i < this.gameObjects.size(); i++)
            {
                GameObject obj = this.gameObjects.get(i);
                obj.draw(canvas);
            }
            this.extendedDraw(canvas);
        }

        else if(this.won && !this.gameOver)
        {
            canvas.drawColor(Color.WHITE);
            Paint winnerPaint = new Paint();
            winnerPaint.setColor(Color.YELLOW);
            winnerPaint.setTextSize(this.widthFaktor *800);
            Rect rect = new Rect();
            winnerPaint.getTextBounds("V", 0, 1, rect);
            float width = rect.width();
            float height = rect.height();
            canvas.drawText("V", this.getWidth()/2-width/2, this.getHeight()/2+height/2,winnerPaint);
            if(this.endedOnClick)
            {

                if(context.getClass() == Game.class) {
                    this.thread.end();
                    ((Game)context).win(this.showScore, this.score);
                }

            }
        }

        else if(this.gameOver && !this.won)
        {
            canvas.drawColor(Color.BLACK);
            Paint loserPaint = new Paint();
            loserPaint.setColor(Color.WHITE);
            loserPaint.setTextSize(this.widthFaktor *180);
            Rect rect = new Rect();
            loserPaint.getTextBounds("GAME OVER", 0, 9, rect);
            float width = rect.width();
            float height = rect.height();
            canvas.drawText("GAME OVER", this.getWidth()/2 - width/2, this.getHeight()/2 + height/2,loserPaint);
            if(this.endedOnClick)
            {
                this.thread.end();
                if(context.getClass() == Game.class) {
                    this.thread.end();
                    ((Game)context).loose(this.showScore, this.score);
                }

            }
        }

        else if(this.paused && !this.gameOver && !this.won)
        {
            canvas.drawColor(Color.BLACK);
            Paint loserPaint = new Paint();
            loserPaint.setColor(Color.WHITE);
            loserPaint.setTextSize(this.widthFaktor *180);
            Rect rect = new Rect();
            loserPaint.getTextBounds("PAUSED", 0, 6, rect);
            float width = rect.width();
            float height = rect.height();
            canvas.drawText("PAUSED", this.getWidth()/2 - width/2, this.getHeight()/2 + height/2,loserPaint);
            this.thread.pause();
            this.timer.pause();
        }
    }

    public abstract void extendedDraw(Canvas canvas);
    public abstract void updateSpc();

    public void update()
    {   if(!this.won && !this.gameOver && !this.paused) {
        for (int i = 0; i < this.gameObjects.size(); i++) {
            GameObject obj = this.gameObjects.get(i);
            obj.update();
        }
        this.updateSpc();
    }
    }

    public void addObject(GameObject gameObject)
    {
        this.gameObjects.add(gameObject);
    }

    public void removeObject(GameObject gameObject)
    {
        this.gameObjects.remove(gameObject);
    }

    public void win(boolean calcScore)
    {
        this.showScore = calcScore;
        if(calcScore)
        {
            this.totalTimeMillis = this.timer.getEndTime();
            this.score = this.getScore();
        }
        this.won = true;
    }

    public void loose(boolean calcScore)
    {
        this.showScore = calcScore;
        if(calcScore)
        {
            this.totalTimeMillis = this.timer.getEndTime();
            this.score = this.getScore();
        }
        this.gameOver = true;
    }

    public abstract int getScore();

    public void pause()
    {
        this.paused = true;
    }

    public void resume()
    {
        this.paused = false;
        this.timer.pause();
        this.thread.Continue();
    }
}