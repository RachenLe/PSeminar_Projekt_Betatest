package com.game.png.Main;

public enum FadingSpeed
{
    FAST, SLOW, MODERATE
}
