package com.game.png.Main.GameModes;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

import com.game.png.GUI.Game;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.Entitys.Bot;
import com.game.png.Main.GameObjects.Paddl;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;

public class ClassicModeGame extends GamePanel
{
    private Paddl player  ;
    private Bot botEnemy;
    public Ball ball;
    public int pointsPlayer, pointsBot;
    private boolean ballOnstartPosition = true;
    private boolean justStarted =true;
    private float startX, startY;
    public View.OnTouchListener listener;
    public long tStart, tEnd, tDelta;
    public int time;
    private float maxBallSpeed;

    public ClassicModeGame(Game context, Difficulty difficulty )
    {
        super(context, difficulty);
        this.getHolder().addCallback(this);
        this.thread = new GameThread(this.getHolder(),this);
    }

    @Override
    public void onCreation()
    {
        this.player = new Paddl(500 * this.widthFaktor, 1300* this.heightFaktor, 280 * this.widthFaktor, 40* this.heightFaktor, GamePanel.objectColor, this);
        this.botEnemy = new Bot(500 * this.widthFaktor, 150* this.heightFaktor, (280 * this.widthFaktor), 40* this.heightFaktor, GamePanel.objectColor,this, this.difficulty);
        this.ball = new Ball(100* this.heightFaktor, 100* this.heightFaktor, 20* this.widthFaktor, GamePanel.objectColor, this, this.difficulty);
        this.addObject(this.ball);
        this.addObject(this.player);
        this.addObject(this.botEnemy);
        this.colliders.add(new Collider(ClassicModeGame.this.player, ClassicModeGame.this.ball){});
        this.colliders.add(new Collider(ClassicModeGame.this.botEnemy, ClassicModeGame.this.ball){});
        this.ball.activate();
        this.player.activate();
        this.botEnemy.activate();
        this.tStart = System.currentTimeMillis();

        switch(this.difficulty){
            case MAJOR:
                this.startX = 30* this.widthFaktor;
                this.startY = 60* this.heightFaktor;
                break;

            case EASY:
                this.startX = 5* this.widthFaktor;
                this.startY = 20* this.heightFaktor;
                break;

            case HARD:
                this.startX = 25* this.widthFaktor;
                this.startY = 45* this.heightFaktor;
                break;

            case MEDIUM:
                this.startX = 10* this.widthFaktor;
                this.startY = 30* this.heightFaktor;
                break;
        }
        this.maxBallSpeed = this.startY + this.startX;
    }

    @Override
    public void onTouch(MotionEvent event)
    {

        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                if (this.won || this.gameOver)
                {
                    this.endedOnClick = true;
                }
            case MotionEvent.ACTION_MOVE:
                if (!this.won && !this.gameOver) {
                    boolean ballRelease = false;

                    //der Player wurde durch den Hauptpointer verschoben
                    if (event.getPointerCount() == 1)
                    {
                        this.player.setPosition((int) event.getX(), this.getHeight() - 150);
                    }

                    //Der Hauptpointer berührt den Ball
                    if(event.getX() < this.getWidth() / 2 + this.ball.width() + 20 && event.getX() > this.getWidth() / 2 - this.ball.width() - 20
                            && event.getY() < this.getHeight() / 2 + this.ball.height() + 20 && event.getY() > this.getHeight() / 2 - this.ball.height() - 20
                            && this.ballOnstartPosition)
                    {
                        ballRelease = true;
                    }

                    //ein anderer Pointer berührt den Ball

                    try
                    {
                        int pointer = event.getPointerId(event.getPointerCount()-1);

                        if (((event.getX(pointer) < this.getWidth() / 2 + this.ball.width() + 20 && event.getX(pointer) > this.getWidth() / 2 - this.ball.width() - 20
                                && event.getY(pointer) < this.getHeight() / 2 + this.ball.height() + 20 && event.getY(pointer) > this.getHeight() / 2 - this.ball.height() - 20))
                                && this.ballOnstartPosition)
                        {
                            ballRelease = true;
                        }

                    }

                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }


                    //der Ball wurde berührt und lag in der Startposition
                    if(ballRelease)
                    {
                        this.ball.resetStartVelocity();
                        this.ball.calculateMoving(this.startX, this.startY);
                        this.ball.moveable = true;
                        this.ballOnstartPosition = false;
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
                break;
        }
    }

    @Override
    public void extendedDraw(Canvas canvas)
    {
        Paint miscPaint = new Paint();
        miscPaint.setColor(GamePanel.objectColor);
        miscPaint.setTextSize(125* this.widthFaktor);
        Rect rect = new Rect();
        int ppE;
        int pbE;
        if (this.pointsPlayer > 9)
        {
            ppE = 2;
        }

        else
        {
            ppE = 1;
        }

        if (this.pointsBot > 9)
        {
            pbE = 2;
        }

        else
        {
            pbE = 1;
        }
        miscPaint.getTextBounds("" + this.pointsPlayer + "", 0, ppE, rect);
        float helloHeight = rect.height();
        rect = new Rect();
        miscPaint.getTextBounds("" + this.pointsBot + "", 0, pbE, rect);
        float byeWidth = rect.width();
        float byeHeight = rect.height();

        canvas.drawText("" + this.pointsPlayer + "", 15, ((getHeight() / 2) + (helloHeight * 3 / 2)), miscPaint);
        canvas.drawText("" + this.pointsBot + "", ((getWidth() - byeWidth) - 20), ((getHeight() / 2) - byeHeight / 2), miscPaint);
        canvas.drawLine(0, this.getHeight() / 2, this.getWidth(), this.getHeight() / 2, miscPaint);
    }

    @Override
    public void updateSpc()
    {
        if(this.justStarted)
        {
            this.ball.setPosition(this.getWidth()/2, this.getHeight()/2);
            this.justStarted =false;
            this.ballOnstartPosition =true;
        }

        if(this.player.centerY() < this.getHeight()-150 || this.player.centerY() > this.getHeight()-150 )
        {
            this.player.setPosition(this.player.point.x, this.getHeight()-150);
        }

        switch(this.ball.checkBoundCollision())
        {
            case RIGHT:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                break;
            case LEFT:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                break;
            case TOP:
            case LEFTTOP:
            case RIGHTTOP:
                this.ball.moveable = false;
                this.ballOnstartPosition = true;
                this.ball.setPosition(this.getWidth()/2, this.getHeight()/2);
                this.pointsPlayer++;
                break;
            case BOTTOM:
            case LEFTBOTTOM:
            case RIGHTBOTTOM:
                this.ball.moveable = false;
                this.ballOnstartPosition = true;
                this.ball.setPosition(this.getWidth()/2, this.getHeight()/2);
                this.pointsBot++;
                break;
            default:
                break;
        }

        if(this.pointsPlayer >= 11 && this.pointsPlayer > this.pointsBot +1)
        {
            this.won = true;
            this.tEnd = System.currentTimeMillis();
            this.tDelta = this.tEnd - this.tStart;
            this.time = (int) this.tDelta / 1000;
            this.win(true);
        }
        if(this.pointsBot >= 11 && this.pointsPlayer < this.pointsBot -1)
        {
            this.tEnd = System.currentTimeMillis();
            this.tDelta = this.tEnd - this.tStart;
            this.time = (int) this.tDelta / 1000;
            this.gameOver = true;
            this.loose(true);
        }

        if(this.maxBallSpeed < (this.ball.movingX* this.ball.countsOfMoving)+(this.ball.movingY* this.ball.countsOfMoving))
        {
            this.maxBallSpeed = (this.ball.movingX* this.ball.countsOfMoving)+(this.ball.movingY* this.ball.countsOfMoving);
        }
    }

    @Override
    public int getScore()
    {
        //calculate with botpoints, time and maxBallspeed
        int score = Math.round(((1000000+ this.maxBallSpeed *10- this.totalTimeMillis *2)/1000)*((float) this.pointsPlayer /(float) this.pointsBot));
        if(score<10)
        {
            score = 10;
        }
        return score;
    }
}