package com.game.png.Main;

import android.graphics.Color;
import java.io.Serializable;
import java.util.ArrayList;

public class GameDesign implements Serializable {
    public static transient int currentColorObjects;
    public static transient int currentColorBackground;
    public static transient GameDesign currentGamedesign;
    public static transient ArrayList<GameDesign> constantDesigns = GameDesign.getConstantDesigns();
    public static transient ArrayList<GameDesign> individualDesigns;
    public String designName;
    public int thisBackgroundColor;
    public int thisObjectColor;

    private GameDesign(String designName, int thisBackgroundColor, int thisObjectColor, int o)
    {
        this.designName = designName;
        this.thisBackgroundColor = thisBackgroundColor;
        this.thisObjectColor = thisObjectColor;
    }

    public GameDesign(String designName, int thisBackgroundColor, int thisObjectColor)
    {
        this.designName = designName;
        this.thisBackgroundColor = thisBackgroundColor;
        this.thisObjectColor = thisObjectColor;
    }

    public static void changeObjectColor(int color)
    {
        GameDesign.currentColorObjects = color;
    }

    public static void changeBackgroundColor(int color)
    {
        GameDesign.currentColorBackground = color;
    }

    private static ArrayList<GameDesign> getConstantDesigns()
    {
        ArrayList<GameDesign> constantDesigns = new ArrayList<GameDesign>();
        constantDesigns.add(new GameDesign("CLASSIC",Color.BLACK,Color.WHITE,0));
        constantDesigns.add(new GameDesign("REVERSE", Color.WHITE,Color.BLACK,0));
        constantDesigns.add(new GameDesign("WINE", Color.rgb(100,0,0),Color.rgb(180,180,180),0));
        constantDesigns.add(new GameDesign("GRAPE", Color.rgb(143,45,99),Color.rgb(200,200,200),0));
        constantDesigns.add(new GameDesign("LIMY", Color.rgb(40,40,40),Color.rgb(120,230,40),0));
        constantDesigns.add(new GameDesign("RADIO", Color.BLACK,Color.rgb(50,150,220),0));
        constantDesigns.add(new GameDesign("JUICE", Color.rgb(250,120,0),Color.rgb(143,45,99 ),0));
        constantDesigns.add(new GameDesign("NEON", Color.rgb(0,0,100),Color.rgb(245,250,0),0));
        constantDesigns.add(new GameDesign("CONTRA", Color.rgb(100,0,0),Color.rgb(120,230,40),0));
        constantDesigns.add(new GameDesign("AGR", Color.rgb(255,0,0),Color.rgb(50,0,0),0));
        return constantDesigns;
    }

    public static GameDesign getGamedesignByName(String designName)
    {
        GameDesign design = null;
        for(GameDesign vardesign : GameDesign.constantDesigns)
        {
            if(vardesign.designName.matches(designName))
            {
                design = vardesign;
            }
        }
        return design;
    }

    public  static  int getButtonColor()
    {
        if(GameDesign.currentGamedesign.designName.equals("CLASSIC")|| GameDesign.currentGamedesign.designName.equals("REVERSE"))
        {
            return Color.BLUE;
        }

        else if(GameDesign.currentGamedesign.designName.equals("GRAPE")|| GameDesign.currentGamedesign.designName.equals("WINE")
                || GameDesign.currentGamedesign.designName.equals("JUICE")|| GameDesign.currentGamedesign.designName.equals("AGR"))
        {
            return GameDesign.currentColorBackground;
        }

        else if(GameDesign.currentGamedesign.designName.equals("LIMY")|| GameDesign.currentGamedesign.designName.equals("RADIO")
                || GameDesign.currentGamedesign.designName.equals("CONTRA")|| GameDesign.currentGamedesign.designName.equals("NEON"))
        {
            return GameDesign.currentColorObjects;
        }

        else
        {
            return Color.BLACK;
        }
    }
}