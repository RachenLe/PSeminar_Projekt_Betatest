package com.game.png.GUI;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;

import com.game.png.Main.SoundManager;
import com.game.png.R;
import com.game.png.R.layout;

import java.io.Serializable;

public class PlayModiSelection extends Activity implements Serializable{

    boolean changingToLinkedActivity;
    private boolean cameFromLinkedActivity ;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = this.getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        this.getWindow().setFlags(LayoutParams.FLAG_FULLSCREEN, LayoutParams.FLAG_FULLSCREEN);

        this.setContentView(layout.activity_play_modi_selection);
        this.cameFromLinkedActivity = (boolean) this.getIntent().getSerializableExtra("cameFromLinkedActivity");
    }

    public void SinglePlayer(View v)
    {
        this.changingToLinkedActivity = true;
        Intent intent =new Intent(this, SinglePlayerSelection.class);
        intent.putExtra("cameFromLinkedActivity", true);
        this.startActivity(intent);
        this.finish();
    }

    public void multiPlayer(View view)
    {
        this.changingToLinkedActivity = true;
        Intent intent =new Intent(this, P2pDetection.class);
        intent.putExtra("cameFromLinkedActivity", true);
        this.startActivity(intent);
        this.finish();
    }

    public void back(View v)
    {
        this.changingToLinkedActivity = true;
        Intent intent =new Intent(this, Menu.class);
        intent.putExtra("cameFromLinkedActivity", true);
        this.startActivity(intent);
        this.finish();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if(!this.cameFromLinkedActivity)
        {
            SoundManager.resumeMusic();
        }
        View decorView = this.getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if(!this.changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
            this.cameFromLinkedActivity = false;
        }
    }
}