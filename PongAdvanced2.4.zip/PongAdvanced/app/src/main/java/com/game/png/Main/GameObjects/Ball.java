package com.game.png.Main.GameObjects;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;

public class Ball extends GameObject
{
    public float radius;
    public int color;
    public int countsOfCollision;
    public boolean speedGaining;
    public int lowerAdd, hAdd;
    public int maxSpeed;

    public Ball(float x, float y, float radius, int color, GamePanel gamepanel, Difficulty difficulty) {
        super(x, y, radius * 2, radius * 2, gamepanel);
        this.radius = radius;
        this.color = color;
        this.moveable = true;
        this.bounceAble = true;
        this.countsOfCollision = 0;
        this.speedGaining = true;

        switch(difficulty)
        {
            case EASY:
                this.lowerAdd = 2;
                this.hAdd =  4;
                this.maxSpeed = 60;
                break;
            case MEDIUM:
                this.lowerAdd = 3;
                this.hAdd =  5;
                this.maxSpeed = 80;
                break;
            case HARD:
                this.lowerAdd = 5;
                this.hAdd =  8;
                this.maxSpeed = 200;
                break;
            case MAJOR:
                this.lowerAdd = 7;
                this.hAdd =  10;
                this.maxSpeed = 300;
                break;
        }
    }

    @Override
    public void update()
    {
        super.update();
        //der Ball muss aktiviert sein
        if (this.activated)
        {
                  //Übertragen der Anzahl der Bewegungen pro Zug auf einen temporären Berechnungswert
                 int var = this.countsOfMoving;
                  // gleichmäßige Beschleunigung des Balls ist aktiviert(standardmäßig)
            if(this.movingY < this.maxSpeed && this.movingX < this.maxSpeed)
            {
                if (this.speedGaining)
                {
                    //ist der Ball einer gewissen Anzahl entsprechend mit einem Spieler kollidiert wird beschleunigt
                    if (this.countsOfCollision / 2 > 2)
                    {
                        //Übertragen der Bewegungswerte auf einen temporären Berechnungswert
                        float tempMx = this.movingX;
                        float tempMy = this.movingY;
                        //Wenn der Berechnungswert negativ ist wird er auf positiv gesetzt
                        if (tempMx < 0)
                        {
                            tempMx = -tempMx;
                        }

                        if (tempMy < 0)
                        {
                            tempMy = -tempMy;
                        }
                        //Der stärkere Berechnungswert erhält Vorzug bei der Beschleunigung
                        //=> Einfluss auf Schwierigkeit
                        if (tempMy >= tempMx)
                        {
                            //der Y-Bewegungswert ist überlegen
                            //der größere Faktor wird zum Y-Wert hinzu gerechnet
                            //negative Bewegungswerte müssen den Zusatz subtrahiert bekommen
                            if (this.movingY < 0)
                            {
                                this.movingY = this.movingY - (float) this.hAdd / (float) this.countsOfMoving;
                            }
                            //positive addiert
                            else if (this.movingY >= 0)
                            {
                                this.movingY = this.movingY + (float) this.hAdd / (float) this.countsOfMoving;
                            }
                            //der kleinere Faktor zum X-Wert
                            //negative Bewegungswerte müssen den Zusatz subtrahiert bekommen
                            if (this.movingX < 0)
                            {
                                this.movingX = this.movingX - (float) this.lowerAdd / (float) this.countsOfMoving;
                            }
                            //positive addiert
                            else if (this.movingY >= 0)
                            {
                                this.movingX = this.movingX + (float) this.lowerAdd / (float) this.countsOfMoving;
                            }
                        }

                        else
                        {
                            //der Fall in welchem der X-Wert überlegen ist verläuft analog
                            if (this.movingX < 0)
                            {
                                this.movingX = this.movingX - (float) this.hAdd / (float) this.countsOfMoving;
                            }

                            else if (this.movingX > 0)
                            {
                                this.movingX = this.movingX + (float) this.hAdd / (float) this.countsOfMoving;
                            }

                            if (this.movingY < 0)
                            {
                                this.movingY = this.movingY - (float) this.lowerAdd / (float) this.countsOfMoving;
                            }

                            else if (this.movingY > 0)
                            {
                                this.movingY = this.movingY + (float) this.lowerAdd / (float) this.countsOfMoving;
                            }
                        }
                        //die neuen Bewegungswerte werden berechnet
                        this.calculateMoving(this.movingX, this.movingY);
                        //Die Kollisionszahl wird zurück gesetzt
                        this.countsOfCollision = 0;
                    }
                }
            }
             //der temporäre Berechnungswert stellt die Anazhl der Schritte in diesem Zug
            while (var > 0 && this.moveable)
             {
                   //der Ball wird um seine bereits gesetzten Bewegungswerte verschoben, welche unter Umständen nur einen
                   // Bruchteil der Gesamtbewegung des Zuges darstellen
                 this.move();
                  //die Kollision wird geprüft
                  for (int i = 0; i < this.colliders.size(); i++)
                  {
                      this.colliders.get(i).check();
                  }
                  //der Temporäre wert wird verkleinert ... Ein Schritt ist ausgeführt
                  var--;
             }

             //hat in diesem Zug eine Kollision statt gefunden
             if (this.collisionDetectedInThisStep)
             {
                 //dann wird die Anzahl der Kollisionen erhöht
                 this.countsOfCollision++;
             }
        }
    }

    public void deactivate()
    {
        this.activated = false;
    }

    public void activate()
    {
        this.activated = true;
    }

    @Override
    public void draw(Canvas canvas)
    {
        Paint paint = new Paint();
        paint.setColor(this.color);
        canvas.drawOval(this, paint);
    }

    public void delete()
    {

    }
}