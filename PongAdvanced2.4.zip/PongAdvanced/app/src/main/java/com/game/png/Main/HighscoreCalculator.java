package com.game.png.Main;

import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;

public class HighscoreCalculator
{
    public static Score[] classicHighscoreEasy;
    public static Score[] juggleHighscoreEasy;
    public static Score[] speedHighscoreEasy;

    public static Score[] classicHighscoreMedium;
    public static Score[] juggleHighscoreMedium;
    public static Score[] speedHighscoreMedium;

    public static Score[] classicHighscoreHard;
    public static Score[] juggleHighscoreHard;
    public static Score[] speedHighscoreHard;

    public static Score[] classicHighscoreMajor;
    public static Score[] juggleHighscoreMajor;
    public static Score[] speedHighscoreMajor;

    public static void resetScores()
    {
        HighscoreCalculator.classicHighscoreEasy = new Score[5];
        HighscoreCalculator.juggleHighscoreEasy = new Score[5];
        HighscoreCalculator.speedHighscoreEasy = new Score[5];
        for(int i =0; i<=4;i++)
        {
            HighscoreCalculator.classicHighscoreEasy[i] = new Score("-empty-",0);
            HighscoreCalculator.juggleHighscoreEasy[i] = new Score("-empty-",0);
            HighscoreCalculator.speedHighscoreEasy[i] = new Score("-empty-",0);

            HighscoreCalculator.classicHighscoreEasy[i].rank = i+1;
            HighscoreCalculator.speedHighscoreEasy[i].rank = i+1;
            HighscoreCalculator.juggleHighscoreEasy[i].rank = i+1;
        }

        HighscoreCalculator.classicHighscoreMedium = new Score[5];
        HighscoreCalculator.juggleHighscoreMedium = new Score[5];
        HighscoreCalculator.speedHighscoreMedium = new Score[5];
        for(int i =0; i<=4;i++)
        {
            HighscoreCalculator.classicHighscoreMedium[i] = new Score("-empty-",0);
            HighscoreCalculator.juggleHighscoreMedium[i] = new Score("-empty-",0);
            HighscoreCalculator.speedHighscoreMedium[i] = new Score("-empty-",0);

            HighscoreCalculator.classicHighscoreMedium[i].rank = i+1;
            HighscoreCalculator.speedHighscoreMedium[i].rank = i+1;
            HighscoreCalculator.juggleHighscoreMedium[i].rank = i+1;
        }

        HighscoreCalculator.classicHighscoreHard = new Score[5];
        HighscoreCalculator.juggleHighscoreHard = new Score[5];
        HighscoreCalculator.speedHighscoreHard = new Score[5];
        for(int i =0; i<=4;i++)
        {
            HighscoreCalculator.classicHighscoreHard[i] = new Score("-empty-",0);
            HighscoreCalculator.juggleHighscoreHard[i] = new Score("-empty-",0);
            HighscoreCalculator.speedHighscoreHard[i] = new Score("-empty-",0);

            HighscoreCalculator.classicHighscoreHard[i].rank = i+1;
            HighscoreCalculator.speedHighscoreHard[i].rank = i+1;
            HighscoreCalculator.juggleHighscoreHard[i].rank = i+1;
        }

        HighscoreCalculator.classicHighscoreMajor = new Score[5];
        HighscoreCalculator.juggleHighscoreMajor = new Score[5];
        HighscoreCalculator.speedHighscoreMajor = new Score[5];
        for(int i =0; i<=4;i++)
        {
            HighscoreCalculator.classicHighscoreMajor[i] = new Score("-empty-",0);
            HighscoreCalculator.juggleHighscoreMajor[i] = new Score("-empty-",0);
            HighscoreCalculator.speedHighscoreMajor[i] = new Score("-empty-",0);

            HighscoreCalculator.classicHighscoreMajor[i].rank = i+1;
            HighscoreCalculator.speedHighscoreMajor[i].rank = i+1;
            HighscoreCalculator.juggleHighscoreMajor[i].rank = i+1;
        }
    }

    public static void isTopClassicScore(Score score, Difficulty difficulty)
    {
        Score[] array;
        switch(difficulty)
        {
            case EASY:
                array = HighscoreCalculator.classicHighscoreEasy;
                HighscoreCalculator.classicHighscoreEasy = HighscoreCalculator.calculateScore(array,score);
                break;
            case MEDIUM:
                array = HighscoreCalculator.classicHighscoreMedium;
                HighscoreCalculator.classicHighscoreMedium = HighscoreCalculator.calculateScore(array,score);
                break;
            case HARD:
                array = HighscoreCalculator.classicHighscoreHard;
                HighscoreCalculator.classicHighscoreHard = HighscoreCalculator.calculateScore(array,score);
                break;
            case MAJOR:
                array = HighscoreCalculator.classicHighscoreMajor;
                HighscoreCalculator.classicHighscoreMajor = HighscoreCalculator.calculateScore(array,score);
                break;
            default:
                array = HighscoreCalculator.classicHighscoreEasy;
                HighscoreCalculator.classicHighscoreEasy = HighscoreCalculator.calculateScore(array,score);
                break;
        }
    }

    public static void isTopJuggleScore(Score score, Difficulty difficulty)
    {
        Score[] array;
        switch(difficulty)
        {
            case EASY:
                array = HighscoreCalculator.juggleHighscoreEasy;
                HighscoreCalculator.juggleHighscoreEasy = HighscoreCalculator.calculateScore(array,score);
                break;
            case MEDIUM:
                array = HighscoreCalculator.juggleHighscoreMedium;
                HighscoreCalculator.juggleHighscoreMedium = HighscoreCalculator.calculateScore(array,score);
                break;
            case HARD:
                array = HighscoreCalculator.juggleHighscoreHard;
                HighscoreCalculator.juggleHighscoreHard = HighscoreCalculator.calculateScore(array,score);
                break;
            case MAJOR:
                array = HighscoreCalculator.juggleHighscoreMajor;
                HighscoreCalculator.juggleHighscoreMajor = HighscoreCalculator.calculateScore(array,score);
                break;
            default:
                array = HighscoreCalculator.juggleHighscoreEasy;
                HighscoreCalculator.juggleHighscoreEasy = HighscoreCalculator.calculateScore(array,score);
                break;
        }
    }

    public static void isTopSpeedScore(Score score, Difficulty difficulty)
    {
        Score[] array;
        switch(difficulty)
        {
            case EASY:
                array = HighscoreCalculator.speedHighscoreEasy;
                HighscoreCalculator.speedHighscoreEasy = HighscoreCalculator.calculateScore(array,score);
                break;
            case MEDIUM:
                array = HighscoreCalculator.speedHighscoreMedium;
                HighscoreCalculator.speedHighscoreMedium = HighscoreCalculator.calculateScore(array,score);
                break;
            case HARD:
                array = HighscoreCalculator.speedHighscoreHard;
                HighscoreCalculator.speedHighscoreHard = HighscoreCalculator.calculateScore(array,score);
                break;
            case MAJOR:
                array = HighscoreCalculator.speedHighscoreMajor;
                HighscoreCalculator.speedHighscoreMajor = HighscoreCalculator.calculateScore(array,score);
                break;
            default:
                array = HighscoreCalculator.speedHighscoreEasy;
                HighscoreCalculator.speedHighscoreEasy = HighscoreCalculator.calculateScore(array,score);
                break;
        }
    }

    private static Score[] calculateScore(Score[] scorelist, Score score)
    {
        Score[] var = new Score[5];
        int rank = 0;
        boolean happendYet = false;
        for(int i = 0; i< scorelist.length; i++)
        {
            var[i] = scorelist[i];
        }

        for(int i = 0; i< scorelist.length;i++)
        {   if(score.score<scorelist[i].score && score.name.matches(scorelist[i].name)){
            break;
            }
            else if(score.score >= scorelist[i].score && !happendYet)
            {
                var[i]=score;
                boolean matched = false;
                for(int y= i+1; y< var.length;y++)
                {
                    if(score.name.matches(scorelist[y-1].name)){
                        matched = true;
                     }
                     else if(!matched) {
                        var[y] = scorelist[y - 1];
                     }
                     else{
                        var[y] = scorelist[y];
                    }
                }
                rank = i+1;
                happendYet = true;
            }
        }
        return var;
    }
}