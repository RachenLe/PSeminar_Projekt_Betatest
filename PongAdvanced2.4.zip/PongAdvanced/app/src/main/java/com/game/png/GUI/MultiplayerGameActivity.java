package com.game.png.GUI;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.game.png.Main.FadingSpeed;
import com.game.png.Main.GameModes.GameMode;
import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.MultiplayerUtil.ClientTask;
import com.game.png.Main.MultiplayerUtil.MultiplayerBroadcastReceiver;
import com.game.png.Main.MultiplayerUtil.MultiplayerGame;
import com.game.png.Main.MultiplayerUtil.P2pManagement;
import com.game.png.Main.MultiplayerUtil.ServerTask;
import com.game.png.Main.SoundManager;
import com.game.png.R;

import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;

public class MultiplayerGameActivity extends Activity implements Serializable
{
    public GamePanel panel;
    public LinearLayout bottomBar;
    public Button leave, pause;
    public LinearLayout layout;
    public int sizeX, sizeY;
    public int panelWidth, panelHeight;
    public static ServerTask server;
    public static ClientTask client;
    public MultiplayerBroadcastReceiver receiver;
    public View.OnClickListener pauseOne, pauseTwo;
    private boolean cameFromLinkedActivity;
    private boolean changingToLinkedActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = this.getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(R.layout.activity_muliplayer_game);

        this.cameFromLinkedActivity = (boolean) this.getIntent().getSerializableExtra("cameFromLinkedActivity");

        Display display = this.getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        this.sizeX = size.x;
        this.sizeY = size.y;

        this.bottomBar = this.findViewById(R.id.BottomBar);
        this.bottomBar.setBackgroundColor(Color.DKGRAY);

        this.leave = this.findViewById(R.id.leave);
        this.pause = this.findViewById(R.id.pause);

        this.pauseOne = new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                pause();
                pause.setText("Resume");
                pause.setOnClickListener(pauseTwo);
            }
        };

        this.pauseTwo =  new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                resume();
                pause.setText("Pause");
                pause.setOnClickListener(pauseOne);
            }
        };

        this.leave.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                leave();
            }
        });

        this.pause.setOnClickListener(this.pauseOne);
        this.panelWidth = this.sizeX;
        this.panelHeight = this.sizeY - this.bottomBar.getHeight();
        this.layout = this.findViewById(R.id.LinearOne);

        receiver = new MultiplayerBroadcastReceiver(P2pManagement.manager, P2pManagement.channel,this);
        panel = new MultiplayerGame(this,client);
        this.layout.addView(this.panel,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));


        if(!this.cameFromLinkedActivity)
        {
            SoundManager.terminate();
            SoundManager.setContext(this.getApplicationContext());
            SoundManager.startMusic(R.raw.game, true);
        }

        else
        {
            SoundManager.fadeThrowMusic(R.raw.game, FadingSpeed.FAST, true);
        }
    }



    public void win( int points)
    {
        final MultiplayerGameActivity thisg = this;
        this.bottomBar.post(new Runnable()
        {
            public void run()
            {
                bottomBar.removeAllViews();
                TextView text = new TextView(thisg);
                text.setTextSize(30);
                text.setText("    CONGRATULATIONS");
                text.setTextColor(Color.WHITE);
                bottomBar.addView(text, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
            }
        });

    }



    public void loose( int points)
    {
        final MultiplayerGameActivity thisg = this;
        this.bottomBar.post(new Runnable()
        {
            public void run()
            {
                bottomBar.removeAllViews();
                TextView text = new TextView(thisg);
                text.setTextSize(30);
                text.setText("    NEXT TIME...");
                text.setTextColor(Color.WHITE);
                bottomBar.addView(text, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
            }
        });
        // send points to server

    }

    public void pause()
    {
        this.panel.pause();
    }

    public void resume()
    {
        this.panel.resume();
    }

    public void leave()
    {
        this.panel.thread.setRunning(false);
        this.changingToLinkedActivity = true;
        this.panel.thread.interrupt();
        Intent intent =new Intent(this, SinglePlayerSelection.class);
        intent.putExtra("cameFromLinkedActivity", true);
        intent.putExtra("cameFromGameActivity", true);
        this.startActivity(intent);
        this.panel.thread.interrupt();
        this.finish();
    }
    @Override
    protected void onResume()
    {
        super.onResume();
        if(!this.cameFromLinkedActivity)
        {
            SoundManager.resumeMusic();
        }
        View decorView = this.getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        if (this.panel.thread != null)
        {
            if (this.panel.thread.getState() == Thread.State.TERMINATED)
            {
                this.startActivity(new Intent(this, SinglePlayerSelection.class));
                this.finish();
            }
        }
    }
    @Override
    protected void onPause()
    {
        super.onPause();
        if(!this.changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
            this.cameFromLinkedActivity = false;
        }
    }}
