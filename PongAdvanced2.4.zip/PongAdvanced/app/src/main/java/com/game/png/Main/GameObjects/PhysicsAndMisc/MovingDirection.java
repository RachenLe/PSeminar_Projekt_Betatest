package com.game.png.Main.GameObjects.PhysicsAndMisc;


public enum MovingDirection
{
    LEFT, LEFTUP, LEFTDOWN, RIGHT, RIGHTUP, RIGHTDOWN, UP, DOWN, NOTMOVING
}