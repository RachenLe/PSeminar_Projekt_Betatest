package com.game.png.Main.MultiplayerUtil;


import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Color;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.WifiP2pManager.ActionListener;
import android.net.wifi.p2p.WifiP2pManager.Channel;
import android.net.wifi.p2p.WifiP2pManager.ConnectionInfoListener;
import android.net.wifi.p2p.WifiP2pManager.DnsSdServiceResponseListener;
import android.net.wifi.p2p.WifiP2pManager.DnsSdTxtRecordListener;
import android.net.wifi.p2p.WifiP2pManager.GroupInfoListener;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest;
import android.widget.EditText;
import android.widget.LinearLayout.LayoutParams;

import com.game.png.GUI.P2pDetection;
import com.game.png.GUI.P2pRoomDisplay;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MultiplayerBroadcastReceiver extends BroadcastReceiver
{
    public WifiP2pManager manager;
    public Channel channel;
    public WifiP2pDevice hostDevice;
    public InetAddress groupOwnerAdress;
    private WifiP2pDevice thisDevice;
    private WifiP2pDnsSdServiceRequest serviceRequest;
    private ActionListener connectionListener, groupListner;

    public ArrayList<WifiP2pDevice> aPeers = new ArrayList<WifiP2pDevice>();
    public ArrayList<WifiP2pConfig> aConfigs = new ArrayList<WifiP2pConfig>();
    public ArrayList<HashMap> aGroupDevices = new ArrayList<>();
    public ArrayList<WifiP2pDevice> groupMembers = new ArrayList<>();

    public Activity activity;

    public boolean isHost ;
    public boolean disconnectCompleted;
    public boolean groupEntered;
    private boolean isPartOfGroup;

    public ConnectionInfoListener infoListener = new ConnectionInfoListener()
    {
        @Override
        public void onConnectionInfoAvailable(WifiP2pInfo info)
        {
            MultiplayerBroadcastReceiver.this.groupOwnerAdress = info.groupOwnerAddress;
            if (info.groupFormed)
            {

                if (info.isGroupOwner)
                {
                    MultiplayerBroadcastReceiver.this.isHost = true;
                    MultiplayerBroadcastReceiver.this.isPartOfGroup = true;

                }

                else
                {
                    MultiplayerBroadcastReceiver.this.isHost = false;
                    MultiplayerBroadcastReceiver.this.isPartOfGroup = true;
                }

            }
            else{
                MultiplayerBroadcastReceiver.this.isHost = false;
                MultiplayerBroadcastReceiver.this.isPartOfGroup = true;
            }
            if(info == null){
                MultiplayerBroadcastReceiver.this.isHost = false;
                MultiplayerBroadcastReceiver.this.isPartOfGroup = true;
            }

        }
    };

    public GroupInfoListener groupInfo = new GroupInfoListener() {
        @Override
        public void onGroupInfoAvailable(WifiP2pGroup group) {
            if(group != null) {
                MultiplayerBroadcastReceiver.this.hostDevice = group.getOwner();
                MultiplayerBroadcastReceiver.this.manager.requestConnectionInfo(MultiplayerBroadcastReceiver.this.channel, MultiplayerBroadcastReceiver.this.infoListener);
                Object[] deviceArray = group.getClientList().toArray();
                MultiplayerBroadcastReceiver.this.groupMembers.clear();
                for (int i = 0; i < deviceArray.length; i++) {
                    MultiplayerBroadcastReceiver.this.groupMembers.add(((WifiP2pDevice) deviceArray[i]));


                }
                P2pManagement.hostAdress = MultiplayerBroadcastReceiver.this.groupOwnerAdress;

            }
            else{
                MultiplayerBroadcastReceiver.this.manager.requestGroupInfo(MultiplayerBroadcastReceiver.this.channel, MultiplayerBroadcastReceiver.this.groupInfo);
            }

        }
    };
    private WifiP2pDnsSdServiceInfo GroupServiceInfo;


    public MultiplayerBroadcastReceiver(WifiP2pManager manager, Channel channel, Activity activity)
    {
        this.manager = manager;
        this.channel = channel;
        this.activity = activity;
        this.isPartOfGroup = false;
        this.isHost = false;
        this.disconnectCompleted = false;


    }

    @Override
    public void onReceive(Context context, Intent intent)
    {
        String action = intent.getAction();
        this.thisDevice = intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE);
        if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action))
        {
            int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
            if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED)
            {

            }

            else
            {

            }

            if(this.activity.getClass() == P2pRoomDisplay.class){
                ((P2pRoomDisplay) this.activity).requestGroupInfo();
            }

        }

        else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action))
        {

        }
        else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action))
        {
            //manager.requestConnectionInfo(channel, infoListener);
            this.manager.requestGroupInfo(this.channel, this.groupInfo);

        }

        else if (WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION.equals(action))
        {
            this.manager.requestGroupInfo(this.channel, this.groupInfo);
        }

    }



    public void connectToGroup(int position)
    {
        WifiP2pConfig config = this.aConfigs.get(position);
        this.hostDevice = this.aPeers.get(position);
        this.manager.connect(this.channel, config, (this.connectionListener = new ActionListener() {
            @Override
            public void onSuccess()
            {
                MultiplayerBroadcastReceiver.this.manager.requestConnectionInfo(MultiplayerBroadcastReceiver.this.channel, MultiplayerBroadcastReceiver.this.infoListener);
                MultiplayerBroadcastReceiver.this.groupEntered = true;

            }

            @Override
            public void onFailure(int code)
            {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }
            }
        }));
    }




    public void createGroup()
    {
        try {
            this.disconnect();
            this.groupEntered = false;
            this.manager.requestConnectionInfo(this.channel, this.infoListener);
            if (!this.isPartOfGroup) {
                Builder alertDialog = new Builder(this.activity);
                alertDialog.setTitle("Create Group");
                alertDialog.setMessage("Set Groupname");
                final EditText input = new EditText(this.activity);
                LayoutParams lp = new LayoutParams(
                        LayoutParams.MATCH_PARENT,
                        LayoutParams.MATCH_PARENT);
                input.setTextColor(Color.BLACK);
                input.setLayoutParams(lp);
                alertDialog.setView(input);
                alertDialog.setPositiveButton("CONFIRM",
                        new OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                MultiplayerBroadcastReceiver.this.manager.createGroup(MultiplayerBroadcastReceiver.this.channel, (MultiplayerBroadcastReceiver.this.groupListner = new ActionListener() {
                                    @Override
                                    public void onSuccess() {
                                        MultiplayerBroadcastReceiver.this.manager.requestGroupInfo(MultiplayerBroadcastReceiver.this.channel, MultiplayerBroadcastReceiver.this.groupInfo);
                                        MultiplayerBroadcastReceiver.this.groupEntered = true;
                                    }

                                    @Override
                                    public void onFailure(int code) {
                                        if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                                            System.out.println("P2pUnsupported");
                                        } else if (code == WifiP2pManager.ERROR) {

                                            System.out.println("Error");
                                        } else if (code == WifiP2pManager.BUSY) {

                                            System.out.println("BUSY");
                                        }
                                        System.out.println("fail");
                                    }
                                }));


                                String groupName = input.getText().toString();
                                if (groupName.trim().length() <= 0 || groupName.matches("group") || groupName.matches("Group")) {
                                    groupName = "SNEXEFEX";
                                }

                                WifiManager wifiMan = (WifiManager) (MultiplayerBroadcastReceiver.this.activity.getApplicationContext()
                                        .getSystemService(Context.WIFI_SERVICE));
                                WifiInfo wifiInf = wifiMan.getConnectionInfo();
                                int ipAddress = wifiInf.getIpAddress();
                                String ip = String.format("%d.%d.%d.%d", (ipAddress & 0xff), (ipAddress >> 8 & 0xff),
                                        (ipAddress >> 16 & 0xff), (ipAddress >> 24 & 0xff));


                                Map record = new HashMap<String, String>();
                                record.put("groupname", groupName);
                                record.put("grouphost", ip);
                                record.put("public", "yes");


                                MultiplayerBroadcastReceiver.this.GroupServiceInfo = WifiP2pDnsSdServiceInfo.newInstance("Room", "GameRoom", record);

                                MultiplayerBroadcastReceiver.this.manager.addLocalService(MultiplayerBroadcastReceiver.this.channel, MultiplayerBroadcastReceiver.this.GroupServiceInfo, new ActionListener() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override
                                    public void onFailure(int code) {
                                        if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                                            System.out.println("P2pUnsupported");
                                        } else if (code == WifiP2pManager.ERROR) {

                                            System.out.println("Error");
                                        } else if (code == WifiP2pManager.BUSY) {

                                            System.out.println("BUSY");
                                        }
                                    }
                                });


                            }
                        });

                alertDialog.show();
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        catch(Error e){
            e.printStackTrace();
        }

    }




    public void disconnect()
    {
        this.groupEntered = false;
        this.disconnectCompleted = false;
        if (this.isOrderedBroadcast()) {
            this.abortBroadcast();
            this.clearAbortBroadcast();
        }
        P2pManagement.clearManager(this.manager);
        this.isPartOfGroup = false;
        this.disconnectCompleted = true;
    }



    public void discoverGroupServices(){
        this.aGroupDevices.clear();
        final HashMap<Object, Object> Groupdata = new HashMap<Object, Object>();

        DnsSdTxtRecordListener txtListener = new DnsSdTxtRecordListener() {
            @Override

            public void onDnsSdTxtRecordAvailable(
                    String fullDomain, Map record, WifiP2pDevice device) {
                Groupdata.put("GroupName", record.get("groupname"));
                Groupdata.put("IP", record.get("grouphost"));
                Groupdata.put("hostDevice", device );


            }

        };

        DnsSdServiceResponseListener servListener = new DnsSdServiceResponseListener() {
            @Override
            public void onDnsSdServiceAvailable(String instanceName, String registrationType,
                                                WifiP2pDevice resourceType) {
                System.out.println(instanceName);
                System.out.println(registrationType);
                 if(Groupdata.containsKey("GroupName")
                            && Groupdata.containsKey("hostDevice")&& Groupdata.containsKey("IP")){
                boolean addedYet = false;
                for (int i = 0; i < MultiplayerBroadcastReceiver.this.aGroupDevices.size(); i++) {
                    if (((WifiP2pDevice) (MultiplayerBroadcastReceiver.this.aGroupDevices.get(i).get("hostDevice"))).deviceAddress.matches(((WifiP2pDevice)Groupdata.get("hostDevice")).deviceAddress)) {
                        addedYet = true;
                        break;
                    }
                }
                if (!addedYet) {
                    MultiplayerBroadcastReceiver.this.aGroupDevices.add(Groupdata);
                    MultiplayerBroadcastReceiver.this.aPeers.add((WifiP2pDevice)Groupdata.get("hostDevice"));
                    WifiP2pConfig config = new WifiP2pConfig();
                    config.deviceAddress = ((WifiP2pDevice)Groupdata.get("hostDevice")).deviceAddress;
                    config.wps.setup = WpsInfo.PBC;
                    MultiplayerBroadcastReceiver.this.aConfigs.add(config);
                    ((P2pDetection) MultiplayerBroadcastReceiver.this.activity).showGroups(MultiplayerBroadcastReceiver.this.aGroupDevices);

                }
                }


            }
        };

        this.manager.setDnsSdResponseListeners(this.channel, servListener, txtListener);

        this.serviceRequest = WifiP2pDnsSdServiceRequest.newInstance();
        this.manager.addServiceRequest(this.channel, this.serviceRequest, new ActionListener()
        {
            @Override
            public void onSuccess() {
                ((P2pDetection) MultiplayerBroadcastReceiver.this.activity).showGroups(MultiplayerBroadcastReceiver.this.aGroupDevices);
            }

            @Override
            public void onFailure(int code) {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }
            }

        });

        this.manager.discoverServices(this.channel, new ActionListener() {

            @Override
            public void onSuccess() {
                if(MultiplayerBroadcastReceiver.this.activity.getClass() == P2pDetection.class){

                }

            }

            @Override
            public void onFailure(int code) {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }

            }

        });



    }

}