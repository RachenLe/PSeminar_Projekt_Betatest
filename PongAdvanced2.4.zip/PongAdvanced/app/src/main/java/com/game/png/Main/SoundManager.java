package com.game.png.Main;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;

import java.util.Timer;
import java.util.TimerTask;

public class SoundManager
{
    static MediaPlayer soundPlayer;
    static MediaPlayer musicPlayer;
    private static Context context;
    public static boolean musicOn, soundsOn;
    public static  boolean activated;
    public static float soundVolume, musicVolume;
    public static boolean fadingIn , fadedOut;




    public static void setContext(Context context)
    {
       SoundManager.context = context;

    }

    public static void startMusic( int music, boolean looping)
    {

        if(SoundManager.musicOn)
        {
            if (SoundManager.musicPlayer != null)
            {
                if (SoundManager.musicPlayer.isPlaying())
                {
                    SoundManager.musicPlayer.pause();
                    SoundManager.musicPlayer.stop();
                    SoundManager.musicPlayer.release();
                }
                SoundManager.musicPlayer = null;
            }
            SoundManager.musicPlayer = MediaPlayer.create(SoundManager.context, music);
            SoundManager.musicPlayer.start();
            SoundManager.musicPlayer.setLooping(looping);
            SoundManager.musicPlayer.setVolume(SoundManager.musicVolume, SoundManager.musicVolume);
        }
    }

    public static void stopMusic()
    {
        if(SoundManager.musicPlayer != null)
        {
            if(SoundManager.musicPlayer.isPlaying())
            {
                SoundManager.musicPlayer.pause();
                SoundManager.musicPlayer.stop();
                SoundManager.musicPlayer.release();
            }
            SoundManager.musicPlayer = null;
        }
    }

    public static void pauseMusic()
    {
        if(SoundManager.musicPlayer != null)
        {
            if (SoundManager.musicPlayer.isPlaying())
            {
                SoundManager.musicPlayer.pause();
            }
        }
    }

    public static void resumeMusic()
    {
        if(SoundManager.musicOn)
        {
            if (SoundManager.musicPlayer != null)
            {
                if (!SoundManager.musicPlayer.isPlaying())
                {
                    SoundManager.musicPlayer.start();
                }
            }
        }
    }

    public static void playSound( int sound)
    {
        if(SoundManager.soundsOn)
        {
            if(SoundManager.soundPlayer == null)
            {
                SoundManager.soundPlayer = MediaPlayer.create(SoundManager.context, sound);
            }

            if(!SoundManager.soundPlayer.isPlaying())
            {
                SoundManager.soundPlayer.start();
                SoundManager.soundPlayer.setLooping(false);
                SoundManager.soundPlayer.setVolume(SoundManager.soundVolume, SoundManager.soundVolume);
            }
        }
    }

    public static void stopSounds()
    {
        if(SoundManager.soundPlayer != null)
        {
            if(SoundManager.soundPlayer.isPlaying())
            {
                SoundManager.soundPlayer.pause();
                SoundManager.soundPlayer.stop();
                SoundManager.soundPlayer.release();
            }

            SoundManager.soundPlayer = null;
        }
    }

    public static void pauseSounds()
    {
        if(SoundManager.soundPlayer != null)
        {
            if (SoundManager.soundPlayer.isPlaying())
            {
                SoundManager.soundPlayer.pause();
            }
        }
    }

    public static void resumeSounds()
    {
        if(SoundManager.soundsOn)
        {
            if (SoundManager.soundPlayer != null)
            {
                if (!SoundManager.soundPlayer.isPlaying())
                {
                    SoundManager.soundPlayer.start();
                }
            }
        }
    }

    public static void terminate()
    {
        SoundManager.stopMusic();
        SoundManager.stopSounds();
        SoundManager.musicPlayer = null;
        SoundManager.soundPlayer = null;
    }

    public static void setSoundVolume(float volume)
    {
        SoundManager.soundVolume = volume;
        if(SoundManager.soundPlayer !=null)
        {
            SoundManager.soundPlayer.setVolume(volume, volume);
        }
    }

    public static void setMusicVolume(float volume)
    {
        SoundManager.musicVolume = volume;
        if(SoundManager.musicPlayer !=null)
        {
            SoundManager.musicPlayer.setVolume(volume, volume);
        }
    }

    public static void setMusicOn(boolean on)
    {
        SoundManager.musicOn = on;
        if(on != true)
        {
            SoundManager.stopMusic();
        }
    }

    public static void setSoundsOn(boolean on)
    {
        SoundManager.soundsOn = on;
        if(on != true)
        {
            SoundManager.stopSounds();
        }
    }

    public static void fadeInMusic(int music, FadingSpeed fadingSpeed, boolean looping)
    {
        if(SoundManager.musicOn) {
            int speed;
            SoundManager.fadingIn = true;
            switch (fadingSpeed) {
                case FAST:
                    speed = 5;
                    break;
                case MODERATE:
                    speed = 10;
                    break;
                case SLOW:
                    speed = 25;
                    break;
                default:
                    speed = 10;
                    break;
            }

            if (SoundManager.musicPlayer == null) {
                SoundManager.musicPlayer = MediaPlayer.create(SoundManager.context, music);
            } else {
                if (SoundManager.musicPlayer.isPlaying()) {
                    SoundManager.stopMusic();
                }

                SoundManager.musicPlayer = MediaPlayer.create(SoundManager.context, music);
            }

            SoundManager.musicPlayer.setVolume(0, 0);
            SoundManager.musicPlayer.start();
            SoundManager.musicPlayer.setLooping(looping);
            final Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                private float currentVolume;

                @Override
                public void run() {
                    if (this.currentVolume < SoundManager.musicVolume) {
                        this.currentVolume = (float) (this.currentVolume + 0.01);
                        try {
                            SoundManager.musicPlayer.setVolume(this.currentVolume, this.currentVolume);
                        } catch (Exception e) {

                        }
                    } else {
                        SoundManager.fadingIn = false;
                        timer.cancel();
                        timer.purge();
                    }
                }
            }, 0, speed);
        }
    }

    public static void fadeOutMusic(FadingSpeed fadingSpeed)
    {
        if(SoundManager.musicOn) {
            SoundManager.fadedOut = false;
            final FadingSpeed ffadingSpeed = fadingSpeed;
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    if (SoundManager.musicPlayer != null) {
                        if (SoundManager.musicPlayer.isPlaying()) {
                            int speed;
                            switch (ffadingSpeed) {
                                case FAST:
                                    speed = 5;
                                    break;
                                case MODERATE:
                                    speed = 10;
                                    break;
                                case SLOW:
                                    speed = 25;
                                    break;
                                default:
                                    speed = 10;
                                    break;
                            }

                            SoundManager.musicPlayer.setVolume(SoundManager.musicVolume, SoundManager.musicVolume);
                            final Timer timer = new Timer();
                            timer.schedule(new TimerTask() {
                                private float currentVolume = SoundManager.musicVolume;

                                @Override
                                public void run() {
                                    if (this.currentVolume > 0) {
                                        this.currentVolume = (float) (this.currentVolume - 0.01);
                                        if (this.currentVolume < 0) {
                                            this.currentVolume = 0;
                                        }

                                        try {
                                            SoundManager.musicPlayer.setVolume(this.currentVolume, this.currentVolume);
                                        } catch (Exception e) {

                                        }

                                    } else {
                                        SoundManager.stopMusic();
                                        SoundManager.fadedOut = true;
                                        timer.cancel();
                                        timer.purge();
                                    }
                                }
                            }, 0, speed);
                        }
                    }
                }

            });
            while (SoundManager.fadingIn) {
                try {
                    Thread.sleep(20);
                } catch (Exception e) {
                    continue;
                }
            }
            thread.start();
        }
    }

    public static void fadeThrowMusic(int music, final FadingSpeed fadingSpeed, final boolean looping) {
        if (SoundManager.musicOn) {
            final int fmusic = music;
            final FadingSpeed ffadingSpeed = fadingSpeed;
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    int speed;

                    switch (ffadingSpeed) {
                        case FAST:
                            speed = 5;
                            break;
                        case MODERATE:
                            speed = 10;
                            break;
                        case SLOW:
                            speed = 25;
                            break;
                        default:
                            speed = 10;
                            break;
                    }

                    if (SoundManager.musicPlayer != null) {
                        if (SoundManager.musicPlayer.isPlaying()) {
                            final Timer timer = new Timer();
                            timer.schedule(new TimerTask() {
                                private float currentVolume = SoundManager.musicVolume;

                                @Override
                                public void run() {
                                    if (this.currentVolume > 0) {
                                        this.currentVolume = (float) (this.currentVolume - 0.01);
                                        if (this.currentVolume < 0) {
                                            this.currentVolume = 0;
                                        }

                                        try {
                                            SoundManager.musicPlayer.setVolume(this.currentVolume, this.currentVolume);
                                        } catch (Exception e) {

                                        }
                                    } else {
                                        SoundManager.stopMusic();
                                        SoundManager.fadeInMusic(fmusic, fadingSpeed, looping);
                                        timer.cancel();
                                        timer.purge();
                                    }
                                }
                            }, 0, speed);
                        }
                    }
                }
            });

            while (SoundManager.fadingIn) {
                try {
                    Thread.sleep(20);
                } catch (Exception e) {
                    continue;
                }
            }
            thread.start();
        }
    }
}