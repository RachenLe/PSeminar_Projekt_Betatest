package com.game.png.Main.GameObjects.PhysicsAndMisc;

import com.game.png.Main.GameObjects.GameObject;

public abstract class Collider
{

    private GameObject partnerOne, partnerTwo;

    public Collider(GameObject partnerOne, GameObject partnerTwo)
    {
        this.partnerOne = partnerOne;
        this.partnerTwo = partnerTwo;
        this.partnerOne.addCollider(this);
        this.partnerTwo.addCollider(this);
    }

    public void check()
    {
        if (this.partnerOne.activated==true && this.partnerTwo.activated == true)
        {

            if (this.partnerOne.detectCollision(this.partnerTwo))
            {
                this.partnerOne.collisionDetectedInThisStep = true;
                this.partnerTwo.collisionDetectedInThisStep = true;
                if(this.partnerTwo.bounceAble &!this.partnerOne.bounceAble)
                {
                    this.partnerTwo.checkAndReflectByObstacle(this.partnerOne);
                }

                else if(!(this.partnerTwo.bounceAble) && this.partnerOne.bounceAble)
                {
                    this.partnerOne.checkAndReflectByObstacle(this.partnerTwo);
                }

                else
                {
                    this.partnerTwo.checkAndReflectByObstacle(this.partnerOne);
                    this.partnerOne.checkAndReflectByObstacle(this.partnerTwo);
                }
            }
        }
    }

    public void deleteCollider()
    {
        this.partnerOne.removeCollider(this);
        this.partnerTwo.removeCollider(this);
        this.partnerOne = null;
        this.partnerTwo = null;
    }

    public Collider containsObject(GameObject obj)
    {
        if(partnerTwo == obj || partnerOne == obj)
        {
            return this;
        }

        else
        {
            return null;
        }
    }
}