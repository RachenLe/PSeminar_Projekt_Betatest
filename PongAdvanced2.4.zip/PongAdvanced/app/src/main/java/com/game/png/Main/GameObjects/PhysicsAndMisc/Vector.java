package com.game.png.Main.GameObjects.PhysicsAndMisc;

public class Vector
{
    public float x,y;
    public boolean yReflected, xReflected;
    public double slope;

    public Vector(float x, float y)
    {
        this.x = x;
        this.y = y;
        if (x != 0)
        {
            this.slope = y/x;
        }
    }


    public void reflectX()
    {
        x = -this.x;
        this.xReflected = !this.xReflected;
    }

    public void reflectY()
    {
        y = -this.y;
        this.yReflected = !this.yReflected;
    }

}