package com.game.png.Main.GameModes;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import com.game.png.GUI.Game;
import com.game.png.Main.GameObjects.Paddl;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;

public class SpeedMode extends GamePanel
{
    private float startX, startY;
    private GameThread thread ;
    private Paddl player;
    public Ball ball;
    public int pointsPlayer, lifes;
    private boolean ballOnStartPosition = true;
    private boolean justStarted =true;
    private int bounces;
    public float maxBallSpeed;

    public SpeedMode(Game context , Difficulty difficulty)
    {
        super(context, difficulty);
        this.getHolder().addCallback(this);
    }
    @Override
    public void onCreation()
    {
        this.thread = new GameThread(this.getHolder(),this);
        this.player = new Paddl(500 * this.widthFaktor, 1300* this.heightFaktor, 300 * this.widthFaktor, 50* this.heightFaktor, GamePanel.objectColor, this);
        this.ball = new Ball(100* this.heightFaktor, 100* this.heightFaktor, 20* this.widthFaktor, GamePanel.objectColor, this, this.difficulty);
        this.addObject(this.ball);
        this.addObject(this.player);
        this.colliders.add(new Collider(SpeedMode.this.player, SpeedMode.this.ball){});
        this.ball.activate();
        this.player.activate();

        switch(this.difficulty)
        {
            case MAJOR:
                this.startX = 40* this.widthFaktor;
                this.startY = 80* this.heightFaktor;
                break;

            case EASY:
                this.startX = 10* this.widthFaktor;
                this.startY = 30* this.heightFaktor;
                break;

            case HARD:
                this.startX = 30* this.widthFaktor;
                this.startY = 60* this.heightFaktor;
                break;

            case MEDIUM:
                this.startX = 20* this.widthFaktor;
                this.startY = 45* this.heightFaktor;
                break;
        }
        this.maxBallSpeed = this.startX + this.startY;
    }

    @Override
    public void onTouch(MotionEvent event)
    {

        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                if (this.won || this.gameOver)
                {
                    this.endedOnClick = true;
                }

            case MotionEvent.ACTION_MOVE:
                if (!this.won && !this.gameOver)
                {
                    boolean ballRelease = false;
                    //Der Hauptpointer berührt den Ball
                    if(event.getX() < this.getWidth() / 2 + this.ball.width() + 20 && event.getX() > this.getWidth() / 2 - this.ball.width() - 20
                            && event.getY() < this.getHeight() / 2 + this.ball.height() + 20 && event.getY() > this.getHeight() / 2 - this.ball.height() - 20
                            && this.ballOnStartPosition)
                    {
                        ballRelease = true;
                    }

                    //ein anderer Pointer berührt den Ball

                    try
                    {
                        int pointer = event.getPointerId(event.getPointerCount()-1);
                        if (((event.getX(pointer) < this.getWidth() / 2 + this.ball.width() + 20 && event.getX(pointer) > this.getWidth() / 2 - this.ball.width() - 20
                                && event.getY(pointer) < this.getHeight() / 4 + this.ball.height() + 20 && event.getY(pointer) > this.getHeight() / 4 - this.ball.height() - 20))
                                && this.ballOnStartPosition)
                        {
                            ballRelease = true;
                        }

                    }

                    catch (Exception e)
                    {

                    }

                    //der Ball wurde berührt und lag in der Startposition
                    if(ballRelease)
                    {
                        this.ball.resetStartVelocity();
                        this.ball.calculateMoving(this.startX, this.startY);
                        this.ball.moveable = true;
                        this.ballOnStartPosition = false;
                    }

                    //der Player wurde durch den Hauptpointer verschoben
                    if (event.getPointerCount() == 1)
                    {
                        this.player.setPosition((int) event.getX(), this.getHeight() - 150);
                    }
                }

                break;
            case MotionEvent.ACTION_UP:

                break;
        }

    }
    @Override
    public void extendedDraw(Canvas canvas)
    {
        Paint miscPaint = new Paint();
        miscPaint.setColor(GamePanel.objectColor);
        miscPaint.setTextSize(this.widthFaktor *125);
        Rect rect = new Rect();
        int ppE;
        if (this.pointsPlayer > 99)
        {
            ppE = 3;
        } else if (this.pointsPlayer > 9)
        {
            ppE = 2;
        } else {
            ppE = 1;
        }

        miscPaint.getTextBounds("" + this.pointsPlayer + "", 0, ppE, rect);
        float helloHeight = rect.height();
        rect = new Rect();
        float byeWidth = rect.width();
        float byeHeight = rect.height();
        canvas.drawText("" + this.pointsPlayer + "", 15, ((getHeight() / 4) + (helloHeight * 3 / 2)), miscPaint);
        canvas.drawLine(0, this.getHeight() / 4, this.getWidth(), this.getHeight() / 4, miscPaint);
    }

    @Override
    public void updateSpc()
    {

        if(this.justStarted)
        {
            this.ball.setPosition(this.getWidth()/2, this.getHeight()/4);
            this.justStarted =false;
            this.ballOnStartPosition =true;
        }
        if(this.player.centerY() < this.getHeight()-150 || this.player.centerY() > this.getHeight()-150 )
        {
            this.player.setPosition(this.player.point.x, this.getHeight()-150);
        }

        boolean special = false;
        switch(this.ball.checkBoundCollision())
        {
            case RIGHT:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                break;

            case LEFT:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                break;

            case LEFTTOP:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                special = true;

            case RIGHTTOP:
                if(!special)
                {
                    this.ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                }

            case TOP:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.UP);
                this.pointsPlayer++;
                this.bounces++;
                break;

            case LEFTBOTTOM:
                this.ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                special = true;

            case RIGHTBOTTOM:
                if(!special)
                {
                    this.ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                }

            case BOTTOM:
                this.ball.moveable = false;
                this.ball.setPosition(this.getWidth()/2, this.getHeight()/2);
                this.loose(true);
                break;

            default:
                break;
        }

        if(this.maxBallSpeed < (this.ball.movingX* this.ball.countsOfMoving)+(this.ball.movingY* this.ball.countsOfMoving))
        {
            this.maxBallSpeed = (this.ball.movingX* this.ball.countsOfMoving)+(this.ball.movingY* this.ball.countsOfMoving);
        }
    }

    @Override
    public int getScore()
    {
        int score = Math.round(this.pointsPlayer);
        if(score<10)
        {
            score = 10;
        }
        return score;
    }
}