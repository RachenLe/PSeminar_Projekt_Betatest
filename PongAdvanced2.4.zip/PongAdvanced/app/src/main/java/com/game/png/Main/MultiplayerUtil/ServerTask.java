package com.game.png.Main.MultiplayerUtil;

import android.os.AsyncTask;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;


public class ServerTask extends AsyncTask<Void,Void,Void> {
    int port;
    private ServerSocket serverSocket;

    private ServerTaskType type;
    private Object sendData;
    private Thread TaskThread;
    private boolean searching;
    private int MessageCode;
    private boolean sending;
    private ArrayList<Socket> ClientList = new ArrayList<>();

    public ServerTask(int port) {
        this.port = port;

    }

    @Override
    protected Void doInBackground(Void... voids) {

        try {
            serverSocket = new ServerSocket(port);
            searching = false;
            new Thread() {
                @Override
                public void run() {
                    long startTime;
                    long timeMillis = 1000 / 20;
                    long waitTime;
                    long targetTime = 1000 / 20;
                    while(true) {
                        startTime = System.nanoTime();
                        timeMillis = (System.nanoTime() - startTime) / 1000000;
                        waitTime = targetTime - timeMillis;
                        if (sending) {
                            for (Socket socket : ClientList) {
                                try {
                                    DataOutputStream dOut = new DataOutputStream(socket.getOutputStream());

                                    dOut.writeInt(MessageCode);
                                    dOut.flush();

                                } catch (Exception e) {
                                    continue;
                                }
                            }
                            sending = false;
                        }
                        if(isCancelled()){
                            break;
                        }
                        try {
                            if (waitTime > 0) {
                                Thread.sleep(waitTime);
                            }
                        } catch (Exception e) {
                            continue;
                        }
                    }
                }
            }.start();
            for (; ; ) {



                if (isCancelled()) {
                    break;
                }
                if (!searching) {
                    searching = true;
                    (TaskThread = new Thread() {
                        @Override
                        public void run() {
                            try {
                                final Socket client = serverSocket.accept();

                                    ClientList.add(client);
                                    new clientThread(client).start();


                                searching = false;
                            } catch (Exception e) {

                            }
                        }
                    }).start();
                }


            }
            System.out.println("Server closed");
            serverSocket.close();
            return null;

        }
        catch (IOException io){
            io.printStackTrace();
            return null;
        }




    }



    private void stop(){
       TaskThread.interrupt();
    }



    private enum ServerTaskType{
        SEND_OBJECT, SEND_MESSAGE
    }
    class clientThread extends Thread{
        Socket socket;
        public boolean sleeping;
        clientThread(Socket client){
            this.socket = client;
        }

        @Override
        public void run() {
            long startTime;
            long timeMillis = 1000 / 20;
            long waitTime;
            long targetTime = 1000 / 20;
            while (true) {
                if(isCancelled()){
                    break;
                }
                //Sleep Loop if Thread is to fast
                startTime = System.nanoTime();
                timeMillis = (System.nanoTime() - startTime) / 1000000;
                waitTime = targetTime - timeMillis;

                try{
                    DataInputStream dIn = new DataInputStream(socket.getInputStream());

                    boolean done = false;
                    try {
                        while (!done) {

                            byte messageType = dIn.readByte();



                        }



                    }
                    catch (Exception e){

                    }

                }
                catch (Exception e){
                    e.printStackTrace();
                }
                try {
                    if (waitTime > 0) {
                        this.sleeping = true;
                        Thread.sleep(waitTime);
                        this.sleeping = false;
                    }
                } catch (Exception e) {
                    continue;
                }

            }

        }

    }

    public void sendServerMessage(int MessageCode){
        this.MessageCode = MessageCode;
        sending = true;
    }


}