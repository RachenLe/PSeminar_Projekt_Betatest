package com.game.png.Main.MultiplayerUtil;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;

public abstract class ClientTask extends AsyncTask<Void,Void,Void> {
    int port;
    InetAddress host;
    private String Message;
    private boolean sending;
    private Socket socket;

    public ClientTask(int port, InetAddress host) {
        this.port = port;
        this.host = host;


    }

    @Override
    protected Void doInBackground(Void... voids) {
        long startTime;
        long timeMillis = 1000 / 20;
        long waitTime;
        long targetTime = 1000 / 20;
        try {
             socket = new Socket(host, port);
            if(!socket.isConnected()){
                socket.connect(new InetSocketAddress(host, port));
            }


            for(;;){
                startTime = System.nanoTime();
                timeMillis = (System.nanoTime() - startTime) / 1000000;
                waitTime = targetTime - timeMillis;
                try {
                    if (waitTime > 0) {

                        Thread.sleep(waitTime);

                    }
                } catch (Exception e) {
                    continue;
                }
                if(isCancelled()){
                    break;
                }



                    new Thread() {
                        @Override
                        public void run() {
                            try {
                            DataInputStream dIn = new DataInputStream(socket.getInputStream());
                            int messageType = dIn.readInt();

                            onReceive(messageType);
                            } catch (Exception e) {
                            }
                        }

                    }.start();





            }
            System.out.println("clientClosed");
            socket.close();
            return null;

        }
        catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public abstract void onReceive(int code);

    public void sendMessage(String Message){
        try {
            DataOutputStream dout = new DataOutputStream(socket.getOutputStream());
            dout.writeByte(1);
            dout.writeUTF(Message);
            dout.flush();
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }

    public void sendBallData(float x, float y, float movingX, float movingY){
        try {
            DataOutputStream dout = new DataOutputStream(socket.getOutputStream());
            dout.writeByte(2);
            dout.writeFloat(x);
            dout.flush();

            dout.writeByte(3);
            dout.writeFloat(y);
            dout.flush();

            dout.writeByte(4);
            dout.writeFloat(movingX);
            dout.flush();

            dout.writeByte(5);
            dout.writeFloat(movingY);
            dout.flush();

            dout.writeByte(6);
            dout.flush();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    public float[] receiveBall(){
        try {
            DataInputStream dIn = new DataInputStream(socket.getInputStream());
            byte code = dIn.readByte();
            boolean ended = false;
            float[] data = new float[3];
            while(!ended) {
                switch (code) {
                    case 2:
                        data[0] = dIn.readFloat();
                        break;
                    case 3:
                        data[1] = dIn.readFloat();
                        break;
                    case 4:
                        data[2] = dIn.readFloat();
                        break;
                    case 5:
                        data[3] = dIn.readFloat();
                        break;
                    case 6:
                        return data;
                    default:
                        ended = true;

                }
            }

        } catch (Exception e) {
        }
        return null;
    }


}