package com.game.png.Main.GameModes;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import com.game.png.GUI.Game;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;
import com.game.png.Main.GameObjects.Paddl;
import java.util.ArrayList;
import java.util.Random;

public class Juggle extends GamePanel
{
    private Paddl player;
    public ArrayList<Ball> balls = new ArrayList<Ball>();
    private Ball ball;
    public int ballsOnField =1;
    private boolean justStarted =true, ballOnStartPosition = true;
    private float startX, startY;
    private int hits;
    private float minADD, maxADD;
    private int mustHold;
    private float maxBallSpeed;
    private int lostBalls;
    private int neededHits;

    public Juggle(Game context, Difficulty difficulty )
    {
        super(context, difficulty);
        this.getHolder().addCallback(this);
        this.thread = new GameThread(this.getHolder(),this);
    }

    @Override
    public void onCreation()
    {
        this.player = new Paddl(500 * this.widthFaktor, 1300* this.heightFaktor, 300 * this.widthFaktor, 50* this.heightFaktor, GamePanel.objectColor, this);
        this.ball = new Ball(100* this.heightFaktor, 100* this.heightFaktor, 20* this.widthFaktor, GamePanel.objectColor, this, this.difficulty);
        this.addBall(this.ball);
        this.addObject(this.player);
        this.player.activate();
        switch(this.difficulty)
        {
            case MAJOR:
                this.startX = 22* this.widthFaktor;
                this.startY = 40* this.heightFaktor;
                this.maxADD = 15* this.widthFaktor;
                this.minADD = 0* this.widthFaktor;
                this.mustHold = 10;
                this.neededHits = 5;
                break;

            case EASY:
                this.startX = 2* this.widthFaktor;
                this.startY = 17* this.heightFaktor;
                this.maxADD = 3* this.widthFaktor;
                this.minADD = -3* this.widthFaktor;
                this.mustHold = 3;
                this.neededHits = 2;
                break;

            case HARD:
                this.startX = 15* this.widthFaktor;
                this.startY = 30* this.heightFaktor;
                this.maxADD = 10* this.widthFaktor;
                this.minADD = -3* this.widthFaktor;
                this.mustHold = 7;
                this.neededHits =4;
                break;

            case MEDIUM:
                this.startX = 8* this.widthFaktor;
                this.startY = 22* this.heightFaktor;
                this.maxADD = 7* this.widthFaktor;
                this.minADD = -5* this.widthFaktor;
                this.mustHold = 5;
                this.neededHits = 3;
                break;
        }
        this.maxBallSpeed = this.startX + this.startY;
    }

    @Override
    public void onTouch(MotionEvent event)
    {

        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                if (this.won || this.gameOver)
                {
                    this.endedOnClick = true;
                }

            case MotionEvent.ACTION_MOVE:
                if (this.justStarted)
                {
                    this.justStarted = false;
                }

                if (!this.won && !this.gameOver)
                {
                    if (this.ballOnStartPosition)
                    {
                        this.ball.calculateMoving(this.startX, this.startY);
                        this.ballOnStartPosition = false;
                    }

                    else
                    {
                        this.player.setPosition((int) event.getX(), this.getHeight() - 150);
                    }
                }

                break;

            case MotionEvent.ACTION_UP:
                break;
        }
    }

    @Override
    public void extendedDraw(Canvas canvas)
    {
        Paint miscPaint = new Paint();
        miscPaint.setColor(GamePanel.objectColor);
        miscPaint.setTextSize(125* this.widthFaktor);
        canvas.drawText("" + this.ballsOnField + "", 15, 200, miscPaint);
        if(this.justStarted)
        {
            Rect rect = new Rect();
            int ppb;
            if(this.mustHold >9)
            {
                ppb = 2;
            }

            else
            {
                ppb = 1;
            }

            miscPaint.setTextSize(75* this.widthFaktor);
            miscPaint.getTextBounds("JUGGLE " + this.mustHold + " BALLS",0,13+ppb,rect);
            int width = rect.width();
            canvas.drawText("JUGGLE " + this.mustHold + " BALLS", this.getWidth()/2-width/2, this.getHeight()/2, miscPaint);
            canvas.drawLine(0, this.getHeight() / 4, this.getWidth(), this.getHeight() / 4, miscPaint);
        }
    }

    @Override
    public void updateSpc()
    {
        if(this.justStarted)
        {
            this.ball.setPosition(this.getWidth()/2, this.getHeight()/4);
        }

        if(this.player.centerY() < this.getHeight()-150 || this.player.centerY() > this.getHeight()-150 )
        {
            this.player.setPosition(this.player.point.x, this.getHeight()-150);
        }

        for(int i = 0; i< this.balls.size(); i++)
        {
            boolean special = false;
            switch (this.balls.get(i).checkBoundCollision())
            {
                case RIGHT:
                    this.balls.get(i).checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                    break;
                case LEFT:
                    this.balls.get(i).checkAndReflectByMovingDirection(MovingDirection.LEFT);
                    break;
                case LEFTTOP:
                    this.balls.get(i).checkAndReflectByMovingDirection(MovingDirection.LEFT);
                    special = true;
                case RIGHTTOP:
                    if(!special)
                    {
                        this.balls.get(i).checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                    }

                case TOP:
                    this.balls.get(i).checkAndReflectByMovingDirection(MovingDirection.UP);
                    if(this.balls.get(i) == this.ball)
                    {
                        this.hits++;
                        Random random=new Random();
                        float randomNumber=(0-random.nextInt(400));
                        if (this.hits % this.neededHits == 0)
                        {
                            Ball ball = new Ball(this.getWidth() / 2+ randomNumber, this.getHeight() / 2+randomNumber, 20* this.widthFaktor, GamePanel.objectColor, this, this.difficulty);
                            this.addBall(ball);
                            randomNumber = (random.nextInt((int) this.maxADD)- this.minADD);
                            float X = this.startX + randomNumber;
                            float Y = this.startY + randomNumber;
                            ball.calculateMoving(X, Y);
                            this.ballsOnField++;
                        }
                    }

                    break;
                case BOTTOM:
                case LEFTBOTTOM:
                case RIGHTBOTTOM:
                    this.balls.get(i).moveable = false;
                    if(this.balls.get(i)== this.ball && this.balls.size()>1)
                    {
                        this.ball = this.balls.get(i+1);
                    }

                    this.removeBall(this.balls.get(i));
                    this.ballsOnField--;
                    this.lostBalls++;

                    break;

            }
            if(this.maxBallSpeed < (this.ball.movingX* this.ball.countsOfMoving)+(this.ball.movingY* this.ball.countsOfMoving)){
                this.maxBallSpeed = (this.ball.movingX* this.ball.countsOfMoving)+(this.ball.movingY* this.ball.countsOfMoving);
            }
        }

        if(this.ballsOnField <= 0)
        {
            this.loose(false);
        }

        if(this.ballsOnField > this.mustHold)
        {
            this.win(true);
        }
    }

    public void addBall(Ball ball)
    {
        this.balls.add(ball);
        this.addObject(ball);
        this.colliders.add(new Collider(Juggle.this.player, ball){});
        ball.activate();
    }

    public void removeBall(Ball ball)
    {
        this.balls.remove(ball);
        this.removeObject(ball);
        for (int i = 0; i< this.colliders.size(); i++)
        {
            Collider collider = this.colliders.get(i).containsObject(ball);
            if(collider != null)
            {
                collider.deleteCollider();
                this.colliders.remove(collider);
            }
        }
    }

    @Override
    public int getScore()
    {
        lostBalls = lostBalls+1;
        //calculate with botpoints, time and maxBallspeed
        int score = Math.round((100*(maxBallSpeed/10))/lostBalls);
        if(score<0)
        {
            score = 0;
        }
        return score;
    }
}