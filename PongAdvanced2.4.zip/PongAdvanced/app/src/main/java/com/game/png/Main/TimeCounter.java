package com.game.png.Main;

import java.util.Timer;
import java.util.TimerTask;

public class TimeCounter
{
    private Timer timer;
    private TimerTask task;
    private int totalTimeMillis;
    private boolean paused;

    public void start()
    {
        this.totalTimeMillis =0;
        this.paused = false;
        this.timer = new Timer();
        this.task = new TimerTask()
        {
            @Override
            public void run()
            {
                if(!TimeCounter.this.paused)
                {
                    TimeCounter.this.totalTimeMillis++;
                }
            }
        };

        this.timer.schedule(this.task,0,1);
    }

    public void pause()
    {
        this.paused = true;
    }

    public void resume()
    {
        this.paused = false;
    }

    public int getEndTime()
    {
        this.timer.cancel();
        this.timer.purge();
        return this.totalTimeMillis;
    }
}