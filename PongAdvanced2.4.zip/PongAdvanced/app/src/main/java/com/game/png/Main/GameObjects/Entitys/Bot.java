package com.game.png.Main.GameObjects.Entitys;

import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.Paddl;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import java.util.ArrayList;

public class Bot extends Paddl
{
    public Paddl paddl;
    public Difficulty difficulty;
    public ArrayList balls = new ArrayList<Ball>();
    private float movingSpeed;
    private float randomSpeedChange;

    public Bot(float x, float y, float width, float height, int color, GamePanel context, Difficulty difficulty)
    {
        super(x,y,width,height,color, context);
        this.difficulty = difficulty;
    }

    @Override
    public void activate()
    {
        super.activate();
        switch(this.difficulty)
        {

            case HARD:
                this.movingSpeed = 25* this.context.widthFaktor;
                break;
            case EASY:
                this.movingSpeed = 9* this.context.widthFaktor ;
                break;
            case MEDIUM:
                this.movingSpeed = 17* this.context.widthFaktor ;
                break;
            case MAJOR:
                this.movingSpeed = 32* this.context.widthFaktor;
                break;
        }

        for(int i = 0; i< this.context.gameObjects.size(); i++)
        {
            if(this.context.gameObjects.get(i).getClass() == Ball.class)
            {
                this.balls.add(this.context.gameObjects.get(i));
            }
        }
    }

    @Override
    public void update()
    {
        super.update();
        Ball target = this.nearestBall();
        this.randomSpeedChange = (float)((Math.random()* this.movingSpeed)-(double) this.movingSpeed /(double)2);
         switch(target.movingDirection)
         {
             case UP:
             case LEFTUP:
             case RIGHTUP:
                 if(target.centerX()< centerX())
                 {
                     if(centerX()> width()/2 +1 )
                     {
                         if (this.movingSpeed > (centerX() - target.centerX()))
                         {
                             this.move(-(int) (centerX() - target.centerX()), 0);
                         }

                         else
                         {
                             this.move(-this.movingSpeed - this.randomSpeedChange, 0);
                         }
                     }

                     else
                     {
                         this.setPosition((int)(width()/2), point.y );
                     }
                 }

                 if(target.centerX()> centerX())
                 {
                     if(centerX()< this.context.getWidth()- width()/2 - 1 )
                     {
                        if(this.movingSpeed > (target.centerX()- centerX()))
                        {
                            this.move((int)(target.centerX()- centerX()), 0);
                         }

                         else
                         {
                             this.move(this.movingSpeed + this.randomSpeedChange,0);
                         }
                     }

                     else
                     {
                         this.setPosition((int)(this.context.getWidth()- width()/2), point.y );
                     }
                 }
                 break;
             default:
                 if(centerX()< this.context.getWidth()/2-50)
                 {
                     this.move(this.movingSpeed + this.randomSpeedChange,0);
                 }

                 else if(centerX() > this.context.getWidth()/2+50)
                 {
                     this.move(-this.movingSpeed - this.randomSpeedChange,0);
                 }
                 break;
         }
    }

    private Ball nearestBall()
    {
            Ball nearest = (Ball) this.balls.get(0);
            int nearestDistance = (int)nearest.centerY();
            for(int i = 1; i< this.balls.size(); i++){
                Ball selected = (Ball) this.balls.get(i);
                int selectedDistance = (int)selected.centerY();
                if(selectedDistance<nearestDistance)
                {
                    nearestDistance=selectedDistance;
                    nearest = selected;
                }
            }
            return nearest;
    }

    @Override
    public void delete()
    {
        super.delete();
        this.balls = null;
        this.difficulty = null;
    }
}