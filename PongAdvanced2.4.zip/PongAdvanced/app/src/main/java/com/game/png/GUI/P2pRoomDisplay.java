package com.game.png.GUI;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.game.png.Main.MultiplayerUtil.ClientTask;
import com.game.png.Main.MultiplayerUtil.MultiplayerBroadcastReceiver;
import com.game.png.Main.MultiplayerUtil.P2pManagement;
import com.game.png.Main.MultiplayerUtil.ServerMessage;
import com.game.png.Main.MultiplayerUtil.ServerTask;
import com.game.png.Main.SoundManager;
import com.game.png.R;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;


public class P2pRoomDisplay extends Activity implements Serializable {

    public boolean cameFromLinkedActivity;
    public boolean changingToLinkedActivity;
    public WifiP2pManager manager;
    public WifiP2pManager.Channel channel;
    public IntentFilter intentFilter;
    public ListView listView;
    public ArrayAdapter adapter;
    private MultiplayerBroadcastReceiver receiver;
    private boolean registered = false;
    private boolean changingToP2pActivity = false;
    private boolean isHost;
    private Timer requestTimer;
    private boolean requesting;
    private ServerTask server;
    private ClientTask localClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        isHost = (boolean) getIntent().getSerializableExtra("isOwner");
        if (isHost) {
            setContentView(R.layout.activity_room_owner_display);
        } else {
            setContentView(R.layout.activity_room_member_display);
        }

        manager = P2pManagement.manager;
        channel = P2pManagement.channel;
        if (!registered) {
            receiver = new MultiplayerBroadcastReceiver(manager, channel, this);
            registered = true;
        }

        intentFilter = new IntentFilter();
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        registerReceiver(receiver, intentFilter);

        listView = findViewById(R.id.connectedClients);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        listView.setAdapter(adapter);

        cameFromLinkedActivity = (boolean) getIntent().getSerializableExtra("cameFromLinkedActivity");
        if (!requesting) {
            requestGroupInfo();
            requesting = true;
        }

        startSockets();
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (!cameFromLinkedActivity) {
            SoundManager.resumeMusic();
        }
        if (!registered) {
            registerReceiver(receiver, intentFilter);
            registered = true;
        }
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        if (!requesting) {
            requestGroupInfo();
            requesting = true;
        }
    }

    /* unregister the broadcast receiver */


    @Override
    protected void onPause() {

        super.onPause();
        if (!changingToLinkedActivity) {
            SoundManager.pauseMusic();
            cameFromLinkedActivity = false;

        }
        if (receiver != null) {
            unregisterReceiver(receiver);
            registered = false;

        }
        if (requesting) {
            requestTimer.cancel();
            requestTimer.purge();
            requesting = false;
        }


    }

    @Override
    protected void onDestroy() {
        if (!changingToP2pActivity) {
            receiver.disconnect();
            if (receiver.isOrderedBroadcast()) {
                receiver.abortBroadcast();
                receiver.clearAbortBroadcast();
            }
        }
        if (registered && receiver != null) {
            registered = false;
            unregisterReceiver(receiver);
        }
        if (requesting) {
            requestTimer.cancel();
            requestTimer.purge();
            requesting = false;
        }
        if (localClient != null) {
            localClient.cancel(true);
        }
        if (server != null) {
            server.cancel(true);
        }
        super.onDestroy();
    }


    public void back(View view) {
        if(server != null){
            server.sendServerMessage(ServerMessage.SHUTDOWN);
        }
        changingToP2pActivity = false;
        changingToLinkedActivity = true;
        Intent intent = new Intent(P2pRoomDisplay.this, P2pDetection.class);
        intent.putExtra("cameFromLinkedActivity", true);
        startActivity(intent);
        finish();
    }


    public void requestGroupInfo() {
        requestTimer = new Timer();
        final Context context = this;
        requestTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                manager.requestGroupInfo(channel, receiver.groupInfo);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.clear();
                        if (receiver.hostDevice != null) {
                            adapter.add(receiver.hostDevice.deviceAddress + "       HOST");
                        }
                        for (WifiP2pDevice device : receiver.groupMembers) {
                            adapter.add(device.deviceAddress + "       CLIENT");

                        }
                    }
                });

            }
        }, 0, 1000);

    }

    public void startSockets() {
        Thread thread = new Thread() {
            @Override
            public void run() {
                while(receiver.groupOwnerAdress == null){
                    try {
                        sleep(50);
                    }
                    catch(Exception e){
                        continue;
                    }
                }
                if (isHost) {
                    try {
                        if (server == null) {
                            server = new ServerTask(8888);
                            server.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
                if (localClient == null) {
                    try {
                        localClient = new ClientTask(8888, receiver.groupOwnerAdress){

                            @Override
                            public void onReceive(int code) {
                                switch(code){
                                    case ServerMessage.SHUTDOWN:
                                        try {
                                            changingToP2pActivity = false;
                                            changingToLinkedActivity = true;
                                            Intent intent = new Intent(P2pRoomDisplay.this, P2pDetection.class);
                                            intent.putExtra("cameFromLinkedActivity", true);
                                            startActivity(intent);
                                            finish();
                                        }
                                        catch (Exception e){

                                        }
                                        break;
                                    case ServerMessage.PAUSE:
                                        break;
                                    case ServerMessage.STARTGAME:
                                        System.out.println("Start Game");
                                        break;


                                }
                            }
                        };
                        localClient.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }
        };
        thread.start();


    }

    @Override
    protected void finalize() {

    }

    public void startGame(View view){
        server.sendServerMessage(ServerMessage.STARTGAME);
    }


}
