package com.game.png.Main.GameObjects;

import android.graphics.Canvas;
import android.graphics.RectF;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Vector;
import com.game.png.Main.GameObjects.PhysicsAndMisc.FloatPoint;
import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameObjects.PhysicsAndMisc.SurfaceBorders;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import com.game.png.R.raw;

import java.util.ArrayList;

public abstract class GameObject extends RectF
{
    public Vector vector = new Vector(0,0);
    public FloatPoint point;
    public MovingDirection movingDirection;
    public boolean moveable, bounceAble;
    private int splitedVelocity =1, varVel;
    public float movingX, movingY, startMX , startMY;
    //Colliding parameters
    public boolean activated;
    public ArrayList<Collider> colliders = new ArrayList<Collider>();
    public boolean collisionDetectedInThisStep;
    // Misc parameters
    public GamePanel context;
    public int countsOfMoving =1;
    public boolean movingHasChanged;

    public GameObject(float x, float y, float width, float height, GamePanel context)
    {
       super(x,y,x+width,y+height);
        point = new FloatPoint(x,y);
        this.moveable = true;
       this.context = context;
    }

    public void calculateMoving(float movingX , float movingY)
    {
        this.vector = null;
        this.vector = new Vector(movingX, movingY);
       this.movingY = movingY;
       this.movingX = movingX;
        this.movingHasChanged = true;
    }

    public void resetStartVelocity()
    {
        this.startMY =0;
        this.startMX =0;
        this.splitedVelocity =0;
        this.countsOfMoving =1;
    }

    public void calculateCountsOfMoving()
    {
        //Die momentane Geschwindigkeit der Bewegung ist größer als 30 (könnte Kollisionsdetektionsproblem erzeugen)
        if(this.movingX <=-15|| this.movingX >=15|| this.movingY <=-15|| this.movingY >=15)
        {
            //übertragen der
            float varX;
            float varY;
            varX = this.startMX;
            varY = this.startMY;
            if (this.movingX < 0 && varX >0)
            {
                varX = varX;
                varX = varX - this.movingX;
            }

            else if(this.movingX > 0 && varX<0)
            {
                varX =0-varX;
                varX = varX + this.movingX;
            }

            else
            {
                varX = varX+ this.movingX;
            }

            if (this.movingY < 0  && varY >0)
            {
                varY = varY;
                varY = varY - this.movingY;
            }

            else if(this.movingY > 0 && varY<0)
            {
                varY =0-varY;
                varY = varY + this.movingY;
            }

            else
            {
                varY = varY+ this.movingY;
            }

            if(varY<0)
            {
                this.startMY = 0-varY;
            }

            else
            {
                this.startMY = varY;
            }

            if(varX<0)
            {
                this.startMX = 0-varX;
            }

            else
            {
                this.startMX = varX;
            }

            if ((this.startMX / 15 > this.splitedVelocity && this.startMX > this.startMY))
            {
                this.countsOfMoving = Math.round(this.startMX / 5);
                if (this.movingX > 0)
                {
                    this.movingX = 5;
                }

                else if (this.movingX < 0)
                {
                    this.movingX = -5;
                }

                this.movingY = this.movingY / this.countsOfMoving;
            }

            else if ((this.startMY / 15 > this.splitedVelocity && this.startMY > this.startMX))
            {
                this.countsOfMoving = Math.round(this.startMY / 5);
                if (this.movingY > 0)
                {
                    this.movingY = 5;
                }

                else if (this.movingY < 0)
                {
                    this.movingY = -5;
                }

                this.movingX = this.movingX / this.countsOfMoving;
            }

            else
            {
                this.countsOfMoving = 1;
            }
            this.calculateMoving(this.movingX, this.movingY);
            this.splitedVelocity++;
        }
    }
    //position management
    public void move()
    {
        this.point.x = this.point.x + this.vector.x;
        this.point.y = this.point.y+ this.vector.y;
        this.updatePosition();
    }

    public void move(float x, float y)
    {
        this.calculateMoving(x,y);
        this.move();
        this.movingHasChanged = true;
    }

    public void setPosition(float x, float y)
    {
        if(x+ this.width()/2 < this.context.getWidth()&& x- this.width()/2 > 0) {
            this.point.x = x;
        }
        if(y+ this.height()/2 < this.context.getHeight() && y- this.height()/2 > 0)
            this.point.y = y;
        this.updatePosition();
    }

    private void updatePosition()
    {
        //updaten der position um positionswechsel intern der GameObject Klasse an die Superklasse zu übertragen
        this.set(this.point.x - this.width()/2, this.point.y - this.height()/2, this.point.x + this.width()/2, this.point.y + this.height()/2);

        //definiert die Bewegungsrichtung relativ zum Spielfeld
        if(this.vector.x> 0)
        {
            //Der x-Wert des Vektors ist größer null also bewegt sich das Objekt nach rechts
            if(this.vector.y>0)
            {
                // der y-Wert des Vektors ist größer null also bewegt sich das Objekt nach unten
                this.movingDirection = MovingDirection.RIGHTDOWN;
            }

            else if(this.vector.y==0)
            {
                // der y-Wert des Vektors ist null es findet keine auf- oder Abwärtsbewegung statt
                this.movingDirection = MovingDirection.RIGHT;
            }

            else
            {
                // der y-Wert des Vektors ist kleiner null also bewegt sich das Objekt nach oben
                this.movingDirection = MovingDirection.RIGHTUP;
            }
        }

        else if(this.vector.x== 0)
        {
            //Der x-Wert des Vektors ist null es findet keine seitliche Bewegung statt
            if(this.vector.y>0)
            {
                // der y-Wert des Vektors ist größer null also bewegt sich das Objekt nach unten
                this.movingDirection = MovingDirection.DOWN;
            }
            else if(this.vector.y==0)
            {
                // der y-Wert des Vektors ist null es findet keine auf- oder Abwärtsbewegung statt
                this.movingDirection = MovingDirection.NOTMOVING;
            }

            else
            {
                // der y-Wert des Vektors ist kleiner null also bewegt sich das Objekt nach oben
                this.movingDirection = MovingDirection.UP;
            }
        }

        else
            {
            //Der x-Wert des Vektors ist kleiner null also bewegt sich das Objekt nach links
            if(this.vector.y>0)
            {
                // der y-Wert des Vektors ist größer null also bewegt sich das Objekt nach unten
                this.movingDirection = MovingDirection.LEFTDOWN;
            }

            else if(this.vector.y==0)
            {
                // der y-Wert des Vektors ist null es findet keine auf- oder Abwärtsbewegung statt
                this.movingDirection = MovingDirection.LEFT;
            }

            else
            {
                // der y-Wert des Vektors ist kleiner null also bewegt sich das Objekt nach oben
                this.movingDirection = MovingDirection.LEFTUP;
            }
        }
    }

    public void addCollider(Collider collider)
    {
        this.colliders.add(collider);
    }

    public void removeCollider(Collider collider)
    {
        this.colliders.remove(collider);
    }

    public boolean detectCollision(GameObject obstacle)
    {
        return RectF.intersects(this,obstacle);
    }

    public SurfaceBorders checkBoundCollision()
    {
        //Die y-Koordinate des Zentrums ist kleiner als die Hälfte der Höhe de Objekts
        // => das Objekt berührt die Oberseite des Spielfeldes
        if(centerY()< ((height()/2) +5) && !(centerX()> (this.context.getWidth()- (width()/2) -5)) && !(centerX()< ((width()/2) +5)))
        {
            //Top Border
            return SurfaceBorders.TOP;
        }
        //Die y-Koordinate des Zentrums ist größer als die Höhe Spielfeldes minus die Hälfte der Höhe
        // => das Objekt berührt die Unterseite des Spielfeldes
        else if(centerY()> (this.context.getHeight()- (height()/2) -5) && !(centerX()> (this.context.getWidth()- (width()/2) -5)) && !(centerX()< ((width()/2) +5)))
        {
            //Bottom Border
            return SurfaceBorders.BOTTOM;
        }
        //Die x-Koordinate des Zentrums ist keiner als die halbe Breite des Objekts
        // => das Objekt berührt die Linke seite des Spielfeldes
        else if(centerX()< ((width()/2) +5)&& !(centerY()< ((height()/2) +5)) && !(centerY()> (this.context.getHeight()- (height()/2) -5)))
        {
            //Left Border
            return SurfaceBorders.LEFT;
        }

        //Die x-Koordinate des Zentrums ist größer als die Breite des Spielfelds minus die halbe Breite der Figur
        //=> Das Objekt berührt die rechte Seite des Spielfelds
        else if(centerX()> (this.context.getWidth()- (width()/2) -5)&& !(centerY()< ((height()/2) +5)) && !(centerY()> (this.context.getHeight()- (height()/2) -5)))
        {
            //Right Bordder
            return SurfaceBorders.RIGHT;
        }

        //Die x-Koordinate des Zentrums ist größer als die Breite des Spielfelds minus die halbe Breite der Figur
        //=> Das Objekt berührt die rechte Seite des Spielfelds
        //Die y-Koordinate des Zentrums ist größer als die Höhe Spielfeldes minus die Hälfte der Höhe
        // => das Objekt berührt die Unterseite des Spielfeldes
        else if(centerX()> (this.context.getWidth()- (width()/2) -5) && centerY()> (this.context.getHeight()- (height()/2) -5))
        {
          //TOP and Right Border
            return SurfaceBorders.RIGHTBOTTOM;
        }

        //Die x-Koordinate des Zentrums ist größer als die Breite des Spielfelds minus die halbe Breite der Figur
        //=> Das Objekt berührt die rechte Seite des Spielfelds
        //Die y-Koordinate des Zentrums ist kleiner als die Hälfte der Höhe de Objekts
        // => das Objekt berührt die Oberseite des Spielfeldes
        else if(centerX()> (this.context.getWidth()- (width()/2) -5) && centerY()< ((height()/2) +5))
        {
            //Bottom and Right Border
            return SurfaceBorders.RIGHTTOP;
        }

        //Die x-Koordinate des Zentrums ist keiner als die halbe Breite des Objekts
        // => das Objekt berührt die Linke seite des Spielfeldes
        //Die y-Koordinate des Zentrums ist größer als die Höhe Spielfeldes minus die Hälfte der Höhe
        // => das Objekt berührt die Unterseite des Spielfeldes
        else if(centerX()< ((width()/2) +5) && centerY()> (this.context.getHeight()- (height()/2) -5))
        {
            //Bottom and Left Border
            return SurfaceBorders.LEFTBOTTOM;
        }

        //Die x-Koordinate des Zentrums ist keiner als die halbe Breite des Objekts
        // => das Objekt berührt die Linke seite des Spielfeldes
        //Die y-Koordinate des Zentrums ist kleiner als die Hälfte der Höhe des Objekts
        // => das Objekt berührt die Oberseite des Spielfeldes
        else if(centerX()< ((width()/2) +5) && centerY()< ((height()/2) +5))
        {
            //Top and Right Border
            return SurfaceBorders.LEFTTOP;
        }
        else
        {
            //keine Seite wird berührt
            return SurfaceBorders.NONE;
        }
    }

    public void checkAndReflectByMovingDirection(MovingDirection direction)
    {
        switch(direction)
        {
            case UP:
                switch(movingDirection)
                {
                    case LEFTUP:
                    case RIGHTUP:
                    case UP:
                        vector.reflectY();
                        SoundManager.playSound(raw.pong);
                        break;
                }

                break;
            case DOWN:
                switch(movingDirection)
                {
                    case LEFTDOWN:
                    case RIGHTDOWN:
                    case DOWN:
                        vector.reflectY();
                        SoundManager.playSound(raw.pong);
                        break;
                }

                break;
            case LEFT:
                switch(movingDirection)
                {
                    case LEFTUP:
                    case LEFTDOWN:
                    case LEFT:
                        vector.reflectX();
                        SoundManager.playSound(raw.pong);
                        break;
                }

                break;
            case RIGHT:

                switch(movingDirection)
                {
                    case RIGHTUP:
                    case RIGHTDOWN:
                    case RIGHT:
                        vector.reflectX();
                        SoundManager.playSound(raw.pong);
                        break;
                }
                break;
        }
    }

    public boolean intersectsLeftSide(GameObject obstacle)
    {
        return obstacle.left < this.right && this.right < obstacle.left + 10 && this.bottom > obstacle.top && !(this.top > obstacle.bottom)
                && (this.movingDirection == MovingDirection.RIGHTDOWN || this.movingDirection == MovingDirection.RIGHTUP || this.movingDirection == MovingDirection.RIGHT);
    }

    public boolean intersectsRightSide(GameObject obstacle)
    {
        return obstacle.right > this.left && this.left > obstacle.right - 10 && this.bottom > obstacle.top && !(this.top > obstacle.bottom)
                && (this.movingDirection == MovingDirection.LEFTDOWN || this.movingDirection == MovingDirection.LEFTUP || this.movingDirection == MovingDirection.LEFT);
    }

    public boolean intersectsUpperSide(GameObject obstacle)
    {
        return obstacle.left + 10 < this.right && this.left < obstacle.right - 10 && this.bottom > obstacle.top && !(this.top > obstacle.bottom - obstacle.height() / 2)
                && (this.movingDirection == MovingDirection.RIGHTDOWN || this.movingDirection == MovingDirection.LEFTDOWN || this.movingDirection == MovingDirection.DOWN);
    }

    public boolean intersectsBottomSide(GameObject obstacle)
    {

        return obstacle.left + 10 < this.right && this.left < obstacle.right - 10 && this.bottom > obstacle.bottom && this.top > obstacle.top && this.top < obstacle.bottom
                && (this.movingDirection == MovingDirection.RIGHTUP || this.movingDirection == MovingDirection.LEFTUP || this.movingDirection == MovingDirection.UP);
    }

    public void checkAndReflectByObstacle( GameObject obstacle)
    {
        if(this.intersectsLeftSide(obstacle))
        {
            this.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
        }

        if(this.intersectsRightSide(obstacle))
        {
            this.checkAndReflectByMovingDirection(MovingDirection.LEFT);
        }

        if(this.intersectsUpperSide(obstacle))
        {
            this.checkAndReflectByMovingDirection(MovingDirection.DOWN);
        }

        if(this.intersectsBottomSide(obstacle))
        {
            this.checkAndReflectByMovingDirection(MovingDirection.UP);
        }
    }
    //rendering management
    public abstract void draw(Canvas canvas);

    public void update()
    {
        this.collisionDetectedInThisStep = false;
        this.updatePosition();
        movingX = this.vector.x;
        movingY = this.vector.y;
        if (this.movingHasChanged)
        {
            this.calculateCountsOfMoving();
            this.movingHasChanged = false;
        }
        for(int i = 0; i< this.colliders.size(); i++ )
        {
            this.colliders.get(i).check();
        }
    }

    public void delete()
    {
        this.vector = null;
        this.point = null;
        this.movingDirection = null;
        this.context = null;
        for(int i = 0; i< this.colliders.size(); i++)
        {
            this.colliders.get(i).deleteCollider();
        }
    }
}