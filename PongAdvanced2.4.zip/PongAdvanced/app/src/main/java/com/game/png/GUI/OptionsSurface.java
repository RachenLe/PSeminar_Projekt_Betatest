package com.game.png.GUI;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.game.png.Main.FadingSpeed;
import com.game.png.Main.GameDesign;
import com.game.png.Main.SavedDataPacket;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import com.game.png.R.id;
import com.game.png.R.layout;
import com.game.png.R.raw;

import java.io.Serializable;

public class OptionsSurface extends Activity implements Serializable
{
    boolean changingToLinkedActivity;
    static boolean cameFromLinkedActivity;
    public static boolean soundsActive, musicActive;
    public static float soundsVolume, musicVolume;
    public SeekBar soundVolumeBar, musicVolumeBar;
    public CheckBox activeSounds, activeMusic;
    public Button changeGameDesign;
    public Button apply;
    public boolean anythingChanged;
    private boolean applyed;
    private boolean originSoundsOn;
    private boolean originMusicOn;
    private float originMusicVolume;
    private float originSoundVolume;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = this.getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        this.getWindow().setFlags(LayoutParams.FLAG_FULLSCREEN, LayoutParams.FLAG_FULLSCREEN);
        this.setContentView(layout.activity_options_surface);

        this.anythingChanged = false;
        OptionsSurface.soundsVolume = SoundManager.soundVolume;
        OptionsSurface.musicVolume = SoundManager.musicVolume;
        OptionsSurface.musicActive = SoundManager.musicOn;
        OptionsSurface.soundsActive = SoundManager.soundsOn;

        this.originSoundVolume = SoundManager.soundVolume;
        this.originMusicVolume = SoundManager.musicVolume;
        this.originMusicOn = SoundManager.musicOn;
        this.originSoundsOn = SoundManager.soundsOn;

        this.musicVolumeBar = this.findViewById(id.musicSeekBar);
        this.soundVolumeBar = this.findViewById(id.soundSeekBar);

        this.activeSounds = this.findViewById(id.soundCheckBox);
        this.activeMusic = this.findViewById(id.musicCheckBox);

        this.changeGameDesign = this.findViewById(id.changeGameDesign);
        this.apply = this.findViewById(id.apply);

        this.musicVolumeBar.setProgress((int)(OptionsSurface.musicVolume *100));
        this.soundVolumeBar.setProgress((int)(OptionsSurface.soundsVolume *100));
        this.activeSounds.setChecked(OptionsSurface.soundsActive);
        this.activeMusic.setChecked(OptionsSurface.musicActive);

        this.musicVolumeBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                SoundManager.setMusicVolume(((float)progress/(float)100));
                OptionsSurface.musicVolume = SoundManager.musicVolume;
                OptionsSurface.this.anythingChanged = true;
                OptionsSurface.this.apply.setTextColor(GameDesign.getButtonColor());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {

            }
        });

        this.soundVolumeBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                SoundManager.setSoundVolume(((float)progress/(float)100));
                OptionsSurface.soundsVolume = SoundManager.soundVolume;
                OptionsSurface.this.anythingChanged = true;
                OptionsSurface.this.apply.setTextColor(GameDesign.getButtonColor());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {
                SoundManager.playSound(raw.pong);
            }
        });

        this.activeSounds.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SoundManager.setSoundsOn(isChecked);
                OptionsSurface.soundsActive = SoundManager.soundsOn;
                if(isChecked){
                    SoundManager.playSound(raw.pong);
                }
                OptionsSurface.this.anythingChanged = true;
                OptionsSurface.this.apply.setTextColor(GameDesign.getButtonColor());
            }
        });

        this.activeMusic.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SoundManager.setMusicOn(isChecked);
                if(isChecked){
                    SoundManager.fadeInMusic(raw.menu_music, FadingSpeed.FAST, true);
                }
                OptionsSurface.musicActive = SoundManager.musicOn;
                OptionsSurface.this.anythingChanged = true;
                OptionsSurface.this.apply.setTextColor(GameDesign.getButtonColor());
            }
        });

    }

    public void apply(View view)
    {
        if(this.anythingChanged)
        {
            (new SavedDataPacket(this.getApplicationContext())).save();
            this.apply.setTextColor(Color.rgb(180, 180, 180));
            this.applyed =true;
            this.originSoundVolume = SoundManager.soundVolume;
            this.originMusicVolume = SoundManager.musicVolume;
            this.originMusicOn = SoundManager.musicOn;
            this.originSoundsOn = SoundManager.soundsOn;
        }
    }

    public void back(View view){
        if(!this.applyed && this.anythingChanged)
        {
            new SavedDataPacket(this.getApplicationContext()).load();
            SoundManager.setSoundVolume(this.originSoundVolume);
            SoundManager.setMusicVolume(this.originMusicVolume);
            SoundManager.setMusicOn(this.originMusicOn);
            SoundManager.setSoundsOn(this.originSoundsOn);
        }
        this.changingToLinkedActivity = true;
        this.changingToLinkedActivity = true;
        Intent intent =new Intent(this, Menu.class);
        intent.putExtra("cameFromLinkedActivity", true);
        this.startActivity(intent);
        this.finish();
    }

    public void changeGameDesign(View v)
    {
        this.changingToLinkedActivity = true;
        Intent intent =new Intent(this, DesignSelection.class);
        intent.putExtra("cameFromLinkedActivity", true);
        this.startActivity(intent);
        this.finish();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if(!OptionsSurface.cameFromLinkedActivity)
        {
            SoundManager.resumeMusic();
        }
        else
        {
            OptionsSurface.cameFromLinkedActivity = false;
        }
        View decorView = this.getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if(!this.changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
        }
    }
}