package com.game.png.Main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class DataManager
{


    public static void save(String verzeichnis, String name, String DataFormat , Object obj)
    {

        try
        {
            File file = new File(verzeichnis+ name+DataFormat);
            if(file.exists())
            {
                file.delete();
            }

            FileOutputStream fiOuS = new FileOutputStream(new File(verzeichnis + name + DataFormat) );
            ObjectOutputStream ObOpS = new ObjectOutputStream(fiOuS);
            ObOpS.writeObject(obj);
            ObOpS.close();
            fiOuS.close();

        }

        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public static Object load(String directory)
    {
        try
        {
            Object Obj = null;
            FileInputStream fiInS = new FileInputStream(directory);
            ObjectInputStream ObInS = new ObjectInputStream(fiInS);
            Obj =  ObInS.readObject();
            ObInS.close();
            fiInS.close();
            return Obj;
        }

        catch(Exception e)
        {
            return null;
        }
    }
}