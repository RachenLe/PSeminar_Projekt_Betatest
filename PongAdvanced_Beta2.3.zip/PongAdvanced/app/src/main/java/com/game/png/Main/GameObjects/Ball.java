package com.game.png.Main.GameObjects;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;

public class Ball extends GameObject
{
    public float radius;
    public int color;
    public int countsOfCollision;
    public boolean speedGaining;
    public int lowerAdd, hAdd;
    public int maxSpeed;

    public Ball(float x, float y, float radius, int color, GamePanel gamepanel, Difficulty difficulty) {
        super(x, y, radius * 2, radius * 2, gamepanel);
        this.radius = radius;
        this.color = color;
        moveable = true;
        bounceAble = true;
        countsOfCollision = 0;
        speedGaining = true;

        switch(difficulty)
        {
            case EASY:
                lowerAdd = 2;
                hAdd =  4;
                maxSpeed = 60;
                break;
            case MEDIUM:
                lowerAdd = 3;
                hAdd =  5;
                maxSpeed = 80;
                break;
            case HARD:
                lowerAdd = 5;
                hAdd =  8;
                maxSpeed = 200;
                break;
            case MAJOR:
                lowerAdd = 7;
                hAdd =  10;
                maxSpeed = 300;
                break;
        }
    }

    @Override
    public void update()
    {
        super.update();
        //der Ball muss aktiviert sein
        if (activated)
        {
                  //Übertragen der Anzahl der Bewegungen pro Zug auf einen temporären Berechnungswert
                 int var = countsOfMoving;
                  // gleichmäßige Beschleunigung des Balls ist aktiviert(standardmäßig)
            if(movingY<maxSpeed && movingX< maxSpeed)
            {
                if (speedGaining)
                {
                    //ist der Ball einer gewissen Anzahl entsprechend mit einem Spieler kollidiert wird beschleunigt
                    if (countsOfCollision / 2 > 2)
                    {
                        //Übertragen der Bewegungswerte auf einen temporären Berechnungswert
                        float tempMx = movingX;
                        float tempMy = movingY;
                        //Wenn der Berechnungswert negativ ist wird er auf positiv gesetzt
                        if (tempMx < 0)
                        {
                            tempMx = -tempMx;
                        }

                        if (tempMy < 0)
                        {
                            tempMy = -tempMy;
                        }
                        //Der stärkere Berechnungswert erhält Vorzug bei der Beschleunigung
                        //=> Einfluss auf Schwierigkeit
                        if (tempMy >= tempMx)
                        {
                            //der Y-Bewegungswert ist überlegen
                            //der größere Faktor wird zum Y-Wert hinzu gerechnet
                            //negative Bewegungswerte müssen den Zusatz subtrahiert bekommen
                            if (movingY < 0)
                            {
                                movingY = movingY - (float) hAdd / (float) countsOfMoving;
                            }
                            //positive addiert
                            else if (movingY >= 0)
                            {
                                movingY = movingY + (float) hAdd / (float) countsOfMoving;
                            }
                            //der kleinere Faktor zum X-Wert
                            //negative Bewegungswerte müssen den Zusatz subtrahiert bekommen
                            if (movingX < 0)
                            {
                                movingX = movingX - (float) lowerAdd / (float) countsOfMoving;
                            }
                            //positive addiert
                            else if (movingY >= 0)
                            {
                                movingX = movingX + (float) lowerAdd / (float) countsOfMoving;
                            }
                        }

                        else
                        {
                            //der Fall in welchem der X-Wert überlegen ist verläuft analog
                            if (movingX < 0)
                            {
                                movingX = movingX - (float) hAdd / (float) countsOfMoving;
                            }

                            else if (movingX > 0)
                            {
                                movingX = movingX + (float) hAdd/ (float) countsOfMoving;
                            }

                            if (movingY < 0)
                            {
                                movingY = movingY - (float) lowerAdd / (float) countsOfMoving;
                            }

                            else if (movingY > 0)
                            {
                                movingY = movingY + (float) lowerAdd / (float) countsOfMoving;
                            }
                        }
                        //die neuen Bewegungswerte werden berechnet
                        calculateMoving(movingX, movingY);
                        //Die Kollisionszahl wird zurück gesetzt
                        countsOfCollision = 0;
                    }
                }
            }
             //der temporäre Berechnungswert stellt die Anazhl der Schritte in diesem Zug
            while (var > 0 && moveable)
             {
                   //der Ball wird um seine bereits gesetzten Bewegungswerte verschoben, welche unter Umständen nur einen
                   // Bruchteil der Gesamtbewegung des Zuges darstellen
                 move();
                  //die Kollision wird geprüft
                  for (int i = 0; i < colliders.size(); i++)
                  {
                      colliders.get(i).check();
                  }
                  //der Temporäre wert wird verkleinert ... Ein Schritt ist ausgeführt
                  var--;
             }

             //hat in diesem Zug eine Kollision statt gefunden
             if (collisionDetectedInThisStep)
             {
                 //dann wird die Anzahl der Kollisionen erhöht
                 countsOfCollision++;
             }
        }
    }

    public void deactivate()
    {
        activated = false;
    }

    public void activate()
    {
        activated = true;
    }

    @Override
    public void draw(Canvas canvas)
    {
        Paint paint = new Paint();
        paint.setColor(color);
        canvas.drawOval(this, paint);
    }

    public void delete()
    {

    }
}