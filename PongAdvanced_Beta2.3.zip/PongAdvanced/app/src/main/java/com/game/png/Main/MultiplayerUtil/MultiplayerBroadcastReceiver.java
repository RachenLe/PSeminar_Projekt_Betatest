package com.game.png.Main.MultiplayerUtil;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.wifi.WifiInfo;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.game.png.GUI.P2pDetection;
import com.game.png.GUI.P2pRoomDisplay;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MultiplayerBroadcastReceiver extends BroadcastReceiver
{
    public WifiP2pManager manager;
    public WifiP2pManager.Channel channel;
    public WifiP2pDevice hostDevice;
    public InetAddress groupOwnerAdress;
    private WifiP2pDevice thisDevice;
    private WifiP2pDnsSdServiceRequest serviceRequest;
    private WifiP2pManager.ActionListener connectionListener, groupListner;

    public ArrayList<WifiP2pDevice> aPeers = new ArrayList<WifiP2pDevice>();
    public ArrayList<WifiP2pConfig> aConfigs = new ArrayList<WifiP2pConfig>();
    public ArrayList<HashMap> aGroupDevices = new ArrayList<>();
    public ArrayList<WifiP2pDevice> groupMembers = new ArrayList<>();

    public Activity activity;

    public boolean isHost ;
    public boolean disconnectCompleted;
    public boolean groupEntered;
    private boolean isPartOfGroup;

    public WifiP2pManager.ConnectionInfoListener infoListener = new WifiP2pManager.ConnectionInfoListener()
    {
        @Override
        public void onConnectionInfoAvailable(WifiP2pInfo info)
        {
            groupOwnerAdress = info.groupOwnerAddress;
            if (info.groupFormed)
            {

                if (info.isGroupOwner)
                {
                    isHost = true;
                    isPartOfGroup = true;

                }

                else
                {
                    isHost = false;
                    isPartOfGroup = true;
                }

            }


        }
    };

    public WifiP2pManager.GroupInfoListener groupInfo = new WifiP2pManager.GroupInfoListener() {
        @Override
        public void onGroupInfoAvailable(WifiP2pGroup group) {
            if(group != null) {
                hostDevice = group.getOwner();
                manager.requestConnectionInfo(channel, infoListener);
                Object[] deviceArray = group.getClientList().toArray();
                groupMembers.clear();
                for (int i = 0; i < deviceArray.length; i++) {
                    groupMembers.add(((WifiP2pDevice) deviceArray[i]));


                }
                P2pManagement.hostAdress = groupOwnerAdress;

            }
            else{
                manager.requestGroupInfo(channel,groupInfo);
            }

        }
    };
    private WifiP2pDnsSdServiceInfo GroupServiceInfo;


    public MultiplayerBroadcastReceiver(WifiP2pManager manager, WifiP2pManager.Channel channel, Activity activity)
    {
        this.manager = manager;
        this.channel = channel;
        this.activity = activity;
        isPartOfGroup = false;
        isHost = false;
        disconnectCompleted = false;


    }

    @Override
    public void onReceive(Context context, Intent intent)
    {
        String action = intent.getAction();
        thisDevice = intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE);
        if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action))
        {
            int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
            if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED)
            {

            }

            else
            {

            }

            if(activity.getClass() == P2pRoomDisplay.class){
                ((P2pRoomDisplay)activity).requestGroupInfo();
            }

        }

        else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action))
        {

        }
        else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action))
        {
            //manager.requestConnectionInfo(channel, infoListener);
            manager.requestGroupInfo(channel, groupInfo);

        }

        else if (WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION.equals(action))
        {
            manager.requestGroupInfo(channel, groupInfo);
        }

    }



    public void connectToGroup(int position)
    {
        WifiP2pConfig config = aConfigs.get(position);
        hostDevice = aPeers.get(position);
        manager.connect(channel, config, (connectionListener= new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess()
            {
                manager.requestConnectionInfo(channel, infoListener);
                groupEntered = true;

            }

            @Override
            public void onFailure(int code)
            {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }
            }
        }));
    }




    public void createGroup()
    {
        groupEntered = false;
        if(!isPartOfGroup) {
            final AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
            alertDialog.setTitle("Create Group");
            alertDialog.setMessage("Set Groupname");
            final EditText input = new EditText(activity);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            input.setTextColor(Color.BLACK);
            input.setLayoutParams(lp);
            alertDialog.setView(input);
            alertDialog.setPositiveButton("CONFIRM",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            manager.createGroup(channel, (groupListner = new WifiP2pManager.ActionListener() {
                                @Override
                                public void onSuccess() {
                                    manager.requestGroupInfo(channel,groupInfo);
                                    groupEntered = true;
                                }

                                @Override
                                public void onFailure(int code) {
                                    if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                                        System.out.println("P2pUnsupported");
                                    }
                                    else if(code == WifiP2pManager.ERROR){

                                        System.out.println("Error");
                                    }
                                    else if(code == WifiP2pManager.BUSY){

                                        System.out.println("BUSY");
                                    }
                                    System.out.println("fail");
                                    disconnect();
                                }
                            }));


                            String groupName = input.getText().toString();
                            if (groupName.trim().length() <= 0 || groupName.matches("group") || groupName.matches("Group")) {
                                groupName = "SNEXEFEX";
                            }

                            android.net.wifi.WifiManager wifiMan = (android.net.wifi.WifiManager)(activity.getApplicationContext()
                                    .getSystemService(Context.WIFI_SERVICE));
                            WifiInfo wifiInf = wifiMan.getConnectionInfo();
                            int ipAddress = wifiInf.getIpAddress();
                            String ip = String.format("%d.%d.%d.%d", (ipAddress & 0xff),(ipAddress >> 8 & 0xff),
                                    (ipAddress >> 16 & 0xff),(ipAddress >> 24 & 0xff));


                            Map record = new HashMap<String,String>();
                            record.put("groupname", groupName);
                            record.put("grouphost", ip );
                            record.put("public", "yes");


                            GroupServiceInfo = WifiP2pDnsSdServiceInfo.newInstance("Room", "GameRoom", record);

                            manager.addLocalService(channel, GroupServiceInfo, new WifiP2pManager.ActionListener() {
                                @Override
                                public void onSuccess() {

                                }

                                @Override
                                public void onFailure(int code) {
                                    if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                                        System.out.println("P2pUnsupported");
                                    }
                                    else if(code == WifiP2pManager.ERROR){

                                        System.out.println("Error");
                                    }
                                    else if(code == WifiP2pManager.BUSY){

                                        System.out.println("BUSY");
                                    }
                                    disconnect();
                                }
                            });




                        }
                    });

            alertDialog.show();
        }
        else{
            disconnect();
            createGroup();
        }


    }




    public void disconnect()
    {
        groupEntered = false;
        disconnectCompleted = false;
        manager.stopPeerDiscovery(channel,new WifiP2pManager.ActionListener(){

        @Override
        public void onSuccess() {

        }

        @Override
        public void onFailure(int code) {
            if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                System.out.println("P2pUnsupported");
            }
            else if(code == WifiP2pManager.ERROR){

                System.out.println("Error");
            }
            else if(code == WifiP2pManager.BUSY){

                System.out.println("BUSY");
            }
        }
    });
        manager.cancelConnect(channel,new WifiP2pManager.ActionListener()
        {
            @Override
            public void onSuccess()
            {
            }

            @Override
            public void onFailure(int code)
            {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }
            }
        });
        manager.removeGroup(channel, new WifiP2pManager.ActionListener()
        {
            @Override
            public void onSuccess()
            {
            }

            @Override
            public void onFailure(int code)
            {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }
            }
        });

        manager.clearLocalServices(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onFailure(int code) {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }
            }
        });

        manager.clearServiceRequests(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onFailure(int code) {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }
            }
        });

        if (isOrderedBroadcast()) {
            abortBroadcast();
            clearAbortBroadcast();
        }

        manager.clearServiceRequests(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
            }
            @Override
            public void onFailure(int reason) {
            }
        });
        manager.clearLocalServices(channel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
            }
            @Override
            public void onFailure(int reason) {
            }
        });

        disconnectCompleted = true;
    }



    public void discoverGroupServices(){
        aGroupDevices.clear();
        final HashMap<Object, Object> Groupdata = new HashMap<Object, Object>();

        WifiP2pManager.DnsSdTxtRecordListener txtListener = new WifiP2pManager.DnsSdTxtRecordListener() {
            @Override

            public void onDnsSdTxtRecordAvailable(
                    String fullDomain, Map record, WifiP2pDevice device) {
                Groupdata.put("GroupName", (String)record.get("groupname"));
                Groupdata.put("IP", (String)record.get("grouphost"));
                Groupdata.put("hostDevice", device );


            }

        };

        WifiP2pManager.DnsSdServiceResponseListener servListener = new WifiP2pManager.DnsSdServiceResponseListener() {
            @Override
            public void onDnsSdServiceAvailable(String instanceName, String registrationType,
                                                WifiP2pDevice resourceType) {
                System.out.println(instanceName);
                System.out.println(registrationType);
                 if(Groupdata.containsKey("GroupName")
                            && Groupdata.containsKey("hostDevice")&& Groupdata.containsKey("IP")){
                boolean addedYet = false;
                for (int i = 0; i < aGroupDevices.size(); i++) {
                    if (((WifiP2pDevice) (aGroupDevices.get(i).get("hostDevice"))).deviceAddress.matches(((WifiP2pDevice)Groupdata.get("hostDevice")).deviceAddress)) {
                        addedYet = true;
                        break;
                    }
                }
                if (!addedYet) {
                    aGroupDevices.add(Groupdata);
                    aPeers.add((WifiP2pDevice)Groupdata.get("hostDevice"));
                    WifiP2pConfig config = new WifiP2pConfig();
                    config.deviceAddress = ((WifiP2pDevice)Groupdata.get("hostDevice")).deviceAddress;
                    config.wps.setup = WpsInfo.PBC;
                    aConfigs.add(config);
                    ((P2pDetection)activity).showGroups(aGroupDevices);

                }
                }


            }
        };

        manager.setDnsSdResponseListeners(channel, servListener, txtListener);

        serviceRequest = WifiP2pDnsSdServiceRequest.newInstance();
        manager.addServiceRequest(channel, serviceRequest, new WifiP2pManager.ActionListener()
        {
            @Override
            public void onSuccess() {
                ((P2pDetection)activity).showGroups(aGroupDevices);
            }

            @Override
            public void onFailure(int code) {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }
            }

        });

        manager.discoverServices(channel, new WifiP2pManager.ActionListener() {

            @Override
            public void onSuccess() {
                if(activity.getClass() == P2pDetection.class){

                }

            }

            @Override
            public void onFailure(int code) {
                if (code == WifiP2pManager.P2P_UNSUPPORTED) {

                    System.out.println("P2pUnsupported");
                }
                else if(code == WifiP2pManager.ERROR){

                    System.out.println("Error");
                }
                else if(code == WifiP2pManager.BUSY){

                    System.out.println("BUSY");
                }

            }

        });



    }

}