package com.game.png.Main.GameModes;

public enum GameMode
{
    SINGLECLASSIC, SINGLESPEED, SINGLEJUGGLE, MULTINORMAL
}
