package com.game.png.Main.GameModes;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import com.game.png.GUI.Game;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;
import com.game.png.Main.GameObjects.Paddl;
import java.util.ArrayList;
import java.util.Random;

public class Juggle extends GamePanel
{
    private Paddl player;
    public ArrayList<Ball> balls = new ArrayList<Ball>();
    private Ball ball;
    public int ballsOnField =1;
    private boolean justStarted =true, ballOnStartPosition = true;
    private float startX, startY;
    private int hits;
    private float minADD, maxADD;
    private int mustHold;
    private float maxBallSpeed;
    private int lostBalls;
    private int neededHits;

    public Juggle(Game context, Difficulty difficulty )
    {
        super(context, difficulty);
        getHolder().addCallback(this);
        thread = new GameThread(getHolder(),this);
    }

    @Override
    public void onCreation()
    {
        player = new Paddl(500 * widthFaktor, 1300*heightFaktor, 300 * widthFaktor, 50*heightFaktor, objectColor, this);
        ball = new Ball(100*heightFaktor, 100*heightFaktor, 20*widthFaktor, objectColor, this, difficulty);
        addBall(ball);
        addObject(player);
        player.activate();
        switch(difficulty)
        {
            case MAJOR:
                startX = 22*widthFaktor;
                startY = 40*heightFaktor;
                maxADD = 15*widthFaktor;
                minADD = 0*widthFaktor;
                mustHold = 10;
                neededHits = 5;
                break;

            case EASY:
                startX = 2*widthFaktor;
                startY = 12*heightFaktor;
                maxADD = 3*widthFaktor;
                minADD = -3*widthFaktor;
                mustHold = 3;
                neededHits = 2;
                break;

            case HARD:
                startX = 15*widthFaktor;
                startY = 30*heightFaktor;
                maxADD = 10*widthFaktor;
                minADD = -3*widthFaktor;
                mustHold = 7;
                neededHits =4;
                break;

            case MEDIUM:
                startX = 8*widthFaktor;
                startY = 20*heightFaktor;
                maxADD = 7*widthFaktor;
                minADD = -5*widthFaktor;
                mustHold = 5;
                neededHits = 3;
                break;
        }
        maxBallSpeed = startX+startY;
    }

    @Override
    public void onTouch(MotionEvent event)
    {

        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                if (won || gameOver)
                {
                    endedOnClick= true;
                }

            case MotionEvent.ACTION_MOVE:
                if (justStarted)
                {
                    justStarted = false;
                }

                if (!won && !gameOver)
                {
                    if (ballOnStartPosition)
                    {
                        ball.calculateMoving(startX, startY);
                        ballOnStartPosition = false;
                    }

                    else
                    {
                        player.setPosition((int) event.getX(), getHeight() - 150);
                    }
                }

                break;

            case MotionEvent.ACTION_UP:
                break;
        }
    }

    @Override
    public void extendedDraw(Canvas canvas)
    {
        Paint miscPaint = new Paint();
        miscPaint.setColor(objectColor);
        miscPaint.setTextSize(125*widthFaktor);
        canvas.drawText("" + ballsOnField + "", 15, 200, miscPaint);
        if(justStarted)
        {
            Rect rect = new Rect();
            int ppb;
            if(mustHold>9)
            {
                ppb = 2;
            }

            else
            {
                ppb = 1;
            }

            miscPaint.setTextSize(75*widthFaktor);
            miscPaint.getTextBounds("HOLD " + mustHold + " BALLS ON THE FIELD",0,24+ppb,rect);
            int width = rect.width();
            canvas.drawText("HOLD " + mustHold + " BALLS ON THE FIELD",getWidth()/2-width/2, getHeight()/2, miscPaint);
        }
    }

    @Override
    public void updateSpc()
    {
        if(justStarted)
        {
            ball.setPosition(getWidth()/2,getHeight()/4);
        }

        if(player.centerY() < getHeight()-150 || player.centerY() > getHeight()-150 )
        {
            player.setPosition(player.point.x,getHeight()-150);
        }

        for(int i = 0; i< balls.size(); i++)
        {
            boolean special = false;
            switch (balls.get(i).checkBoundCollision())
            {
                case RIGHT:
                    balls.get(i).checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                    break;
                case LEFT:
                    balls.get(i).checkAndReflectByMovingDirection(MovingDirection.LEFT);
                    break;
                case LEFTTOP:
                    balls.get(i).checkAndReflectByMovingDirection(MovingDirection.LEFT);
                    special = true;
                case RIGHTTOP:
                    if(!special)
                    {
                        balls.get(i).checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                    }

                case TOP:
                    balls.get(i).checkAndReflectByMovingDirection(MovingDirection.UP);
                    if(balls.get(i) == ball)
                    {
                        hits++;
                        Random random=new Random();
                        float randomNumber=(0-random.nextInt(400));
                        if (hits % neededHits == 0)
                        {
                            Ball ball = new Ball(getWidth() / 2+ randomNumber, getHeight() / 2+randomNumber, 20*widthFaktor, objectColor, this, difficulty);
                            addBall(ball);
                            randomNumber = (random.nextInt((int)maxADD)-minADD);
                            float X = startX+ randomNumber;
                            float Y = startY+ randomNumber;
                            ball.calculateMoving(X, Y);
                            ballsOnField++;
                        }
                    }

                    break;
                case BOTTOM:
                case LEFTBOTTOM:
                case RIGHTBOTTOM:
                    balls.get(i).moveable = false;
                    if(balls.get(i)== ball && balls.size()>1)
                    {
                        ball = balls.get(i+1);
                    }

                    removeBall(balls.get(i));
                    ballsOnField--;
                    lostBalls++;

                    break;

            }
            if(maxBallSpeed< (ball.movingX*ball.countsOfMoving)+(ball.movingY*ball.countsOfMoving)){
                maxBallSpeed = (ball.movingX*ball.countsOfMoving)+(ball.movingY*ball.countsOfMoving);
            }
        }

        if(ballsOnField <= 0)
        {
            loose(false);
        }

        if(ballsOnField > mustHold)
        {
            win(true);
        }
    }

    public void addBall(Ball ball)
    {
        balls.add(ball);
        addObject(ball);
        colliders.add(new Collider(player, ball){});
        ball.activate();
    }

    public void removeBall(Ball ball)
    {
        balls.remove(ball);
        removeObject(ball);
        for (int i = 0; i< colliders.size();i++)
        {
            Collider collider = colliders.get(i).containsObject(ball);
            if(collider != null)
            {
                collider.deleteCollider();
                colliders.remove(collider);
            }
        }
    }

    @Override
    public int getScore()
    {
        //calculate with botpoints, time and maxBallspeed
        int score =(int)Math.round(((100000+maxBallSpeed*10-totalTimeMillis*2)/1000)*( ballsOnField - lostBalls));
        if(score<10)
        {
            score = 10;
        }
        return score;
    }
}