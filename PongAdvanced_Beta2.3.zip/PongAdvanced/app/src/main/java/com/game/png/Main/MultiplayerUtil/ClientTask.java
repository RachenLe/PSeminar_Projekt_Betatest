package com.game.png.Main.MultiplayerUtil;

import android.content.Context;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;

public class ClientTask extends AsyncTask<Void,Void,Void> {
    int port;
    InetAddress host;
    private Object object;
    private boolean running;

    public ClientTask(int port, InetAddress host) {
        this.port = port;
        this.host = host;
        object = new Object();
        running = true;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        try {

                Socket client = new Socket(host, port);
                client.connect(new InetSocketAddress(host, port));

                    ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());
                    out.writeObject(object);
                    if (object.getClass() == Integer.class) {
                        out.write(((Integer) object).intValue());
                    }
                    if (object.getClass() == Boolean.class) {
                        out.writeBoolean(((Boolean) object).booleanValue());
                    }
                    out.close();


            return null;

        } catch (IOException e) {
            return null;
        }
    }

    @Override
    protected void onPostExecute(Void voids) {

    }

    public void sendObject(Object obj){
        object = obj;
        execute();
    }

    public void sendInteger(int i){
        object = Integer.valueOf(i);
    }

    public void sendBoolean(boolean b){
        object = Boolean.valueOf(b);
    }
}