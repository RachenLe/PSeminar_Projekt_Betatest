package com.game.png.Main;

import android.content.Context;
import android.graphics.Color;
import com.game.png.GUI.DesignSelection;
import java.io.Serializable;

public class SavedDataPacket implements Serializable
{
    public boolean musicOn, soundsOn;
    public float musicVolume, soundVolume;
    public int colorBackground, colorObjects;

    public Score[] classicHighscoreEasy;
    public Score[] juggleHighScoreEasy;
    public Score[] speedHighScoreEasy;

    public Score[] classicHighscoreMedium;
    public Score[] juggleHighScoreMedium;
    public Score[] speedHighScoreMedium;

    public Score[] classicHighscoreHard;
    public Score[] juggleHighScoreHard;
    public Score[] speedHighScoreHard;

    public Score[] classicHighscoreMajor;
    public Score[] juggleHighScoreMajor;
    public Score[] speedHighScoreMajor;

    public String currentGameDesign;
    public GameDesign designObject;

    transient public Context context;

    public SavedDataPacket(Context context)
    {
        this.context = context;
    }

    private void override()
    {
        SoundManager.musicOn = this.musicOn;
        SoundManager.soundsOn = this.soundsOn;
        SoundManager.musicVolume = this.musicVolume;
        SoundManager.soundVolume = this.soundVolume;
        GameDesign.currentColorBackground = this.colorBackground;
        GameDesign.currentColorObjects = this.colorObjects;
        HighscoreCalculator.speedHighscoreEasy = speedHighScoreEasy;
        HighscoreCalculator.classicHighscoreEasy = classicHighscoreEasy;
        HighscoreCalculator.juggleHighscoreEasy = juggleHighScoreEasy;

        HighscoreCalculator.speedHighscoreMedium = speedHighScoreMedium;
        HighscoreCalculator.classicHighscoreMedium = classicHighscoreMedium;
        HighscoreCalculator.juggleHighscoreMedium = juggleHighScoreMedium;

        HighscoreCalculator.speedHighscoreHard = speedHighScoreHard;
        HighscoreCalculator.classicHighscoreHard = classicHighscoreHard;
        HighscoreCalculator.juggleHighscoreHard = juggleHighScoreHard;

        HighscoreCalculator.speedHighscoreMajor = speedHighScoreMajor;
        HighscoreCalculator.classicHighscoreMajor = classicHighscoreMajor;
        HighscoreCalculator.juggleHighscoreMajor = juggleHighScoreMajor;

        DesignSelection.currentDesign = this.currentGameDesign;
        GameDesign.currentGamedesign = this.designObject;
    }

    public void save()
    {
        musicOn = SoundManager.musicOn;
        soundsOn = SoundManager.soundsOn;
        musicVolume = SoundManager.musicVolume;
        soundVolume = SoundManager.soundVolume;
        colorBackground = GameDesign.currentColorBackground;
        colorObjects = GameDesign.currentColorObjects;
        classicHighscoreEasy = HighscoreCalculator.classicHighscoreEasy;
        juggleHighScoreEasy = HighscoreCalculator.juggleHighscoreEasy;
        speedHighScoreEasy = HighscoreCalculator.speedHighscoreEasy;

        speedHighScoreMedium = HighscoreCalculator.speedHighscoreMedium;;
        classicHighscoreMedium = HighscoreCalculator.classicHighscoreMedium;
        juggleHighScoreMedium = HighscoreCalculator.juggleHighscoreMedium;

        speedHighScoreHard = HighscoreCalculator.speedHighscoreHard;
        classicHighscoreHard=HighscoreCalculator.classicHighscoreHard;
        juggleHighScoreHard = HighscoreCalculator.juggleHighscoreHard;

        speedHighScoreMajor= HighscoreCalculator.speedHighscoreMajor;
        classicHighscoreMajor=HighscoreCalculator.classicHighscoreMajor;
        juggleHighScoreMajor=HighscoreCalculator.juggleHighscoreMajor;
        currentGameDesign = DesignSelection.currentDesign;
        designObject = GameDesign.currentGamedesign;
       DataManager.save(context.getFilesDir().getAbsolutePath(), "savedData",".sdp", this);
    }

    public void load()
    {
        SavedDataPacket packet = (SavedDataPacket)DataManager.load(context.getFilesDir().getAbsolutePath()+"savedData.sdp");

        if(packet != null)
        {
            musicOn = packet.musicOn;
            soundsOn = packet.soundsOn;
            musicVolume = packet.musicVolume;
            soundVolume = packet.soundVolume;
            colorBackground = packet.colorBackground;
            colorObjects = packet.colorObjects;
            classicHighscoreEasy =packet.classicHighscoreEasy;
            speedHighScoreEasy = packet.speedHighScoreEasy;
            juggleHighScoreEasy = packet.juggleHighScoreEasy;

            speedHighScoreMedium =packet.speedHighScoreMedium;;
            classicHighscoreMedium = packet.classicHighscoreMedium;
            juggleHighScoreMedium = packet.juggleHighScoreMedium;

            speedHighScoreHard = packet.speedHighScoreHard;
            classicHighscoreHard=packet.classicHighscoreHard;
            juggleHighScoreHard = packet.juggleHighScoreHard;

            speedHighScoreMajor= packet.speedHighScoreMajor;
            classicHighscoreMajor=packet.classicHighscoreMajor;
            juggleHighScoreMajor=packet.juggleHighScoreMajor;
            currentGameDesign = packet.currentGameDesign;
            designObject = packet.designObject;
            override();
        }

        else
        {
            musicOn = true;
            soundsOn = true;
            musicVolume = 1;
            soundVolume = 1;
            colorBackground = Color.BLACK;
            colorObjects = Color.WHITE;
            currentGameDesign = "CLASSIC";
            HighscoreCalculator.resetScores();
            classicHighscoreEasy = HighscoreCalculator.classicHighscoreEasy;
            juggleHighScoreEasy = HighscoreCalculator.juggleHighscoreEasy;
            speedHighScoreEasy = HighscoreCalculator.speedHighscoreEasy;

            speedHighScoreMedium = HighscoreCalculator.speedHighscoreMedium;;
            classicHighscoreMedium = HighscoreCalculator.classicHighscoreMedium;
            juggleHighScoreMedium = HighscoreCalculator.juggleHighscoreMedium;

            speedHighScoreHard = HighscoreCalculator.speedHighscoreHard;
            classicHighscoreHard=HighscoreCalculator.classicHighscoreHard;
            juggleHighScoreHard = HighscoreCalculator.juggleHighscoreHard;

            speedHighScoreMajor= HighscoreCalculator.speedHighscoreMajor;
            classicHighscoreMajor=HighscoreCalculator.classicHighscoreMajor;
            juggleHighScoreMajor=HighscoreCalculator.juggleHighscoreMajor;
            designObject = GameDesign.getGamedesignByName("CLASSIC");
            override();
            save();
        }
    }
}