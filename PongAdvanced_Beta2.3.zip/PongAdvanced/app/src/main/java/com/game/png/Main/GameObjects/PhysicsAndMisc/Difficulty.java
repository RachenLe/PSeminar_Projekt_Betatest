package com.game.png.Main.GameObjects.PhysicsAndMisc;

public enum Difficulty
{
    EASY, MEDIUM, HARD, MAJOR
}