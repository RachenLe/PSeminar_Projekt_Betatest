package com.game.png.Main;

import java.util.Timer;
import java.util.TimerTask;

public class TimeCounter
{
    private Timer timer;
    private TimerTask task;
    private int totalTimeMillis;
    private boolean paused;

    public void start()
    {
        totalTimeMillis =0;
        paused = false;
        timer = new Timer();
        task = new TimerTask()
        {
            @Override
            public void run()
            {
                if(!paused)
                {
                    totalTimeMillis++;
                }
            }
        };

        timer.schedule(task,0,1);
    }

    public void pause()
    {
        paused = true;
    }

    public void resume()
    {
        paused = false;
    }

    public int getEndTime()
    {
        timer.cancel();
        timer.purge();
        return totalTimeMillis;
    }
}