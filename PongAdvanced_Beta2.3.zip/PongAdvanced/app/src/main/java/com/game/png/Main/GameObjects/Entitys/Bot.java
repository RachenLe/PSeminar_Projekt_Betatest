package com.game.png.Main.GameObjects.Entitys;

import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.Paddl;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import java.util.ArrayList;

public class Bot extends Paddl
{
    public Paddl paddl;
    public Difficulty difficulty;
    public ArrayList balls = new ArrayList<Ball>();
    private float movingSpeed;
    private float randomSpeedChange;

    public Bot(float x, float y, float width, float height, int color, GamePanel context, Difficulty difficulty)
    {
        super(x,y,width,height,color, context);
        this.difficulty = difficulty;
    }

    @Override
    public void activate()
    {
        super.activate();
        switch(difficulty)
        {

            case HARD: movingSpeed = 25*context.widthFaktor;
                break;
            case EASY: movingSpeed = 9*context.widthFaktor ;
                break;
            case MEDIUM: movingSpeed = 17*context.widthFaktor ;
                break;
            case MAJOR: movingSpeed = 32*context.widthFaktor;
                break;
        }

        for(int i =0; i< context.gameObjects.size(); i++)
        {
            if(context.gameObjects.get(i).getClass() == Ball.class)
            {
                balls.add(context.gameObjects.get(i));
            }
        }
    }

    @Override
    public void update()
    {
        super.update();
        Ball target = nearestBall();
        randomSpeedChange = (float)((Math.random()*movingSpeed)-(double)movingSpeed/(double)2);
         switch(target.movingDirection)
         {
             case UP:
             case LEFTUP:
             case RIGHTUP:
                 if(target.centerX()< this.centerX())
                 {
                     if(this.centerX()> this.width()/2 +1 )
                     {
                         if (movingSpeed > (this.centerX() - target.centerX()))
                         {
                             move(-(int) (this.centerX() - target.centerX()), 0);
                         }

                         else
                         {
                             move(-movingSpeed-randomSpeedChange, 0);
                         }
                     }

                     else
                     {
                         setPosition((int)(this.width()/2), this.point.y );
                     }
                 }

                 if(target.centerX()> this.centerX())
                 {
                     if(this.centerX()< context.getWidth()-this.width()/2 - 1 )
                     {
                        if(movingSpeed> (target.centerX()-this.centerX()))
                        {
                           move((int)(target.centerX()-this.centerX()), 0);
                         }

                         else
                         {
                            move(movingSpeed+randomSpeedChange,0);
                         }
                     }

                     else
                     {
                         setPosition((int)(context.getWidth()-this.width()/2), this.point.y );
                     }
                 }
                 break;
             default:
                 if(this.centerX()< context.getWidth()/2-50)
                 {
                    move(movingSpeed+randomSpeedChange,0);
                 }

                 else if(this.centerX() > context.getWidth()/2+50)
                 {
                    move(-movingSpeed-randomSpeedChange,0);
                 }
                 break;
         }
    }

    private Ball nearestBall()
    {
            Ball nearest = (Ball)balls.get(0);
            int nearestDistance = (int)nearest.centerY();
            for(int i=1; i<balls.size(); i++){
                Ball selected = (Ball)balls.get(i);
                int selectedDistance = (int)selected.centerY();
                if(selectedDistance<nearestDistance)
                {
                    nearestDistance=selectedDistance;
                    nearest = selected;
                }
            }
            return nearest;
    }

    @Override
    public void delete()
    {
        super.delete();
        balls = null;
        difficulty = null;
    }
}