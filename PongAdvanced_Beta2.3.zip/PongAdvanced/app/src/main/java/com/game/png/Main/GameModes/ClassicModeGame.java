package com.game.png.Main.GameModes;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import com.game.png.GUI.Game;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.Entitys.Bot;
import com.game.png.Main.GameObjects.Paddl;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;

public class ClassicModeGame extends GamePanel
{
    private Paddl player  ;
    private Bot botEnemy;
    public Ball ball;
    public int pointsPlayer  = 0, pointsBot = 0;
    private boolean ballOnstartPosition = true;
    private boolean justStarted =true;
    private float startX, startY;
    public OnTouchListener listener;
    public long tStart, tEnd, tDelta;
    public int time;
    private float maxBallSpeed;

    public ClassicModeGame(Game context, Difficulty difficulty )
    {
        super(context, difficulty);
        getHolder().addCallback(this);
        thread = new GameThread(getHolder(),this);
    }

    @Override
    public void onCreation()
    {
        player = new Paddl(500 * widthFaktor, 1300*heightFaktor, 280 * widthFaktor, 40*heightFaktor, objectColor, this);
        botEnemy = new Bot(500 * widthFaktor, 150*heightFaktor, (280 * widthFaktor), 40*heightFaktor, objectColor,this, difficulty);
        ball = new Ball(100*heightFaktor, 100*heightFaktor, 20*widthFaktor, objectColor, this, difficulty);
        addObject(ball);
        addObject(player);
        addObject(botEnemy);
        colliders.add(new Collider(player, ball){});
        colliders.add(new Collider(botEnemy, ball){});
        ball.activate();
        player.activate();
        botEnemy.activate();
        tStart = System.currentTimeMillis();

        switch(difficulty){
            case MAJOR:
                startX = 30*widthFaktor;
                startY = 60*heightFaktor;
                break;

            case EASY:
                startX = 5*widthFaktor;
                startY = 20*heightFaktor;
                break;

            case HARD:
                startX = 25*widthFaktor;
                startY = 45*heightFaktor;
                break;

            case MEDIUM:
                startX = 10*widthFaktor;
                startY = 30*heightFaktor;
                break;
        }
        maxBallSpeed = startY+startX;
    }

    @Override
    public void onTouch(MotionEvent event)
    {

        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                if (won || gameOver)
                {
                    endedOnClick= true;
                }
            case MotionEvent.ACTION_MOVE:
                if (!won && !gameOver) {
                    boolean ballRelease = false;

                    //der Player wurde durch den Hauptpointer verschoben
                    if (event.getPointerCount() == 1)
                    {
                        player.setPosition((int) event.getX(), getHeight() - 150);
                    }

                    //Der Hauptpointer berührt den Ball
                    if(event.getX() < getWidth() / 2 + ball.width() + 20 && event.getX() > getWidth() / 2 - ball.width() - 20
                            && event.getY() < getHeight() / 2 + ball.height() + 20 && event.getY() > getHeight() / 2 - ball.height() - 20
                            && ballOnstartPosition)
                    {
                        ballRelease = true;
                    }

                    //ein anderer Pointer berührt den Ball

                    try
                    {
                        int pointer = event.getPointerId(event.getPointerCount()-1);

                        if (((event.getX(pointer) < getWidth() / 2 + ball.width() + 20 && event.getX(pointer) > getWidth() / 2 - ball.width() - 20
                                && event.getY(pointer) < getHeight() / 2 + ball.height() + 20 && event.getY(pointer) > getHeight() / 2 - ball.height() - 20))
                                && ballOnstartPosition)
                        {
                            ballRelease = true;
                        }

                    }

                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }


                    //der Ball wurde berührt und lag in der Startposition
                    if(ballRelease)
                    {
                        ball.resetStartVelocity();
                        ball.calculateMoving(startX, startY);
                        ball.moveable = true;
                        ballOnstartPosition = false;
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
                break;
        }
    }

    @Override
    public void extendedDraw(Canvas canvas)
    {
        Paint miscPaint = new Paint();
        miscPaint.setColor(objectColor);
        miscPaint.setTextSize(125*widthFaktor);
        Rect rect = new Rect();
        int ppE;
        int pbE;
        if (pointsPlayer > 9)
        {
            ppE = 2;
        }

        else
        {
            ppE = 1;
        }

        if (pointsBot > 9)
        {
            pbE = 2;
        }

        else
        {
            pbE = 1;
        }
        miscPaint.getTextBounds("" + pointsPlayer + "", 0, ppE, rect);
        float helloHeight = rect.height();
        rect = new Rect();
        miscPaint.getTextBounds("" + pointsBot + "", 0, pbE, rect);
        float byeWidth = rect.width();
        float byeHeight = rect.height();

        canvas.drawText("" + pointsPlayer + "", 15, ((this.getHeight() / 2) + (helloHeight * 3 / 2)), miscPaint);
        canvas.drawText("" + pointsBot + "", ((this.getWidth() - byeWidth) - 20), ((this.getHeight() / 2) - byeHeight / 2), miscPaint);
        canvas.drawLine(0, getHeight() / 2, getWidth(), getHeight() / 2, miscPaint);
    }

    @Override
    public void updateSpc()
    {
        if(justStarted)
        {
            ball.setPosition(getWidth()/2,getHeight()/2);
            justStarted=false;
            ballOnstartPosition=true;
        }

        if(player.centerY() < getHeight()-150 || player.centerY() > getHeight()-150 )
        {
            player.setPosition(player.point.x,getHeight()-150);
        }

        switch(ball.checkBoundCollision())
        {
            case RIGHT:
                ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                break;
            case LEFT:
                ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                break;
            case TOP:
            case LEFTTOP:
            case RIGHTTOP:
                ball.moveable = false;
                ballOnstartPosition = true;
                ball.setPosition(getWidth()/2,getHeight()/2);
                pointsPlayer++;
                break;
            case BOTTOM:
            case LEFTBOTTOM:
            case RIGHTBOTTOM:
                ball.moveable = false;
                ballOnstartPosition = true;
                ball.setPosition(getWidth()/2,getHeight()/2);
                pointsBot++;
                break;
            default:
                break;
        }

        if(pointsPlayer >= 11 &&pointsPlayer> pointsBot+1)
        {
            won = true;
            tEnd = System.currentTimeMillis();
            tDelta = tEnd - tStart;
            time = (int) tDelta / 1000;
            win(true);
        }
        if(pointsBot >= 11 && pointsPlayer< pointsBot-1)
        {
            tEnd = System.currentTimeMillis();
            tDelta = tEnd - tStart;
            time = (int) tDelta / 1000;
            gameOver = true;
            loose(true);
        }

        if(maxBallSpeed< (ball.movingX*ball.countsOfMoving)+(ball.movingY*ball.countsOfMoving))
        {
            maxBallSpeed = (ball.movingX*ball.countsOfMoving)+(ball.movingY*ball.countsOfMoving);
        }
    }

    @Override
    public int getScore()
    {
        //calculate with botpoints, time and maxBallspeed
        int score =(int)Math.round(((1000000+maxBallSpeed*10-totalTimeMillis*2)/1000)*((float)pointsPlayer/(float)pointsBot));
        if(score<10)
        {
            score = 10;
        }
        return score;
    }
}