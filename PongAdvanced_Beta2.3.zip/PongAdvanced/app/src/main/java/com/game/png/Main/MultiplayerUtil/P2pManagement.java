package com.game.png.Main.MultiplayerUtil;

import android.content.Context;
import android.net.wifi.p2p.WifiP2pManager;

import java.net.InetAddress;

/**
 * Created by Lennard on 31.12.2017.
 */

public class P2pManagement {
    public static WifiP2pManager manager;
    public static WifiP2pManager.Channel channel;
    public static InetAddress hostAdress;

    public static void initialize(Context context){
        manager = (WifiP2pManager) context.getSystemService(Context.WIFI_P2P_SERVICE);
        channel = manager.initialize(context, context.getMainLooper(), null);
    }

}
