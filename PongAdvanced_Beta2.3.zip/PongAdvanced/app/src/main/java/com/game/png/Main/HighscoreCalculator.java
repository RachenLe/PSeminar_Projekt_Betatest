package com.game.png.Main;

import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;

public class HighscoreCalculator
{
    public static Score[] classicHighscoreEasy;
    public static Score[] juggleHighscoreEasy;
    public static Score[] speedHighscoreEasy;

    public static Score[] classicHighscoreMedium;
    public static Score[] juggleHighscoreMedium;
    public static Score[] speedHighscoreMedium;

    public static Score[] classicHighscoreHard;
    public static Score[] juggleHighscoreHard;
    public static Score[] speedHighscoreHard;

    public static Score[] classicHighscoreMajor;
    public static Score[] juggleHighscoreMajor;
    public static Score[] speedHighscoreMajor;

    public static void resetScores()
    {
        classicHighscoreEasy = new Score[5];
        juggleHighscoreEasy = new Score[5];
        speedHighscoreEasy = new Score[5];
        for(int i =0; i<=4;i++)
        {
            classicHighscoreEasy[i] = new Score("-empty-",0);
            juggleHighscoreEasy[i] = new Score("-empty-",0);
            speedHighscoreEasy[i] = new Score("-empty-",0);

            classicHighscoreEasy[i].rank = i+1;
            speedHighscoreEasy[i].rank = i+1;
            juggleHighscoreEasy[i].rank = i+1;
        }

        classicHighscoreMedium = new Score[5];
        juggleHighscoreMedium= new Score[5];
        speedHighscoreMedium = new Score[5];
        for(int i =0; i<=4;i++)
        {
            classicHighscoreMedium[i] = new Score("-empty-",0);
            juggleHighscoreMedium[i] = new Score("-empty-",0);
            speedHighscoreMedium[i] = new Score("-empty-",0);

            classicHighscoreMedium[i].rank = i+1;
            speedHighscoreMedium[i].rank = i+1;
            juggleHighscoreMedium[i].rank = i+1;
        }

        classicHighscoreHard = new Score[5];
        juggleHighscoreHard= new Score[5];
        speedHighscoreHard = new Score[5];
        for(int i =0; i<=4;i++)
        {
            classicHighscoreHard[i] = new Score("-empty-",0);
            juggleHighscoreHard[i] = new Score("-empty-",0);
            speedHighscoreHard[i] = new Score("-empty-",0);

            classicHighscoreHard[i].rank = i+1;
            speedHighscoreHard[i].rank = i+1;
            juggleHighscoreHard[i].rank = i+1;
        }

        classicHighscoreMajor = new Score[5];
        juggleHighscoreMajor= new Score[5];
        speedHighscoreMajor= new Score[5];
        for(int i =0; i<=4;i++)
        {
            classicHighscoreMajor[i] = new Score("-empty-",0);
            juggleHighscoreMajor[i] = new Score("-empty-",0);
            speedHighscoreMajor[i] = new Score("-empty-",0);

            classicHighscoreMajor[i].rank = i+1;
            speedHighscoreMajor[i].rank = i+1;
            juggleHighscoreMajor[i].rank = i+1;
        }
    }

    public static void isTopClassicScore(Score score, Difficulty difficulty)
    {
        Score[] array;
        switch(difficulty)
        {
            case EASY:
                array = classicHighscoreEasy;
                classicHighscoreEasy= calculateScore(array,score);
                break;
            case MEDIUM:
                array = classicHighscoreMedium;
                classicHighscoreMedium= calculateScore(array,score);
                break;
            case HARD:
                array = classicHighscoreHard;
                classicHighscoreHard= calculateScore(array,score);
                break;
            case MAJOR:
                array = classicHighscoreMajor;
                classicHighscoreMajor= calculateScore(array,score);
                break;
            default:
                array = classicHighscoreEasy;
                classicHighscoreEasy= calculateScore(array,score);
                break;
        }
    }

    public static void isTopJuggleScore(Score score, Difficulty difficulty)
    {
        Score[] array;
        switch(difficulty)
        {
            case EASY:
                array = juggleHighscoreEasy;
                juggleHighscoreEasy= calculateScore(array,score);
                break;
            case MEDIUM:
                array = juggleHighscoreMedium;
                juggleHighscoreMedium= calculateScore(array,score);
                break;
            case HARD:
                array = juggleHighscoreHard;
                juggleHighscoreHard= calculateScore(array,score);
                break;
            case MAJOR:
                array = juggleHighscoreMajor;
                juggleHighscoreMajor= calculateScore(array,score);
                break;
            default:
                array = juggleHighscoreEasy;
                juggleHighscoreEasy= calculateScore(array,score);
                break;
        }
    }

    public static void isTopSpeedScore(Score score, Difficulty difficulty)
    {
        Score[] array;
        switch(difficulty)
        {
            case EASY:
                array = speedHighscoreEasy;
                speedHighscoreEasy= calculateScore(array,score);
                break;
            case MEDIUM:
                array = speedHighscoreMedium;
                speedHighscoreMedium= calculateScore(array,score);
                break;
            case HARD:
                array = speedHighscoreHard;
                speedHighscoreHard= calculateScore(array,score);
                break;
            case MAJOR:
                array = speedHighscoreMajor;
                speedHighscoreMajor= calculateScore(array,score);
                break;
            default:
                array = speedHighscoreEasy;
                speedHighscoreEasy= calculateScore(array,score);
                break;
        }
    }

    private static Score[] calculateScore(Score[] scorelist, Score score)
    {
        Score[] var = new Score[5];
        int rank = 0;
        boolean happendYet = false;
        for(int i = 0; i< scorelist.length; i++)
        {
            var[i] = scorelist[i];
        }

        for(int i = 0; i< scorelist.length;i++)
        {   if(score.score<scorelist[i].score && score.name.matches(scorelist[i].name)){
            break;
            }
            else if(score.score >= scorelist[i].score && !happendYet)
            {
                var[i]=score;
                boolean matched = false;
                for(int y= i+1; y< var.length;y++)
                {
                    if(score.name.matches(scorelist[y-1].name)){
                        matched = true;
                     }
                     else if(!matched) {
                        var[y] = scorelist[y - 1];
                     }
                     else{
                        var[y] = scorelist[y];
                    }
                }
                rank = i+1;
                happendYet = true;
            }
        }
        return var;
    }
}