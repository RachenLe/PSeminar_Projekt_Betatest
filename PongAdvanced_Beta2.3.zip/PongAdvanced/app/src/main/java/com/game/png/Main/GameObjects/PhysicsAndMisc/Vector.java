package com.game.png.Main.GameObjects.PhysicsAndMisc;

public class Vector
{
    public float x,y;
    public boolean yReflected = false, xReflected = false;
    public double slope;

    public Vector(float x, float y)
    {
        this.x = x;
        this.y = y;
        if (x != 0)
        {
            slope = y/x;
        }
    }


    public void reflectX()
    {
        this.x = -x;
        xReflected = !xReflected;
    }

    public void reflectY()
    {
        this.y = -y;
        yReflected = !yReflected;
    }

}