package com.game.png.Main.MultiplayerUtil;

import android.content.Context;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;


public class ServerTask extends AsyncTask<Void,Void,Void> {
    int port;

    public ServerTask(int port) {
        this.port = port;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            System.out.println("Hello");
            for(;;) {
                ServerSocket serverSocket = new ServerSocket(port);
                final Socket client = serverSocket.accept();
                System.out.println("Yes");
                new MultiplayerManagementThread(){

                    @Override
                    public void runningMethod() {
                        try {
                            ObjectOutputStream ous = new ObjectOutputStream(client.getOutputStream());
                            ous.flush();
                            ObjectInputStream in = new ObjectInputStream(client.getInputStream());
                            System.out.println(in.readObject());
                        }
                        catch (Exception e){

                        }
                    }
                }.start();
            }


        } catch (IOException e) {
            return null;
        }
    }

    @Override
    protected void onPostExecute(Void voids) {

    }

}