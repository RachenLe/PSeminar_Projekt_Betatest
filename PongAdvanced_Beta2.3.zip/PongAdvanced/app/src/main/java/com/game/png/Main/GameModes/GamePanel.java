package com.game.png.Main.GameModes;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import com.game.png.GUI.Game;
import com.game.png.Main.GameDesign;
import com.game.png.Main.GameObjects.GameObject;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.TimeCounter;
import java.util.ArrayList;

public abstract class GamePanel extends SurfaceView implements SurfaceHolder.Callback
{
    public GameThread thread ;
    public ArrayList<GameObject> gameObjects = new ArrayList<GameObject>();
    public static int backgroundColor, objectColor;
    public ArrayList<Collider> colliders = new ArrayList<Collider>();
    public boolean won, gameOver;
    public Game context;
    public Difficulty difficulty;
    public boolean ending;
    public boolean EndScreenDrawn;
    public boolean paused;
    public int PanelWidth, PanelHeight;
    public float widthFaktor, heightFaktor;
    public boolean endedOnClick;
    public int totalTimeMillis;
    public TimeCounter timer;
    private int score;
    private boolean showScore;

    public GamePanel(Game context, Difficulty difficulty)
    {
        super(context);
        gameOver = false;
        won = false;
        getHolder().addCallback(this);
        thread = new GameThread(getHolder(),this);
        setFocusable(true);
        this.context = context;
        this. difficulty = difficulty;
        ending = false;
        this.PanelWidth = context.panelWidth;
        this.PanelHeight = context.panelHeight;
        EndScreenDrawn = false;
        backgroundColor = GameDesign.currentColorBackground;
        objectColor = GameDesign.currentColorObjects;
        timer = new TimeCounter();
    }

    public abstract void onCreation();

    @Override
    public void surfaceCreated(SurfaceHolder holder)
    {
        thread = new GameThread(getHolder(),this);
        widthFaktor = (float)PanelWidth/(float)1080;
        heightFaktor = (float)PanelHeight/(float)1776;
        onCreation();
        thread.setRunning(true);
        thread.start();
        timer.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
    {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder)
    {
        thread.setRunning(false);
        thread.interrupt();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        if(!ending &! paused)
        {
            onTouch(event);
        }
        return true;
    }

    public abstract void onTouch(MotionEvent event);

    @Override
    public void draw(Canvas canvas)
    {
        super.draw(canvas);
        if(!won && !gameOver && !paused)
        {
            canvas.drawColor(backgroundColor);

            for (int i = 0; i < gameObjects.size(); i++)
            {
                GameObject obj = gameObjects.get(i);
                obj.draw(canvas);
            }
            extendedDraw(canvas);
        }

        else if(won && !gameOver)
        {
            canvas.drawColor(Color.WHITE);
            Paint winnerPaint = new Paint();
            winnerPaint.setColor(Color.YELLOW);
            winnerPaint.setTextSize(widthFaktor*800);
            Rect rect = new Rect();
            winnerPaint.getTextBounds("V", 0, 1, rect);
            float width = rect.width();
            float height = rect.height();
            canvas.drawText("V",getWidth()/2-width/2,getHeight()/2+height/2,winnerPaint);
            if(endedOnClick)
            {
                thread.end();
                context.win(showScore,score);
            }
        }

        else if(gameOver && !won)
        {
            canvas.drawColor(Color.BLACK);
            Paint loserPaint = new Paint();
            loserPaint.setColor(Color.WHITE);
            loserPaint.setTextSize(widthFaktor*180);
            Rect rect = new Rect();
            loserPaint.getTextBounds("GAME OVER", 0, 9, rect);
            float width = rect.width();
            float height = rect.height();
            canvas.drawText("GAME OVER",getWidth()/2 - width/2,getHeight()/2 + height/2,loserPaint);
            if(endedOnClick)
            {
                thread.end();
                context.loose(showScore,score);
            }
        }

        else if(paused && !gameOver && !won)
        {
            canvas.drawColor(Color.BLACK);
            Paint loserPaint = new Paint();
            loserPaint.setColor(Color.WHITE);
            loserPaint.setTextSize(widthFaktor*180);
            Rect rect = new Rect();
            loserPaint.getTextBounds("PAUSED", 0, 6, rect);
            float width = rect.width();
            float height = rect.height();
            canvas.drawText("PAUSED",getWidth()/2 - width/2,getHeight()/2 + height/2,loserPaint);
            thread.pause();
            timer.pause();
        }
    }

    public abstract void extendedDraw(Canvas canvas);
    public abstract void updateSpc();

    public void update()
    {   if(!won && !gameOver && !paused) {
        for (int i = 0; i < gameObjects.size(); i++) {
            GameObject obj = gameObjects.get(i);
            obj.update();
        }
        updateSpc();
    }
    }

    public void addObject(GameObject gameObject)
    {
        gameObjects.add(gameObject);
    }

    public void removeObject(GameObject gameObject)
    {
        gameObjects.remove(gameObject);
    }

    public void win(boolean calcScore)
    {
        showScore = calcScore;
        if(calcScore)
        {
            totalTimeMillis = timer.getEndTime();
            score = getScore();
        }
        won = true;
    }

    public void loose(boolean calcScore)
    {
        showScore = calcScore;
        if(calcScore)
        {
            totalTimeMillis = timer.getEndTime();
            score = getScore();
        }
        gameOver = true;
    }

    public abstract int getScore();

    public void pause()
    {
        paused = true;
    }

    public void resume()
    {
        paused = false;
        timer.pause();
        thread.Continue();
    }
}