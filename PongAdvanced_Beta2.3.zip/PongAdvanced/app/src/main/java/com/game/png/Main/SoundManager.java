package com.game.png.Main;

import android.content.Context;
import android.media.MediaPlayer;
import java.util.Timer;
import java.util.TimerTask;

public class SoundManager
{
    static MediaPlayer soundPlayer;
    static MediaPlayer musicPlayer;
    private static Context context;
    public static boolean musicOn, soundsOn;
    public static  boolean activated = false;
    public static float soundVolume, musicVolume;
    public static boolean fadingIn , fadedOut = false;


    public static void setContext(Context context)
    {
       SoundManager.context = context;
    }

    public static void startMusic( int music, boolean looping)
    {
        if(musicOn)
        {
            if (musicPlayer != null)
            {
                if (musicPlayer.isPlaying())
                {
                    musicPlayer.pause();
                    musicPlayer.stop();
                    musicPlayer.release();
                }
                musicPlayer = null;
            }
            musicPlayer = MediaPlayer.create(context, music);
            musicPlayer.start();
            musicPlayer.setLooping(looping);
            musicPlayer.setVolume(musicVolume, musicVolume);
        }
    }

    public static void stopMusic()
    {
        if(musicPlayer != null)
        {
            if(musicPlayer.isPlaying())
            {
                musicPlayer.pause();
                musicPlayer.stop();
                musicPlayer.release();
            }
            musicPlayer = null;
        }
    }

    public static void pauseMusic()
    {
        if(musicPlayer != null)
        {
            if (musicPlayer.isPlaying())
            {
                musicPlayer.pause();
            }
        }
    }

    public static void resumeMusic()
    {
        if(musicOn)
        {
            if (musicPlayer != null)
            {
                if (!musicPlayer.isPlaying())
                {
                    musicPlayer.start();
                }
            }
        }
    }

    public static void playSound( int sound)
    {
        if(soundsOn)
        {
            if(soundPlayer== null)
            {
                soundPlayer = MediaPlayer.create(context, sound);
            }

            if(!soundPlayer.isPlaying())
            {
                soundPlayer.start();
                soundPlayer.setLooping(false);
                soundPlayer.setVolume(soundVolume, soundVolume);
            }
        }
    }

    public static void stopSounds()
    {
        if(soundPlayer != null)
        {
            if(soundPlayer.isPlaying())
            {
                soundPlayer.pause();
                soundPlayer.stop();
                soundPlayer.release();
            }

            soundPlayer = null;
        }
    }

    public static void pauseSounds()
    {
        if(soundPlayer != null)
        {
            if (soundPlayer.isPlaying())
            {
                soundPlayer.pause();
            }
        }
    }

    public static void resumeSounds()
    {
        if(soundsOn)
        {
            if (soundPlayer != null)
            {
                if (!soundPlayer.isPlaying())
                {
                    soundPlayer.start();
                }
            }
        }
    }

    public static void terminate()
    {
        stopMusic();
        stopSounds();
        musicPlayer = null;
        soundPlayer = null;
    }

    public static void setSoundVolume(float volume)
    {
        soundVolume = volume;
        if(soundPlayer!=null)
        {
            soundPlayer.setVolume(volume, volume);
        }
    }

    public static void setMusicVolume(float volume)
    {
        musicVolume = volume;
        if(musicPlayer!=null)
        {
            musicPlayer.setVolume(volume, volume);
        }
    }

    public static void setMusicOn(boolean on)
    {
        musicOn = on;
        if(on != true)
        {
            stopMusic();
        }
    }

    public static void setSoundsOn(boolean on)
    {
        soundsOn = on;
        if(on != true)
        {
            stopSounds();
        }
    }

    public static void fadeInMusic(int music, final FadingSpeed fadingSpeed, boolean looping)
    {
        if(musicOn) {
            int speed;
            fadingIn = true;
            switch (fadingSpeed) {
                case FAST:
                    speed = 5;
                    break;
                case MODERATE:
                    speed = 10;
                    break;
                case SLOW:
                    speed = 25;
                    break;
                default:
                    speed = 10;
                    break;
            }

            if (musicPlayer == null) {
                musicPlayer = MediaPlayer.create(context, music);
            } else {
                if (musicPlayer.isPlaying()) {
                    stopMusic();
                }

                musicPlayer = MediaPlayer.create(context, music);
            }

            musicPlayer.setVolume(0, 0);
            musicPlayer.start();
            musicPlayer.setLooping(looping);
            final Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                private float currentVolume = 0;

                @Override
                public void run() {
                    if (currentVolume < musicVolume) {
                        currentVolume = (float) (currentVolume + 0.01);
                        try {
                            musicPlayer.setVolume(currentVolume, currentVolume);
                        } catch (Exception e) {

                        }
                    } else {
                        fadingIn = false;
                        timer.cancel();
                        timer.purge();
                    }
                }
            }, 0, speed);
        }
    }

    public static void fadeOutMusic(FadingSpeed fadingSpeed)
    {
        if(musicOn) {
            fadedOut = false;
            final FadingSpeed ffadingSpeed = fadingSpeed;
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    if (musicPlayer != null) {
                        if (musicPlayer.isPlaying()) {
                            int speed;
                            switch (ffadingSpeed) {
                                case FAST:
                                    speed = 5;
                                    break;
                                case MODERATE:
                                    speed = 10;
                                    break;
                                case SLOW:
                                    speed = 25;
                                    break;
                                default:
                                    speed = 10;
                                    break;
                            }

                            musicPlayer.setVolume(musicVolume, musicVolume);
                            final Timer timer = new Timer();
                            timer.schedule(new TimerTask() {
                                private float currentVolume = musicVolume;

                                @Override
                                public void run() {
                                    if (currentVolume > 0) {
                                        currentVolume = (float) (currentVolume - 0.01);
                                        if (currentVolume < 0) {
                                            currentVolume = 0;
                                        }

                                        try {
                                            musicPlayer.setVolume(currentVolume, currentVolume);
                                        } catch (Exception e) {

                                        }

                                    } else {
                                        stopMusic();
                                        fadedOut = true;
                                        timer.cancel();
                                        timer.purge();
                                    }
                                }
                            }, 0, speed);
                        }
                    }
                }

            });
            while (fadingIn) {
                try {
                    thread.sleep(20);
                } catch (Exception e) {
                    continue;
                }
            }
            thread.start();
        }
    }

    public static void fadeThrowMusic(int music, final FadingSpeed fadingSpeed, final boolean looping) {
        if (musicOn) {
            final int fmusic = music;
            final FadingSpeed ffadingSpeed = fadingSpeed;
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    int speed;

                    switch (ffadingSpeed) {
                        case FAST:
                            speed = 5;
                            break;
                        case MODERATE:
                            speed = 10;
                            break;
                        case SLOW:
                            speed = 25;
                            break;
                        default:
                            speed = 10;
                            break;
                    }

                    if (musicPlayer != null) {
                        if (musicPlayer.isPlaying()) {
                            final Timer timer = new Timer();
                            timer.schedule(new TimerTask() {
                                private float currentVolume = musicVolume;

                                @Override
                                public void run() {
                                    if (currentVolume > 0) {
                                        currentVolume = (float) (currentVolume - 0.01);
                                        if (currentVolume < 0) {
                                            currentVolume = 0;
                                        }

                                        try {
                                            musicPlayer.setVolume(currentVolume, currentVolume);
                                        } catch (Exception e) {

                                        }
                                    } else {
                                        stopMusic();
                                        fadeInMusic(fmusic, fadingSpeed, looping);
                                        timer.cancel();
                                        timer.purge();
                                    }
                                }
                            }, 0, speed);
                        }
                    }
                }
            });

            while (fadingIn) {
                try {
                    thread.sleep(20);
                } catch (Exception e) {
                    continue;
                }
            }
            thread.start();
        }
    }
}