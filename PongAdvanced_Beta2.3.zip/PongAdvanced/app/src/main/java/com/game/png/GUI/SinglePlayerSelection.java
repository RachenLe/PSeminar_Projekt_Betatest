package com.game.png.GUI;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import com.game.png.Main.FadingSpeed;
import com.game.png.Main.GameDesign;
import com.game.png.Main.GameModes.GameMode;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import java.io.Serializable;

public class SinglePlayerSelection extends Activity implements Serializable
{

    public Button medium, hard, easy, major;
    private Difficulty difficulty;
    boolean changingToLinkedActivity = false;
    private boolean cameFromLinkedActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final View decorView = getWindow().getDecorView();
        final int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_single_player_game_modes);
            boolean cameFromGameActivity;
            if(getIntent().getSerializableExtra("cameFromGameActivity")!=null)
            {
                cameFromGameActivity=(boolean) getIntent().getSerializableExtra("cameFromGameActivity");
            }
            else
            {
                cameFromGameActivity = false;
            }

        cameFromLinkedActivity = (boolean)getIntent().getSerializableExtra("cameFromLinkedActivity");
        if(cameFromGameActivity)
        {
            SoundManager.fadeThrowMusic(R.raw.menu_music, FadingSpeed.FAST,true);
            cameFromGameActivity = false;
        }
        easy = findViewById(R.id.easy);
        medium = findViewById(R.id.medium);
        hard = findViewById(R.id.hard);
        major = findViewById(R.id.major);

        medium.setTextColor(GameDesign.getButtonColor());
        easy.setTextColor(Color.LTGRAY);
        hard.setTextColor(Color.LTGRAY);
        major.setTextColor(Color.LTGRAY);
        difficulty = Difficulty.MEDIUM;

        major.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                major.setTextColor(GameDesign.getButtonColor());
                medium.setTextColor(Color.LTGRAY);
                easy.setTextColor(Color.LTGRAY);
                hard.setTextColor(Color.LTGRAY);
                difficulty = Difficulty.MAJOR;
            }
        });

        easy.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                easy.setTextColor(GameDesign.getButtonColor());
                medium.setTextColor(Color.LTGRAY);
                major.setTextColor(Color.LTGRAY);
                hard.setTextColor(Color.LTGRAY);
                difficulty = Difficulty.EASY;
            }
        });

        medium.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                medium.setTextColor(GameDesign.getButtonColor());
                major.setTextColor(Color.LTGRAY);
                easy.setTextColor(Color.LTGRAY);
                hard.setTextColor(Color.LTGRAY);
                difficulty = Difficulty.MEDIUM;
            }
        });

        hard.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                hard.setTextColor(GameDesign.getButtonColor());
                medium.setTextColor(Color.LTGRAY);
                easy.setTextColor(Color.LTGRAY);
                major.setTextColor(Color.LTGRAY);
                difficulty = Difficulty.HARD;
            }
        });
    }

    public void Classic(View v)
    {
        changingToLinkedActivity = true;
        Intent intent =new Intent(SinglePlayerSelection.this, Game.class);
        intent.putExtra("cameFromLinkedActivity", true);
        intent.putExtra("difficulty", difficulty);
        intent.putExtra("Gamemode", GameMode.SINGLECLASSIC);
        startActivity(intent);
        finish();
    }

    public void Speed(View v)
    {
        changingToLinkedActivity = true;
        Intent intent =new Intent(SinglePlayerSelection.this, Game.class);
        intent.putExtra("cameFromLinkedActivity", true);
        intent.putExtra("difficulty", difficulty);
        intent.putExtra("Gamemode", GameMode.SINGLESPEED);
        startActivity(intent);
        finish();
    }

    public void juggle(View view)
    {
        changingToLinkedActivity = true;
        Intent intent =new Intent(SinglePlayerSelection.this, Game.class);
        intent.putExtra("cameFromLinkedActivity", true);
        intent.putExtra("difficulty", difficulty);
        intent.putExtra("Gamemode", GameMode.SINGLEJUGGLE);
        startActivity(intent);
        finish();
    }
    public void back(View v)
    {
        changingToLinkedActivity = true;
        Intent intent =new Intent(SinglePlayerSelection.this, PlayModiSelection.class);
        intent.putExtra("cameFromLinkedActivity", true);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if(!cameFromLinkedActivity)
        {
            SoundManager.resumeMusic();
        }
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if(!changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
            cameFromLinkedActivity = false;
        }
    }
}