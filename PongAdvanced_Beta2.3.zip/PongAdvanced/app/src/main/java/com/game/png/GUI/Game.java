package com.game.png.GUI;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.game.png.Main.FadingSpeed;
import com.game.png.Main.GameModes.GameMode;
import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameModes.SpeedMode;
import com.game.png.Main.GameModes.ClassicModeGame;
import com.game.png.Main.GameModes.Juggle;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import java.io.Serializable;

    public class Game extends Activity implements Serializable
    {
        public GameMode mode;
        public Difficulty difficulty;
        public GamePanel panel;
        public LinearLayout bottomBar;
        public Button leave, pause;
        public LinearLayout layout;
        public int sizeX, sizeY;
        public int panelWidth, panelHeight;
        public View.OnClickListener pauseOne, pauseTwo;
        private boolean cameFromLinkedActivity;
        private boolean changingToLinkedActivity;

    @Override
        protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                      | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                      | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                      | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                      | View.SYSTEM_UI_FLAG_FULLSCREEN
                      | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_game);

        mode = (GameMode)getIntent().getSerializableExtra("Gamemode") ;
        difficulty = (Difficulty)getIntent().getSerializableExtra("difficulty");
        cameFromLinkedActivity = (boolean)getIntent().getSerializableExtra("cameFromLinkedActivity");

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        sizeX = size.x;
        sizeY = size.y;

        bottomBar = findViewById(R.id.BottomBar);
        bottomBar.setBackgroundColor(Color.DKGRAY);

        leave = findViewById(R.id.leave);
        pause = findViewById(R.id.pause);

        pauseOne = new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                pause();
                pause.setText("Resume");
                pause.setOnClickListener(pauseTwo);
            }
        };

        pauseTwo =  new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                resume();
                pause.setText("Pause");
                pause.setOnClickListener(pauseOne);
            }
        };

        leave.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                leave();
            }
        });

        pause.setOnClickListener(pauseOne);
        panelWidth = sizeX;
        panelHeight = sizeY-bottomBar.getHeight();
        layout = findViewById(R.id.LinearOne);
        switch(mode)
        {
            case MULTINORMAL:
                break;
            case SINGLEJUGGLE:
                panel = new Juggle(this, difficulty);
                layout.addView(panel,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                break;
            case SINGLESPEED:
                panel = new SpeedMode(this, difficulty);
                layout.addView(panel,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                break;
            case SINGLECLASSIC:
                panel = new ClassicModeGame(this, difficulty);
                layout.addView(panel,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                break;
        }

        if(!cameFromLinkedActivity)
        {
            SoundManager.terminate();
            SoundManager.setContext(getApplicationContext());
            SoundManager.startMusic(R.raw.game, true);
        }

        else
        {
            SoundManager.fadeThrowMusic(R.raw.game, FadingSpeed.FAST, true);
        }
    }

        public void win(boolean showScore, @Nullable int points)
        {
            final Game game = this;
            bottomBar.post(new Runnable()
            {
                public void run()
                {
                    bottomBar.removeAllViews();
                    TextView text = new TextView(game);
                    text.setTextSize(30);
                    text.setText("    CONGRATULATIONS");
                    text.setTextColor(Color.WHITE);
                    bottomBar.addView(text, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                }
            });

            if(showScore)
            {
                    panel.thread.setRunning(false);
                    changingToLinkedActivity = true;
                    Intent intent = new Intent(Game.this, HighScoreScreen.class);
                    intent.putExtra("points", points);
                    intent.putExtra("gamemode", mode);
                    intent.putExtra("difficulty", difficulty);
                    intent.putExtra("cameFromLinkedActivity", true);
                    intent.putExtra("cameFromGameActivity", true);
                    startActivity(intent);
                    panel.thread.interrupt();
                    finish();
            }

            else
            {
                    panel.thread.setRunning(false);
                    changingToLinkedActivity = true;
                    Intent intent = new Intent(Game.this, SinglePlayerSelection.class);
                    intent.putExtra("cameFromLinkedActivity", true);
                    intent.putExtra("cameFromGameActivity", true);
                    startActivity(intent);
                    panel.thread.interrupt();
                    finish();
            }
        }

    public void loose( boolean showScore, @Nullable int points)
    {
        final Game game = this;
        bottomBar.post(new Runnable()
        {
            public void run()
            {
                bottomBar.removeAllViews();
                TextView text = new TextView(game);
                text.setTextSize(30);
                text.setText("    NEXT TIME...");
                text.setTextColor(Color.WHITE);
                bottomBar.addView(text, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
            }
        });

        if(showScore)
        {
                 panel.thread.setRunning(false);
                changingToLinkedActivity = true;
                Intent intent = new Intent(Game.this, HighScoreScreen.class);
                intent.putExtra("points", points);
                intent.putExtra("gamemode", mode);
                intent.putExtra("difficulty", difficulty);
                intent.putExtra("cameFromLinkedActivity", true);
                intent.putExtra("cameFromGameActivity", true);
                startActivity(intent);
                panel.thread.interrupt();
                finish();
        }
        else
        {
                panel.thread.setRunning(false);
                changingToLinkedActivity = true;
                Intent intent = new Intent(Game.this, SinglePlayerSelection.class);
                intent.putExtra("cameFromLinkedActivity", true);
                intent.putExtra("cameFromGameActivity", true);
                startActivity(intent);
                panel.thread.interrupt();
                finish();
        }
    }

    public void pause()
    {
        panel.pause();
    }

    public void resume()
    {
        panel.resume();
    }

    public void leave()
    {
            panel.thread.setRunning(false);
            changingToLinkedActivity = true;
            panel.thread.interrupt();
            Intent intent =new Intent(Game.this, SinglePlayerSelection.class);
            intent.putExtra("cameFromLinkedActivity", true);
            intent.putExtra("cameFromGameActivity", true);
            startActivity(intent);
            panel.thread.interrupt();
            finish();
    }
    @Override
    protected void onResume()
    {
        super.onResume();
        if(!cameFromLinkedActivity)
        {
            SoundManager.resumeMusic();
        }
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        if (panel.thread != null)
        {
            if (panel.thread.getState() == Thread.State.TERMINATED)
            {
                startActivity(new Intent(Game.this, SinglePlayerSelection.class));
                finish();
            }
        }
    }
    @Override
    protected void onPause()
    {
        super.onPause();
        if(!changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
            cameFromLinkedActivity = false;
        }
    }
}