package com.game.png.GUI;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.SeekBar;

import com.game.png.Main.FadingSpeed;
import com.game.png.Main.GameDesign;
import com.game.png.Main.SavedDataPacket;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import java.io.Serializable;

public class OptionsSurface extends Activity implements Serializable
{
    boolean changingToLinkedActivity = false;
    static boolean cameFromLinkedActivity = false;
    public static boolean soundsActive, musicActive;
    public static float soundsVolume, musicVolume;
    public SeekBar soundVolumeBar, musicVolumeBar;
    public CheckBox activeSounds, activeMusic;
    public Button changeGameDesign;
    public Button apply;
    public boolean anythingChanged;
    private boolean applyed =  false;
    private boolean originSoundsOn;
    private boolean originMusicOn;
    private float originMusicVolume;
    private float originSoundVolume;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_options_surface);

        anythingChanged = false;
        soundsVolume = SoundManager.soundVolume;
        musicVolume = SoundManager.musicVolume;
        musicActive = SoundManager.musicOn;
        soundsActive = SoundManager.soundsOn;

        originSoundVolume = SoundManager.soundVolume;
        originMusicVolume = SoundManager.musicVolume;
        originMusicOn = SoundManager.musicOn;
        originSoundsOn = SoundManager.soundsOn;

        musicVolumeBar = findViewById(R.id.musicSeekBar);
        soundVolumeBar = findViewById(R.id.soundSeekBar);

        activeSounds = findViewById(R.id.soundCheckBox);
        activeMusic = findViewById(R.id.musicCheckBox);

        changeGameDesign = findViewById(R.id.changeGameDesign);
        apply = findViewById(R.id.apply);

        musicVolumeBar.setProgress((int)(musicVolume*100));
        soundVolumeBar.setProgress((int)(soundsVolume*100));
        activeSounds.setChecked(soundsActive);
        activeMusic.setChecked(musicActive);

        musicVolumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                SoundManager.setMusicVolume(((float)progress/(float)100));
                musicVolume = SoundManager.musicVolume;
                anythingChanged = true;
                apply.setTextColor(GameDesign.getButtonColor());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {

            }
        });

        soundVolumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                SoundManager.setSoundVolume(((float)progress/(float)100));
                soundsVolume = SoundManager.soundVolume;
                anythingChanged = true;
                apply.setTextColor(GameDesign.getButtonColor());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {

            }
        });

        activeSounds.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SoundManager.setSoundsOn(isChecked);
                soundsActive = SoundManager.soundsOn;
                if(isChecked){
                    SoundManager.playSound(R.raw.pong);
                }
                anythingChanged = true;
                apply.setTextColor(GameDesign.getButtonColor());
            }
        });

        activeMusic.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SoundManager.setMusicOn(isChecked);
                if(isChecked){
                    SoundManager.fadeInMusic(R.raw.menu_music, FadingSpeed.FAST, true);
                }
                musicActive = SoundManager.musicOn;
                anythingChanged = true;
                apply.setTextColor(GameDesign.getButtonColor());
            }
        });

    }

    public void apply(View view)
    {
        if(anythingChanged)
        {
            (new SavedDataPacket(getApplicationContext())).save();
            apply.setTextColor(Color.rgb(180, 180, 180));
            applyed =true;
            originSoundVolume = SoundManager.soundVolume;
            originMusicVolume = SoundManager.musicVolume;
            originMusicOn = SoundManager.musicOn;
            originSoundsOn = SoundManager.soundsOn;
        }
    }

    public void back(View view){
        if(!applyed && anythingChanged)
        {
            new SavedDataPacket(getApplicationContext()).load();
            SoundManager.setSoundVolume(originSoundVolume);
            SoundManager.setMusicVolume(originMusicVolume);
            SoundManager.setMusicOn(originMusicOn);
            SoundManager.setSoundsOn(originSoundsOn);
        }
        changingToLinkedActivity = true;
        changingToLinkedActivity = true;
        Intent intent =new Intent(OptionsSurface.this, Menu.class);
        intent.putExtra("cameFromLinkedActivity", true);
        startActivity(intent);
        finish();
    }

    public void changeGameDesign(View v)
    {
        changingToLinkedActivity = true;
        Intent intent =new Intent(OptionsSurface.this, DesignSelection.class);
        intent.putExtra("cameFromLinkedActivity", true);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if(!cameFromLinkedActivity)
        {
            SoundManager.resumeMusic();
        }
        else
        {
            cameFromLinkedActivity = false;
        }
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if(!changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
        }
    }
}