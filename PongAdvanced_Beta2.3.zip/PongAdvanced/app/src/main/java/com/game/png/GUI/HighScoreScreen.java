package com.game.png.GUI;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.game.png.Main.FadingSpeed;
import com.game.png.Main.GameModes.GameMode;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.HighscoreCalculator;
import com.game.png.Main.SavedDataPacket;
import com.game.png.Main.Score;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import java.io.Serializable;

public class HighScoreScreen extends Activity implements Serializable
{
    public String playerName;
    private TextView nmFirst,nmSecond,nmThird,nmFourth,nmFifth, scFirst,scSecond, scThird,scFourth,scFifth;
    public GameMode selectedMode;
    public Difficulty difficulty;
    public int score;
    private Score currentScore;
    public  boolean cameFromGame;
    private boolean cameFromLinkedActivity;
    private boolean changingToLinkedActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_highscore_screen);

        ((Button) (findViewById(R.id.backFromHighscore))).setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                (new SavedDataPacket(getApplicationContext())).save();
                changingToLinkedActivity = true;
                Intent intent =new Intent(HighScoreScreen.this, Menu.class);
                intent.putExtra("cameFromLinkedActivity", true);
                startActivity(intent);
                finish();
            }
        });

        cameFromLinkedActivity = (boolean)getIntent().getSerializableExtra("cameFromLinkedActivity");
        cameFromGame =  (boolean)getIntent().getSerializableExtra("cameFromGameActivity");

        if(cameFromGame)
        {
            SoundManager.fadeThrowMusic(R.raw.menu_music, FadingSpeed.FAST,true);
            score = (int) getIntent().getSerializableExtra("points");
            selectedMode = (GameMode) getIntent().getSerializableExtra("gamemode");
            difficulty = (Difficulty) getIntent().getSerializableExtra("difficulty");
            switch(selectedMode)
            {
                case SINGLESPEED:
                    switch (difficulty)
                    {
                        case EASY:
                            ((TextView)findViewById(R.id.layerView)).setText("SPEED - EASY");
                            break;
                        case MEDIUM:
                            ((TextView)findViewById(R.id.layerView)).setText("SPEED - MEDIUM");
                            break;
                        case HARD:
                            ((TextView)findViewById(R.id.layerView)).setText("SPEED - HARD");
                            break;
                        case MAJOR:
                            ((TextView)findViewById(R.id.layerView)).setText("SPEED - MAJOR");
                            break;
                    }
                    break;
                case SINGLECLASSIC:
                    switch (difficulty)
                    {
                        case EASY:
                            ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - EASY");
                            break;
                        case MEDIUM:
                            ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - MEDIUM");
                            break;
                        case HARD:
                            ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - HARD");
                            break;
                        case MAJOR:
                            ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - MAJOR");
                            break;
                    }
                    break;
                case SINGLEJUGGLE:
                    switch (difficulty)
                    {
                        case EASY:
                            ((TextView)findViewById(R.id.layerView)).setText("JUGGLE - EASY");
                            break;
                        case MEDIUM:
                            ((TextView)findViewById(R.id.layerView)).setText("JUGGLE - MEDIUM");
                            break;
                        case HARD:
                            ((TextView)findViewById(R.id.layerView)).setText("JUGGLE - HARD");
                            break;
                        case MAJOR:
                            ((TextView)findViewById(R.id.layerView)).setText("JUGGLE - MAJOR");
                            break;
                    }
                    break;
            }

            final AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
            alertDialog.setTitle("SEE YOUR SCORE");
            alertDialog.setMessage("ENTER NAME");
            final TextView textView = findViewById(R.id.NameViewHigh);
            final EditText input = new EditText(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            input.setTextColor(Color.BLACK);
            input.setLayoutParams(lp);
            alertDialog.setView(input);
            alertDialog.setPositiveButton("CONFIRM",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            playerName = input.getText().toString();
                            if (playerName.trim().length()<=0||playerName.matches("-empty-"))
                            {
                                playerName = "SNEXEFEX";
                            }

                            currentScore = new Score(playerName, score);
                            recalculateHighScore(currentScore);
                        }
                    });

            alertDialog.show();
        }

        else
        {
            selectedMode = GameMode.SINGLECLASSIC;
            difficulty = Difficulty.EASY;
            showHighScore(selectedMode, difficulty);
        }

        Button switchOne = findViewById(R.id.switchOne);
        Button switchTwo = findViewById(R.id.switchTwo);

        switchOne.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                switch(selectedMode){
                    case SINGLECLASSIC:
                        switch(difficulty)
                        {
                            case EASY:
                                selectedMode = GameMode.SINGLESPEED;
                                difficulty = Difficulty.MAJOR;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MEDIUM:
                                selectedMode = GameMode.SINGLECLASSIC;
                                difficulty = Difficulty.EASY;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case HARD:
                                selectedMode = GameMode.SINGLECLASSIC;
                                difficulty = Difficulty.MEDIUM;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MAJOR:
                                selectedMode = GameMode.SINGLECLASSIC;
                                difficulty = Difficulty.HARD;
                                showHighScore(selectedMode, difficulty);
                                break;
                        }
                        break;
                    case SINGLEJUGGLE:
                        switch(difficulty)
                        {
                            case EASY:
                                selectedMode = GameMode.SINGLECLASSIC;
                                difficulty = Difficulty.MAJOR;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MEDIUM:
                                selectedMode = GameMode.SINGLEJUGGLE;
                                difficulty = Difficulty.EASY;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case HARD:
                                selectedMode = GameMode.SINGLEJUGGLE;
                                difficulty = Difficulty.MEDIUM;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MAJOR:
                                selectedMode = GameMode.SINGLEJUGGLE;
                                difficulty = Difficulty.HARD;
                                showHighScore(selectedMode, difficulty);
                                break;
                        }
                        break;
                    case SINGLESPEED:
                        switch(difficulty)
                        {
                            case EASY:
                                selectedMode = GameMode.SINGLEJUGGLE;
                                difficulty = Difficulty.MAJOR;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MEDIUM:
                                selectedMode = GameMode.SINGLESPEED;
                                difficulty = Difficulty.EASY;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case HARD:
                                selectedMode = GameMode.SINGLESPEED;
                                difficulty = Difficulty.MEDIUM;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MAJOR:
                                selectedMode = GameMode.SINGLESPEED;
                                difficulty = Difficulty.HARD;
                                showHighScore(selectedMode, difficulty);
                                break;
                        }
                        break;
                }
            }
        });

        switchTwo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                switch(selectedMode)
                {
                    case SINGLECLASSIC:
                        switch(difficulty)
                        {
                            case EASY:
                                selectedMode = GameMode.SINGLECLASSIC;
                                difficulty = Difficulty.MEDIUM;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MEDIUM:
                                selectedMode = GameMode.SINGLECLASSIC;
                                difficulty = Difficulty.HARD;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case HARD:
                                selectedMode = GameMode.SINGLECLASSIC;
                                difficulty = Difficulty.MAJOR;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MAJOR:
                                selectedMode = GameMode.SINGLEJUGGLE;
                                difficulty = Difficulty.EASY;
                                showHighScore(selectedMode, difficulty);
                                break;
                        }
                        break;
                    case SINGLEJUGGLE:
                        switch(difficulty)
                        {
                            case EASY:
                                selectedMode = GameMode.SINGLEJUGGLE;
                                difficulty = Difficulty.MEDIUM;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MEDIUM:
                                selectedMode = GameMode.SINGLEJUGGLE;
                                difficulty = Difficulty.HARD;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case HARD:
                                selectedMode = GameMode.SINGLEJUGGLE;
                                difficulty = Difficulty.MAJOR;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MAJOR:
                                selectedMode = GameMode.SINGLESPEED;
                                difficulty = Difficulty.EASY;
                                showHighScore(selectedMode, difficulty);
                                break;
                        }
                        break;
                    case SINGLESPEED:
                        switch(difficulty)
                        {
                            case EASY:
                                selectedMode = GameMode.SINGLESPEED;
                                difficulty = Difficulty.MEDIUM;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MEDIUM:
                                selectedMode = GameMode.SINGLESPEED;
                                difficulty = Difficulty.HARD;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case HARD:
                                selectedMode = GameMode.SINGLESPEED;
                                difficulty = Difficulty.MAJOR;
                                showHighScore(selectedMode, difficulty);
                                break;
                            case MAJOR:
                                selectedMode = GameMode.SINGLECLASSIC;
                                difficulty = Difficulty.EASY;
                                showHighScore(selectedMode, difficulty);
                                break;
                        }
                        break;
                }
            }
        });
    }

    public void showHighScore(GameMode mode, Difficulty difficulty)
    {
        if(mode ==null)
        {
            mode = GameMode.SINGLECLASSIC;
        }
        switch(mode)
        {
            case SINGLESPEED:
                switch(difficulty)
                {
                    case EASY:
                        ((TextView)findViewById(R.id.layerView)).setText("SPEED - EASY");
                        setSelectedScore(HighscoreCalculator.speedHighscoreEasy);
                        break;
                    case MEDIUM:
                        ((TextView)findViewById(R.id.layerView)).setText("SPEED - MEDIUM");
                        setSelectedScore(HighscoreCalculator.speedHighscoreMedium);
                        break;
                    case HARD:
                        ((TextView)findViewById(R.id.layerView)).setText("SPEED - HARD");
                        setSelectedScore(HighscoreCalculator.speedHighscoreHard);
                        break;
                    case MAJOR:
                        ((TextView)findViewById(R.id.layerView)).setText("SPEED - MAJOR");
                        setSelectedScore(HighscoreCalculator.speedHighscoreMajor);
                        break;
                }

                break;
            case SINGLECLASSIC:
                switch(difficulty)
                {
                    case EASY:
                        ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - EASY");
                        setSelectedScore(HighscoreCalculator.classicHighscoreEasy);
                        break;
                    case MEDIUM:
                        ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - MEDIUM");
                        setSelectedScore(HighscoreCalculator.classicHighscoreMedium);
                        break;
                    case HARD:
                        ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - HARD");
                        setSelectedScore(HighscoreCalculator.classicHighscoreHard);
                        break;
                    case MAJOR:
                        ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - MAJOR");
                        setSelectedScore(HighscoreCalculator.classicHighscoreMajor);
                        break;
                }

                break;
            case SINGLEJUGGLE:
                switch(difficulty)
                {
                    case EASY:
                        ((TextView)findViewById(R.id.layerView)).setText("JUGGLE - EASY");
                        setSelectedScore(HighscoreCalculator.juggleHighscoreEasy);
                        break;
                    case MEDIUM:
                        ((TextView)findViewById(R.id.layerView)).setText("JUGGLE - MEDIUM");
                        setSelectedScore(HighscoreCalculator.juggleHighscoreMedium);
                        break;
                    case HARD:
                        ((TextView)findViewById(R.id.layerView)).setText("JUGGLE - HARD");
                        setSelectedScore(HighscoreCalculator.juggleHighscoreHard);
                        break;
                    case MAJOR:
                        ((TextView)findViewById(R.id.layerView)).setText("JUGGLE - MAJOR");
                        setSelectedScore(HighscoreCalculator.juggleHighscoreMajor);
                        break;
                }
                break;
            default:
                setSelectedScore(HighscoreCalculator.classicHighscoreEasy);
                ((TextView)findViewById(R.id.layerView)).setText("CLASSIC - EASY");
                break;
        }
    }

    public void setSelectedScore(Score[] scoreType)
    {
        nmFirst = findViewById(R.id.nmOne);
        nmSecond = findViewById(R.id.nmTwo);
        nmThird = findViewById(R.id.nmThree);
        nmFourth = findViewById(R.id.nmFour);
        nmFifth = findViewById(R.id.nmFive);

        scFirst = findViewById(R.id.scOne);
        scSecond = findViewById(R.id.scTwo);
        scThird = findViewById(R.id.scThree);
        scFourth = findViewById(R.id.scFour);
        scFifth = findViewById(R.id.scFive);

        nmFirst.setText(""+scoreType[0].name+"");
        nmSecond.setText(""+scoreType[1].name+"");
        nmThird.setText(""+scoreType[2].name+"");
        nmFourth.setText(""+scoreType[3].name+"");
        nmFifth.setText(""+scoreType[3].name+"");

        scFirst.setText(""+scoreType[0].score+"");
        scSecond.setText(""+scoreType[1].score+"");
        scThird.setText(""+scoreType[2].score+"");
        scFourth.setText(""+scoreType[3].score+"");
        scFifth.setText(""+scoreType[3].score+"");
    }

    private void recalculateHighScore(Score score)
    {
        int status;
        switch(selectedMode)
        {
            case SINGLECLASSIC:
                switch(difficulty)
                {
                    case EASY:
                        HighscoreCalculator.isTopClassicScore(score, Difficulty.EASY);
                        setSelectedScore(HighscoreCalculator.classicHighscoreEasy);
                        break;
                    case MEDIUM:
                        HighscoreCalculator.isTopClassicScore(score, Difficulty.MEDIUM);
                        setSelectedScore(HighscoreCalculator.classicHighscoreMedium);
                        break;
                    case HARD:
                        HighscoreCalculator.isTopClassicScore(score, Difficulty.HARD);
                        setSelectedScore(HighscoreCalculator.classicHighscoreHard);
                        break;
                    case MAJOR:
                        HighscoreCalculator.isTopClassicScore(score, Difficulty.MAJOR);
                        setSelectedScore(HighscoreCalculator.classicHighscoreMajor);
                        break;
                }
                break;

            case SINGLESPEED:
                switch(difficulty)
                {
                    case EASY:
                        HighscoreCalculator.isTopSpeedScore(score, Difficulty.EASY);
                        setSelectedScore(HighscoreCalculator.speedHighscoreEasy);
                        break;
                    case MEDIUM:
                        HighscoreCalculator.isTopSpeedScore(score, Difficulty.MEDIUM);
                        setSelectedScore(HighscoreCalculator.speedHighscoreMedium);
                        break;
                    case HARD:
                        HighscoreCalculator.isTopSpeedScore(score, Difficulty.HARD);
                        setSelectedScore(HighscoreCalculator.speedHighscoreHard);
                        break;
                    case MAJOR:
                        HighscoreCalculator.isTopSpeedScore(score, Difficulty.MAJOR);
                        setSelectedScore(HighscoreCalculator.speedHighscoreMajor);
                        break;
                }
                break;

            case SINGLEJUGGLE:
                switch(difficulty)
                {
                    case EASY:
                        HighscoreCalculator.isTopJuggleScore(score, Difficulty.EASY);
                        setSelectedScore(HighscoreCalculator.juggleHighscoreEasy);
                        break;
                    case MEDIUM:
                        HighscoreCalculator.isTopJuggleScore(score, Difficulty.MEDIUM);
                        setSelectedScore(HighscoreCalculator.juggleHighscoreMedium);
                        break;
                    case HARD:
                        HighscoreCalculator.isTopJuggleScore(score, Difficulty.HARD);
                        setSelectedScore(HighscoreCalculator.juggleHighscoreHard);
                        break;
                    case MAJOR:
                        HighscoreCalculator.isTopJuggleScore(score, Difficulty.MAJOR);
                        setSelectedScore(HighscoreCalculator.juggleHighscoreMajor);
                        break;
                }
                break;

            default:
                status = 8888;
                setSelectedScore(HighscoreCalculator.classicHighscoreEasy);
                break;
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if(!cameFromLinkedActivity)
        {
            SoundManager.resumeMusic();
        }
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if(!changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
            cameFromLinkedActivity = false;
        }
    }
}