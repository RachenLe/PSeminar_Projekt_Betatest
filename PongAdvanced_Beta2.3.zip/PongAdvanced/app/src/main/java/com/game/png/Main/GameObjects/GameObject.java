package com.game.png.Main.GameObjects;

import android.graphics.Canvas;
import android.graphics.RectF;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Vector;
import com.game.png.Main.GameObjects.PhysicsAndMisc.FloatPoint;
import com.game.png.Main.GameModes.GamePanel;
import com.game.png.Main.GameObjects.PhysicsAndMisc.SurfaceBorders;
import com.game.png.Main.SoundManager;
import com.game.png.R;
import java.util.ArrayList;

public abstract class GameObject extends RectF
{
    public Vector vector = new Vector(0,0);
    public FloatPoint point;
    public MovingDirection movingDirection;
    public boolean moveable, bounceAble;
    private int splitedVelocity =1, varVel;
    public float movingX, movingY, startMX , startMY;
    //Colliding parameters
    public boolean activated;
    public ArrayList<Collider> colliders = new ArrayList<Collider>();
    public boolean collisionDetectedInThisStep;
    // Misc parameters
    public GamePanel context;
    public int countsOfMoving =1;
    public boolean movingHasChanged = false;

    public GameObject(float x, float y, float width, float height, GamePanel context)
    {
       super(x,y,x+width,y+height);
       this.point = new FloatPoint(x,y);
       moveable = true;
       this.context = context;
    }

    public void calculateMoving(float movingX , float movingY)
    {
       vector = null;
       vector = new Vector(movingX, movingY);
       this.movingY = movingY;
       this.movingX = movingX;
        movingHasChanged = true;
    }

    public void resetStartVelocity()
    {
        startMY =0;
        startMX=0;
        splitedVelocity =0;
        countsOfMoving=1;
    }

    public void calculateCountsOfMoving()
    {
        //Die momentane Geschwindigkeit der Bewegung ist größer als 30 (könnte Kollisionsdetektionsproblem erzeugen)
        if(movingX<=-30||movingX>=30||movingY<=-30||movingY>=30)
        {
            //übertragen der
            float varX;
            float varY;
            varX = startMX;
            varY = startMY;
            if (movingX < 0 && varX >0)
            {
                varX = varX;
                varX = varX - movingX;
            }

            else if(movingX> 0 && varX<0)
            {
                varX =0-varX;
                varX = varX + movingX;
            }

            else
            {
                varX = varX+movingX;
            }

            if (movingY < 0  && varY >0)
            {
                varY = varY;
                varY = varY - movingY;
            }

            else if(movingY> 0 && varY<0)
            {
                varY =0-varY;
                varY = varY + movingY;
            }

            else
            {
                varY = varY+movingY;
            }

            if(varY<0)
            {
                startMY = 0-varY;
            }

            else
            {
                startMY = varY;
            }

            if(varX<0)
            {
                startMX = 0-varX;
            }

            else
            {
                startMX = varX;
            }

            if ((startMX / 15 > splitedVelocity && startMX > startMY))
            {
                countsOfMoving = Math.round(startMX / 5);
                if (movingX > 0)
                {
                    movingX = 5;
                }

                else if (movingX < 0)
                {
                    movingX = -5;
                }

                movingY = movingY / countsOfMoving;
            }

            else if ((startMY / 15 > splitedVelocity&& startMY > startMX))
            {
                countsOfMoving = Math.round(startMY / 5);
                if (movingY > 0)
                {
                    movingY = 5;
                }

                else if (movingY < 0)
                {
                    movingY = -5;
                }

                movingX = movingX / countsOfMoving;
            }

            else
            {
                countsOfMoving = 1;
            }
            calculateMoving(movingX, movingY);
            splitedVelocity++;
        }
    }
    //position management
    public void move()
    {
            point.x = point.x + vector.x;
            point.y = point.y+ vector.y;
            updatePosition();
    }

    public void move(float x, float y)
    {
        calculateMoving(x,y);
        move();
        movingHasChanged = true;
    }

    public void setPosition(float x, float y)
    {
        if(x+width()/2 < context.getWidth()&& x- width()/2 > 0) {
            point.x = x;
        }
        if(y+height()/2 < context.getHeight() && y- height()/2 > 0)
            point.y = y;
        updatePosition();
    }

    private void updatePosition()
    {
        //updaten der position um positionswechsel intern der GameObject Klasse an die Superklasse zu übertragen
        set(point.x - width()/2, point.y - height()/2, point.x + width()/2, point.y + height()/2);

        //definiert die Bewegungsrichtung relativ zum Spielfeld
        if(vector.x> 0)
        {
            //Der x-Wert des Vektors ist größer null also bewegt sich das Objekt nach rechts
            if(vector.y>0)
            {
                // der y-Wert des Vektors ist größer null also bewegt sich das Objekt nach unten
                movingDirection = MovingDirection.RIGHTDOWN;
            }

            else if(vector.y==0)
            {
                // der y-Wert des Vektors ist null es findet keine auf- oder Abwärtsbewegung statt
                movingDirection = MovingDirection.RIGHT;
            }

            else
            {
                // der y-Wert des Vektors ist kleiner null also bewegt sich das Objekt nach oben
                movingDirection = MovingDirection.RIGHTUP;
            }
        }

        else if(vector.x== 0)
        {
            //Der x-Wert des Vektors ist null es findet keine seitliche Bewegung statt
            if(vector.y>0)
            {
                // der y-Wert des Vektors ist größer null also bewegt sich das Objekt nach unten
                movingDirection = MovingDirection.DOWN;
            }
            else if(vector.y==0)
            {
                // der y-Wert des Vektors ist null es findet keine auf- oder Abwärtsbewegung statt
                movingDirection = MovingDirection.NOTMOVING;
            }

            else
            {
                // der y-Wert des Vektors ist kleiner null also bewegt sich das Objekt nach oben
                movingDirection = MovingDirection.UP;
            }
        }

        else
            {
            //Der x-Wert des Vektors ist kleiner null also bewegt sich das Objekt nach links
            if(vector.y>0)
            {
                // der y-Wert des Vektors ist größer null also bewegt sich das Objekt nach unten
                movingDirection = MovingDirection.LEFTDOWN;
            }

            else if(vector.y==0)
            {
                // der y-Wert des Vektors ist null es findet keine auf- oder Abwärtsbewegung statt
                movingDirection = MovingDirection.LEFT;
            }

            else
            {
                // der y-Wert des Vektors ist kleiner null also bewegt sich das Objekt nach oben
                movingDirection = MovingDirection.LEFTUP;
            }
        }
    }

    public void addCollider(Collider collider)
    {
      colliders.add(collider);
    }

    public void removeCollider(Collider collider)
    {
        colliders.remove(collider);
    }

    public boolean detectCollision(GameObject obstacle)
    {
        return RectF.intersects(this,obstacle);
    }

    public SurfaceBorders checkBoundCollision()
    {
        //Die y-Koordinate des Zentrums ist kleiner als die Hälfte der Höhe de Objekts
        // => das Objekt berührt die Oberseite des Spielfeldes
        if(this.centerY()< ((this.height()/2) +5) && !(this.centerX()> (context.getWidth()- (this.width()/2) -5)) && !(this.centerX()< ((this.width()/2) +5)))
        {
            //Top Border
            return SurfaceBorders.TOP;
        }
        //Die y-Koordinate des Zentrums ist größer als die Höhe Spielfeldes minus die Hälfte der Höhe
        // => das Objekt berührt die Unterseite des Spielfeldes
        else if(this.centerY()> (context.getHeight()- (this.height()/2) -5) && !(this.centerX()> (context.getWidth()- (this.width()/2) -5)) && !(this.centerX()< ((this.width()/2) +5)))
        {
            //Bottom Border
            return SurfaceBorders.BOTTOM;
        }
        //Die x-Koordinate des Zentrums ist keiner als die halbe Breite des Objekts
        // => das Objekt berührt die Linke seite des Spielfeldes
        else if(this.centerX()< ((this.width()/2) +5)&& !(this.centerY()< ((this.height()/2) +5)) && !(this.centerY()> (context.getHeight()- (this.height()/2) -5)))
        {
            //Left Border
            return SurfaceBorders.LEFT;
        }

        //Die x-Koordinate des Zentrums ist größer als die Breite des Spielfelds minus die halbe Breite der Figur
        //=> Das Objekt berührt die rechte Seite des Spielfelds
        else if(this.centerX()> (context.getWidth()- (this.width()/2) -5)&& !(this.centerY()< ((this.height()/2) +5)) && !(this.centerY()> (context.getHeight()- (this.height()/2) -5)))
        {
            //Right Bordder
            return SurfaceBorders.RIGHT;
        }

        //Die x-Koordinate des Zentrums ist größer als die Breite des Spielfelds minus die halbe Breite der Figur
        //=> Das Objekt berührt die rechte Seite des Spielfelds
        //Die y-Koordinate des Zentrums ist größer als die Höhe Spielfeldes minus die Hälfte der Höhe
        // => das Objekt berührt die Unterseite des Spielfeldes
        else if(this.centerX()> (context.getWidth()- (this.width()/2) -5) && this.centerY()> (context.getHeight()- (this.height()/2) -5))
        {
          //TOP and Right Border
            return SurfaceBorders.RIGHTBOTTOM;
        }

        //Die x-Koordinate des Zentrums ist größer als die Breite des Spielfelds minus die halbe Breite der Figur
        //=> Das Objekt berührt die rechte Seite des Spielfelds
        //Die y-Koordinate des Zentrums ist kleiner als die Hälfte der Höhe de Objekts
        // => das Objekt berührt die Oberseite des Spielfeldes
        else if(this.centerX()> (context.getWidth()- (this.width()/2) -5) && this.centerY()< ((this.height()/2) +5))
        {
            //Bottom and Right Border
            return SurfaceBorders.RIGHTTOP;
        }

        //Die x-Koordinate des Zentrums ist keiner als die halbe Breite des Objekts
        // => das Objekt berührt die Linke seite des Spielfeldes
        //Die y-Koordinate des Zentrums ist größer als die Höhe Spielfeldes minus die Hälfte der Höhe
        // => das Objekt berührt die Unterseite des Spielfeldes
        else if(this.centerX()< ((this.width()/2) +5) && this.centerY()> (context.getHeight()- (this.height()/2) -5))
        {
            //Bottom and Left Border
            return SurfaceBorders.LEFTBOTTOM;
        }

        //Die x-Koordinate des Zentrums ist keiner als die halbe Breite des Objekts
        // => das Objekt berührt die Linke seite des Spielfeldes
        //Die y-Koordinate des Zentrums ist kleiner als die Hälfte der Höhe des Objekts
        // => das Objekt berührt die Oberseite des Spielfeldes
        else if(this.centerX()< ((this.width()/2) +5) && this.centerY()< ((this.height()/2) +5))
        {
            //Top and Right Border
            return SurfaceBorders.LEFTTOP;
        }
        else
        {
            //keine Seite wird berührt
            return SurfaceBorders.NONE;
        }
    }

    public void checkAndReflectByMovingDirection(MovingDirection direction)
    {
        switch(direction)
        {
            case UP:
                switch(this.movingDirection)
                {
                    case LEFTUP:
                    case RIGHTUP:
                    case UP:
                        this.vector.reflectY();
                        SoundManager.playSound(R.raw.pong);
                        break;
                }

                break;
            case DOWN:
                switch(this.movingDirection)
                {
                    case LEFTDOWN:
                    case RIGHTDOWN:
                    case DOWN:
                        this.vector.reflectY();
                        SoundManager.playSound(R.raw.pong);
                        break;
                }

                break;
            case LEFT:
                switch(this.movingDirection)
                {
                    case LEFTUP:
                    case LEFTDOWN:
                    case LEFT:
                        this.vector.reflectX();
                        SoundManager.playSound(R.raw.pong);
                        break;
                }

                break;
            case RIGHT:

                switch(this.movingDirection)
                {
                    case RIGHTUP:
                    case RIGHTDOWN:
                    case RIGHT:
                        this.vector.reflectX();
                        SoundManager.playSound(R.raw.pong);
                        break;
                }
                break;
        }
    }

    public boolean intersectsLeftSide(GameObject obstacle)
    {
        return obstacle.left < right && right < obstacle.left + 10 && bottom > obstacle.top && !(top > obstacle.bottom)
                && (movingDirection == MovingDirection.RIGHTDOWN || movingDirection == MovingDirection.RIGHTUP || movingDirection == MovingDirection.RIGHT);
    }

    public boolean intersectsRightSide(GameObject obstacle)
    {
        return obstacle.right > left && left > obstacle.right - 10 && bottom > obstacle.top && !(top > obstacle.bottom)
                && (movingDirection == MovingDirection.LEFTDOWN || movingDirection == MovingDirection.LEFTUP || movingDirection == MovingDirection.LEFT);
    }

    public boolean intersectsUpperSide(GameObject obstacle)
    {
        return obstacle.left + 10 < right && left < obstacle.right - 10 && bottom > obstacle.top && !(top > obstacle.bottom - obstacle.height() / 2)
                && (movingDirection == MovingDirection.RIGHTDOWN || movingDirection == MovingDirection.LEFTDOWN || movingDirection == MovingDirection.DOWN);
    }

    public boolean intersectsBottomSide(GameObject obstacle)
    {

        return obstacle.left + 10 < right && left < obstacle.right - 10 && bottom > obstacle.bottom && top > obstacle.top && top < obstacle.bottom
                && (movingDirection == MovingDirection.RIGHTUP || movingDirection == MovingDirection.LEFTUP || movingDirection == MovingDirection.UP);
    }

    public void checkAndReflectByObstacle( GameObject obstacle)
    {
        if(intersectsLeftSide(obstacle))
        {
            checkAndReflectByMovingDirection(MovingDirection.RIGHT);
        }

        if(intersectsRightSide(obstacle))
        {
            checkAndReflectByMovingDirection(MovingDirection.LEFT);
        }

        if(intersectsUpperSide(obstacle))
        {
            checkAndReflectByMovingDirection(MovingDirection.DOWN);
        }

        if(intersectsBottomSide(obstacle))
        {
            checkAndReflectByMovingDirection(MovingDirection.UP);
        }
    }
    //rendering management
    public abstract void draw(Canvas canvas);

    public void update()
    {
        collisionDetectedInThisStep = false;
        updatePosition();
        this.movingX = vector.x;
        this.movingY = vector.y;
        if (movingHasChanged)
        {
            calculateCountsOfMoving();
            movingHasChanged = false;
        }
        for(int i = 0; i< colliders.size();i++ )
        {
            colliders.get(i).check();
        }
    }

    public void delete()
    {
        vector = null;
        point = null;
        movingDirection = null;
        context = null;
        for(int i =0; i< colliders.size(); i++)
        {
            colliders.get(i).deleteCollider();
        }
    }
}