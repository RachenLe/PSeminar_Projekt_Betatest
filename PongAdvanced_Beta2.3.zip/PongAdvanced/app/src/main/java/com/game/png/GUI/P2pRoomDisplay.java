package com.game.png.GUI;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.game.png.Main.MultiplayerUtil.ClientTask;
import com.game.png.Main.MultiplayerUtil.MultiplayerBroadcastReceiver;
import com.game.png.Main.MultiplayerUtil.P2pManagement;
import com.game.png.Main.MultiplayerUtil.ServerTask;
import com.game.png.Main.SoundManager;
import com.game.png.R;

import java.io.Serializable;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


public class P2pRoomDisplay extends Activity implements Serializable
{

    private MultiplayerBroadcastReceiver receiver;
    public boolean cameFromLinkedActivity;
    public boolean changingToLinkedActivity;
    public WifiP2pManager manager;
    public WifiP2pManager.Channel channel;
    public IntentFilter intentFilter;
    public ListView listView;
    public ArrayAdapter adapter;
    private boolean registered = false;
    private boolean changingToP2pActivity = false;
    private boolean isHost;
    private Timer requestTimer;
    private boolean requesting;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        isHost = (boolean) getIntent().getSerializableExtra("isOwner");
        if(isHost) {
            setContentView(R.layout.activity_room_owner_display);
        }
        else {
            setContentView(R.layout.activity_room_member_display);
        }

        manager = P2pManagement.manager;
        channel = P2pManagement.channel;
        if(!registered) {
            receiver = new MultiplayerBroadcastReceiver(manager, channel, this);
            registered = true;
        }

        intentFilter = new IntentFilter();
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        registerReceiver(receiver, intentFilter);

        listView = findViewById(R.id.connectedClients);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        listView.setAdapter(adapter);

        cameFromLinkedActivity = (boolean) getIntent().getSerializableExtra("cameFromLinkedActivity");
        if(!requesting) {
            requestGroupInfo();
            requesting = true;
        }
    }



    @Override
    protected void onResume() {
        super.onResume();
        if (!cameFromLinkedActivity) {
            SoundManager.resumeMusic();
        }
        if(!registered){
            registerReceiver(receiver, intentFilter);
            registered = true;
        }
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        if(!requesting) {
            requestGroupInfo();
            requesting = true;
        }
    }

    /* unregister the broadcast receiver */


    @Override
    protected void onPause(){

        super.onPause();
        if(!changingToLinkedActivity)
        {
            SoundManager.pauseMusic();
            cameFromLinkedActivity = false;

        }
        if(receiver != null) {
            unregisterReceiver(receiver);
            registered = false;

        }
        if(requesting) {
            requestTimer.cancel();
            requestTimer.purge();
            requesting = false;
        }


    }

    @Override
    protected void onDestroy(){
        if(!changingToP2pActivity){
            receiver.disconnect();
            if (receiver.isOrderedBroadcast()) {
                receiver.abortBroadcast();
                receiver.clearAbortBroadcast();
            }
        }
        if(registered && receiver != null ){
            registered = false;
            unregisterReceiver(receiver);
        }
        if(requesting) {
            requestTimer.cancel();
            requestTimer.purge();
            requesting = false;
        }
        super.onDestroy();
    }


    public void back(View view) {
        changingToP2pActivity = false;
        changingToLinkedActivity = true;
        Intent intent = new Intent(P2pRoomDisplay.this, P2pDetection.class);
        intent.putExtra("cameFromLinkedActivity", true);
        startActivity(intent);
        finish();
    }


    public void requestGroupInfo(){
        requestTimer =new Timer();
        final Context context = this;
                requestTimer.schedule(new TimerTask(){

            @Override
            public void run() {
                manager.requestGroupInfo(channel,receiver.groupInfo);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.clear();
                        if(receiver.hostDevice!= null) {
                            adapter.add(receiver.hostDevice.deviceAddress + "       HOST");
                        }
                        for(WifiP2pDevice device : receiver.groupMembers) {
                            adapter.add(device.deviceAddress + "       CLIENT");

                        }
                    }
                });

            }
        },0,1000);

    }

    public void startGame(View v){
        if(isHost){
            try {

                final ServerTask server = new ServerTask(8888);
                server.execute();

            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
        else{


            final ClientTask localClient = new ClientTask(8888, receiver.groupOwnerAdress);
                        localClient.execute();

        }
    }


}
