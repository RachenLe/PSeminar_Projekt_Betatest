package com.game.png.Main.GameModes;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import com.game.png.GUI.Game;
import com.game.png.Main.GameObjects.Paddl;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Collider;
import com.game.png.Main.GameObjects.PhysicsAndMisc.Difficulty;
import com.game.png.Main.GameObjects.Ball;
import com.game.png.Main.GameObjects.PhysicsAndMisc.MovingDirection;

public class SpeedMode extends GamePanel
{
    private float startX, startY;
    private GameThread thread ;
    private Paddl player;
    public Ball ball;
    public int pointsPlayer  = 0, lifes = 0;
    private boolean ballOnStartPosition = true;
    private boolean justStarted =true;
    private int bounces;
    public float maxBallSpeed;

    public SpeedMode(Game context , Difficulty difficulty)
    {
        super(context, difficulty);
        getHolder().addCallback(this);
    }
    @Override
    public void onCreation()
    {
        thread = new GameThread(getHolder(),this);
        player = new Paddl(500 * widthFaktor, 1300*heightFaktor, 300 * widthFaktor, 50*heightFaktor, objectColor, this);
        ball = new Ball(100*heightFaktor, 100*heightFaktor, 20*widthFaktor, objectColor, this, difficulty);
        addObject(ball);
        addObject(player);
        colliders.add(new Collider(player, ball){});
        ball.activate();
        player.activate();

        switch(difficulty)
        {
            case MAJOR:
                startX = 40*widthFaktor;
                startY = 80*heightFaktor;
                break;

            case EASY:
                startX = 10*widthFaktor;
                startY = 30*heightFaktor;
                break;

            case HARD:
                startX = 30*widthFaktor;
                startY = 60*heightFaktor;
                break;

            case MEDIUM:
                startX = 20*widthFaktor;
                startY = 45*heightFaktor;
                break;
        }
        maxBallSpeed = startX+startY;
    }

    @Override
    public void onTouch(MotionEvent event)
    {

        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                if (won || gameOver)
                {
                    endedOnClick= true;
                }

            case MotionEvent.ACTION_MOVE:
                if (!won && !gameOver)
                {
                    boolean ballRelease = false;
                    //Der Hauptpointer berührt den Ball
                    if(event.getX() < getWidth() / 2 + ball.width() + 20 && event.getX() > getWidth() / 2 - ball.width() - 20
                            && event.getY() < getHeight() / 2 + ball.height() + 20 && event.getY() > getHeight() / 2 - ball.height() - 20
                            && ballOnStartPosition)
                    {
                        ballRelease = true;
                    }

                    //ein anderer Pointer berührt den Ball

                    try
                    {
                        int pointer = event.getPointerId(event.getPointerCount()-1);
                        if (((event.getX(pointer) < getWidth() / 2 + ball.width() + 20 && event.getX(pointer) > getWidth() / 2 - ball.width() - 20
                                && event.getY(pointer) < getHeight() / 4 + ball.height() + 20 && event.getY(pointer) > getHeight() / 4 - ball.height() - 20))
                                && ballOnStartPosition)
                        {
                            ballRelease = true;
                        }

                    }

                    catch (Exception e)
                    {

                    }

                    //der Ball wurde berührt und lag in der Startposition
                    if(ballRelease)
                    {
                        ball.resetStartVelocity();
                        ball.calculateMoving(startX, startY);
                        ball.moveable = true;
                        ballOnStartPosition = false;
                    }

                    //der Player wurde durch den Hauptpointer verschoben
                    if (event.getPointerCount() == 1)
                    {
                        player.setPosition((int) event.getX(), getHeight() - 150);
                    }
                }

                break;
            case MotionEvent.ACTION_UP:

                break;
        }

    }
    @Override
    public void extendedDraw(Canvas canvas)
    {
        Paint miscPaint = new Paint();
        miscPaint.setColor(objectColor);
        miscPaint.setTextSize(widthFaktor*125);
        Rect rect = new Rect();
        int ppE;
        if (pointsPlayer > 99)
        {
            ppE = 3;
        } else if (pointsPlayer > 9)
        {
            ppE = 2;
        } else {
            ppE = 1;
        }

        miscPaint.getTextBounds("" + pointsPlayer + "", 0, ppE, rect);
        float helloHeight = rect.height();
        rect = new Rect();
        float byeWidth = rect.width();
        float byeHeight = rect.height();
        canvas.drawText("" + pointsPlayer + "", 15, ((this.getHeight() / 2) + (helloHeight * 3 / 2)), miscPaint);
        canvas.drawLine(0, getHeight() / 4, getWidth(), getHeight() / 4, miscPaint);
    }

    @Override
    public void updateSpc()
    {

        if(justStarted)
        {
            ball.setPosition(getWidth()/2,getHeight()/4);
            justStarted=false;
            ballOnStartPosition=true;
        }
        if(player.centerY() < getHeight()-150 || player.centerY() > getHeight()-150 )
        {
            player.setPosition(player.point.x,getHeight()-150);
        }

        boolean special = false;
        switch(ball.checkBoundCollision())
        {
            case RIGHT:
                ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                break;

            case LEFT:
                ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                break;

            case LEFTTOP:
                ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                special = true;

            case RIGHTTOP:
                if(!special)
                {
                    ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                }

            case TOP:
                ball.checkAndReflectByMovingDirection(MovingDirection.UP);
                pointsPlayer++;
                bounces++;
                break;

            case LEFTBOTTOM:
                ball.checkAndReflectByMovingDirection(MovingDirection.LEFT);
                special = true;

            case RIGHTBOTTOM:
                if(!special)
                {
                    ball.checkAndReflectByMovingDirection(MovingDirection.RIGHT);
                }

            case BOTTOM:
                ball.moveable = false;
                ball.setPosition(getWidth()/2,getHeight()/2);
                loose(true);
                break;

            default:
                break;
        }

        if(maxBallSpeed< (ball.movingX*ball.countsOfMoving)+(ball.movingY*ball.countsOfMoving))
        {
            maxBallSpeed = (ball.movingX*ball.countsOfMoving)+(ball.movingY*ball.countsOfMoving);
        }
    }

    @Override
    public int getScore()
    {
        int score =(int)Math.round(pointsPlayer);
        if(score<10)
        {
            score = 10;
        }
        return score;
    }
}