package com.game.png.Main.MultiplayerUtil;

import java.lang.reflect.Method;
import java.net.Socket;

/**
 * Created by Lennard on 05.01.2018.
 */

public abstract class MultiplayerManagementThread extends Thread {
    boolean running;
    Socket socket;
    public static final int MAX_SENDS = 30;
    private double averageSENDS;
    private boolean sleeping = false;

    public MultiplayerManagementThread(){
      this.socket = socket;
      running = true;
    }


    @Override
    public void run()
    {
        long startTime;
        long timeMillis = 1000 / MAX_SENDS;
        long waitTime;
        int frameCount = 0;
        long totalTime = 0;
        long targetTime = 1000 / MAX_SENDS;

        while (running)
        {

                startTime = System.nanoTime();
                runningMethod();
                timeMillis = (System.nanoTime() - startTime) / 1000000;
                waitTime = targetTime - timeMillis;
                try
                {
                    if (waitTime > 0)
                    {
                        sleeping = true;
                        sleep(waitTime);
                        sleeping = false;
                    }
                }

                catch (Exception e)
                {
                    continue;
                }

                totalTime += System.nanoTime() - startTime;
                frameCount++;
                if (frameCount == MAX_SENDS)
                {
                    averageSENDS = 1000 / ((totalTime / frameCount) / 1000000);
                    frameCount = 0;
                    totalTime = 0;
                }

        }

    }

    public abstract void runningMethod();

    public void setRunning(boolean b){
        running = b;
    }
}
