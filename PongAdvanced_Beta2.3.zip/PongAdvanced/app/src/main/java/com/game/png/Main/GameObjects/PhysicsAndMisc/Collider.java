package com.game.png.Main.GameObjects.PhysicsAndMisc;

import com.game.png.Main.GameObjects.GameObject;

public abstract class Collider
{

    private GameObject partnerOne, partnerTwo;

    public Collider(GameObject partnerOne, GameObject partnerTwo)
    {
        this.partnerOne = partnerOne;
        this.partnerTwo = partnerTwo;
        this.partnerOne.addCollider(this);
        this.partnerTwo.addCollider(this);
    }

    public void check()
    {
        if (partnerOne.activated==true && partnerTwo.activated == true)
        {

            if (partnerOne.detectCollision(partnerTwo))
            {
                partnerOne.collisionDetectedInThisStep = true;
                partnerTwo.collisionDetectedInThisStep = true;
                if(partnerTwo.bounceAble &! partnerOne.bounceAble)
                {
                    partnerTwo.checkAndReflectByObstacle(partnerOne);
                }

                else if(!(partnerTwo.bounceAble) && partnerOne.bounceAble)
                {
                    partnerOne.checkAndReflectByObstacle(partnerTwo);
                }

                else
                {
                    partnerTwo.checkAndReflectByObstacle(partnerOne);
                    partnerOne.checkAndReflectByObstacle(partnerTwo);
                }
            }
        }
    }

    public void deleteCollider()
    {
        partnerOne.removeCollider(this);
        partnerTwo.removeCollider(this);
        partnerOne = null;
        partnerTwo = null;
    }

    public Collider containsObject(GameObject obj)
    {
        if(this.partnerTwo == obj || this.partnerOne == obj)
        {
            return this;
        }

        else
        {
            return null;
        }
    }
}